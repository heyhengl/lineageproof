#!/usr/bin/env python3
"""Clean, reconcile, analyze, and report a synthetic sales ledger."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterable

import pandas as pd
from reportlab.lib.colors import HexColor, white
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas


PRODUCT_MASTER = {
    "Atlas Pro": {"price": 249.0, "cost": 141.0},
    "Nova Lite": {"price": 119.0, "cost": 61.0},
    "Orbit Kit": {"price": 179.0, "cost": 98.0},
    "Pulse Mini": {"price": 79.0, "cost": 36.0},
    "Vertex Hub": {"price": 329.0, "cost": 190.0},
}
REGION_ALIASES = {
    "north": "North",
    "n": "North",
    "south": "South",
    "s": "South",
    "east": "East",
    "e": "East",
    "e.": "East",
    "west": "West",
    "w": "West",
}
BUILT_AT = "2026-07-17T04:00:00+08:00"

NAVY = HexColor("#0B1220")
INK = HexColor("#152238")
MUTED = HexColor("#5F6B7A")
PANEL = HexColor("#F4F7FB")
LINE = HexColor("#D8E0EA")
CYAN = HexColor("#17B6C8")
BLUE = HexColor("#356AE6")
PURPLE = HexColor("#7B61FF")
GREEN = HexColor("#1C9B67")
AMBER = HexColor("#E49B2E")
RED = HexColor("#D95151")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_region(value: str) -> str:
    normalized = str(value).strip().lower()
    return REGION_ALIASES.get(normalized, str(value).strip().title())


def format_money(value: float) -> str:
    return f"${value:,.0f}"


def wrap_lines(text: str, font: str, size: float, max_width: float) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if not current or stringWidth(candidate, font, size) <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_wrapped(
    pdf: canvas.Canvas,
    text: str,
    x: float,
    y: float,
    width: float,
    *,
    font: str = "Helvetica",
    size: float = 9,
    leading: float = 12,
    color=INK,
    max_lines: int | None = None,
) -> float:
    lines = wrap_lines(text, font, size, width)
    if max_lines is not None:
        lines = lines[:max_lines]
    pdf.setFont(font, size)
    pdf.setFillColor(color)
    for line in lines:
        pdf.drawString(x, y, line)
        y -= leading
    return y


def draw_header(pdf: canvas.Canvas, title: str, subtitle: str, page: int) -> None:
    width, height = A4
    pdf.setFillColor(NAVY)
    pdf.rect(0, height - 92, width, 92, fill=1, stroke=0)
    pdf.setFillColor(CYAN)
    pdf.roundRect(36, height - 45, 132, 18, 9, fill=1, stroke=0)
    pdf.setFillColor(NAVY)
    pdf.setFont("Helvetica-Bold", 8)
    pdf.drawCentredString(102, height - 39, "SYNTHETIC PORTFOLIO PROOF")
    pdf.setFillColor(white)
    pdf.setFont("Helvetica-Bold", 21)
    pdf.drawString(36, height - 70, title)
    pdf.setFont("Helvetica", 9)
    pdf.setFillColor(HexColor("#C7D1E0"))
    pdf.drawRightString(width - 36, height - 69, subtitle)
    pdf.setFillColor(MUTED)
    pdf.setFont("Helvetica", 8)
    pdf.drawString(36, 22, "Fictional data. Reproducible descriptive analysis. No client or account information.")
    pdf.drawRightString(width - 36, 22, f"Page {page} of 4")


def draw_card(pdf: canvas.Canvas, x: float, y: float, w: float, h: float, label: str, value: str, note: str) -> None:
    pdf.setFillColor(PANEL)
    pdf.setStrokeColor(LINE)
    pdf.roundRect(x, y, w, h, 9, fill=1, stroke=1)
    pdf.setFillColor(MUTED)
    pdf.setFont("Helvetica-Bold", 7.5)
    pdf.drawString(x + 12, y + h - 17, label.upper())
    pdf.setFillColor(INK)
    pdf.setFont("Helvetica-Bold", 17)
    pdf.drawString(x + 12, y + h - 40, value)
    draw_wrapped(pdf, note, x + 12, y + 13, w - 24, font="Helvetica", size=7.5, leading=9, color=MUTED, max_lines=2)


def draw_section_title(pdf: canvas.Canvas, text: str, x: float, y: float) -> None:
    pdf.setFillColor(CYAN)
    pdf.rect(x, y - 2, 4, 17, fill=1, stroke=0)
    pdf.setFillColor(INK)
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(x + 11, y, text)


def draw_vertical_bars(
    pdf: canvas.Canvas,
    labels: list[str],
    values: list[float],
    x: float,
    y: float,
    w: float,
    h: float,
    color=BLUE,
) -> None:
    maximum = max(values) if values else 1.0
    count = max(len(values), 1)
    gap = 5
    bar_w = max(8, (w - gap * (count - 1)) / count)
    pdf.setStrokeColor(LINE)
    pdf.line(x, y, x + w, y)
    for index, (label, value) in enumerate(zip(labels, values)):
        bar_h = (value / maximum) * (h - 28) if maximum else 0
        bx = x + index * (bar_w + gap)
        pdf.setFillColor(color if index < count - 1 else CYAN)
        pdf.roundRect(bx, y + 1, bar_w, bar_h, 3, fill=1, stroke=0)
        pdf.setFillColor(MUTED)
        pdf.setFont("Helvetica", 6.5)
        pdf.drawCentredString(bx + bar_w / 2, y - 11, label)
        if index in {0, count - 1}:
            pdf.setFillColor(INK)
            pdf.setFont("Helvetica-Bold", 6.5)
            pdf.drawCentredString(bx + bar_w / 2, y + bar_h + 5, format_money(value))


def draw_horizontal_bars(
    pdf: canvas.Canvas,
    labels: list[str],
    values: list[float],
    x: float,
    y: float,
    w: float,
    bar_h: float = 16,
) -> None:
    maximum = max(values) if values else 1.0
    for index, (label, value) in enumerate(zip(labels, values)):
        yy = y - index * 35
        pdf.setFillColor(INK)
        pdf.setFont("Helvetica-Bold", 8)
        pdf.drawString(x, yy + 5, label)
        pdf.setFillColor(PANEL)
        pdf.roundRect(x + 92, yy, w - 160, bar_h, 5, fill=1, stroke=0)
        pdf.setFillColor([BLUE, CYAN, PURPLE, GREEN, AMBER][index % 5])
        pdf.roundRect(x + 92, yy, (w - 160) * value / maximum, bar_h, 5, fill=1, stroke=0)
        pdf.setFillColor(INK)
        pdf.setFont("Helvetica-Bold", 8)
        pdf.drawRightString(x + w, yy + 5, format_money(value))


def draw_table(
    pdf: canvas.Canvas,
    headers: list[str],
    rows: Iterable[list[str]],
    widths: list[float],
    x: float,
    y: float,
    row_h: float = 24,
) -> float:
    total_w = sum(widths)
    pdf.setFillColor(NAVY)
    pdf.roundRect(x, y - row_h + 4, total_w, row_h, 5, fill=1, stroke=0)
    cursor = x
    pdf.setFillColor(white)
    pdf.setFont("Helvetica-Bold", 7)
    for header, width in zip(headers, widths):
        pdf.drawString(cursor + 7, y - 11, header.upper())
        cursor += width
    y -= row_h
    for index, row in enumerate(rows):
        pdf.setFillColor(white if index % 2 == 0 else PANEL)
        pdf.rect(x, y - row_h + 4, total_w, row_h, fill=1, stroke=0)
        cursor = x
        pdf.setFillColor(INK)
        pdf.setFont("Helvetica", 7.5)
        for value, width in zip(row, widths):
            pdf.drawString(cursor + 7, y - 11, str(value)[:32])
            cursor += width
        y -= row_h
    return y


def build_pdf(
    pdf_path: Path,
    metrics: dict,
    monthly: pd.DataFrame,
    products: pd.DataFrame,
    regions: pd.DataFrame,
    channels: pd.DataFrame,
    rejection_counts: pd.DataFrame,
) -> None:
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    pdf = canvas.Canvas(str(pdf_path), pagesize=A4, pageCompression=1, invariant=1)
    pdf.setTitle("Sales Insight Audit - Synthetic Case Study")
    pdf.setAuthor("MicroStudio")
    pdf.setSubject("Reproducible synthetic sales-data cleaning and descriptive analysis proof")
    width, height = A4

    # Page 1 - executive overview.
    draw_header(pdf, "Sales Insight Audit", "Executive overview", 1)
    card_w = (width - 72 - 24) / 4
    cards = [
        ("Net revenue", format_money(metrics["net_revenue"]), "Accepted rows only"),
        ("Gross profit", format_money(metrics["gross_profit"]), f"{metrics['gross_margin_pct']:.1f}% margin"),
        ("YoY growth", f"{metrics['yoy_revenue_growth_pct']:+.1f}%", "2025 vs 2024 revenue"),
        ("Accepted rows", f"{metrics['accepted_rows']:,}", "Unique and valid orders"),
    ]
    for index, card in enumerate(cards):
        draw_card(pdf, 36 + index * (card_w + 8), height - 185, card_w, 72, *card)

    draw_section_title(pdf, "Monthly revenue - last 12 months", 36, height - 225)
    last_12 = monthly.tail(12)
    labels = [value[5:] for value in last_12["month"].tolist()]
    draw_vertical_bars(pdf, labels, last_12["net_revenue"].tolist(), 44, height - 465, width - 88, 190)

    draw_section_title(pdf, "Decision-ready findings", 36, height - 520)
    findings = [
        f"Top product: {metrics['top_product']} generated {metrics['top_product_share_pct']:.1f}% of net revenue.",
        f"Best region: {metrics['top_region']} contributed {metrics['top_region_share_pct']:.1f}% of revenue.",
        f"Online channel share reached {metrics['online_share_pct']:.1f}% across the two-year ledger.",
        f"{metrics['outlier_rows_flagged']} high-value order(s) were flagged for review, not silently removed.",
    ]
    y = height - 550
    for finding in findings:
        pdf.setFillColor(CYAN)
        pdf.circle(43, y + 2, 2.3, fill=1, stroke=0)
        y = draw_wrapped(pdf, finding, 54, y, width - 94, size=9, leading=13, color=INK) - 5
    pdf.showPage()

    # Page 2 - performance mix.
    draw_header(pdf, "Sales Insight Audit", "Product and market mix", 2)
    draw_section_title(pdf, "Product performance", 36, height - 126)
    product_rows = []
    for _, row in products.head(5).iterrows():
        product_rows.append(
            [
                row["product"],
                f"{int(row['quantity']):,}",
                format_money(row["net_revenue"]),
                format_money(row["gross_profit"]),
                f"{row['gross_margin_pct']:.1f}%",
            ]
        )
    draw_table(
        pdf,
        ["Product", "Units", "Revenue", "Profit", "Margin"],
        product_rows,
        [126, 62, 100, 100, 70],
        36,
        height - 148,
        25,
    )

    draw_section_title(pdf, "Regional revenue", 36, height - 340)
    draw_horizontal_bars(
        pdf,
        regions["region"].tolist(),
        regions["net_revenue"].tolist(),
        42,
        height - 375,
        width - 84,
    )

    draw_section_title(pdf, "Channel mix", 36, height - 540)
    channel_rows = []
    total_revenue = channels["net_revenue"].sum()
    for _, row in channels.iterrows():
        channel_rows.append(
            [
                row["channel"],
                format_money(row["net_revenue"]),
                f"{row['net_revenue'] / total_revenue * 100:.1f}%",
                f"{row['gross_margin_pct']:.1f}%",
            ]
        )
    draw_table(pdf, ["Channel", "Revenue", "Share", "Margin"], channel_rows, [130, 120, 90, 90], 36, height - 562, 27)

    pdf.setFillColor(PANEL)
    pdf.roundRect(36, 75, width - 72, 78, 8, fill=1, stroke=0)
    pdf.setFillColor(INK)
    pdf.setFont("Helvetica-Bold", 9)
    pdf.drawString(50, 132, "Interpretation boundary")
    draw_wrapped(
        pdf,
        "These are descriptive portfolio findings from fictional data. Product, region, and channel differences are not causal claims. A funded discovery milestone must freeze the client's metric, currency, return, and attribution rules before analysis.",
        50,
        114,
        width - 100,
        size=8.2,
        leading=11,
        color=MUTED,
    )
    pdf.showPage()

    # Page 3 - data quality and reconciliation.
    draw_header(pdf, "Sales Insight Audit", "Data quality and reconciliation", 3)
    quality_cards = [
        ("Input rows", f"{metrics['input_rows']:,}", "Raw fictional ledger"),
        ("Duplicates", str(metrics["duplicate_rows_removed"]), "Removed by order ID"),
        ("Rejected", str(metrics["rejected_rows"]), "Preserved with reasons"),
        ("Accepted", f"{metrics['accepted_rows']:,}", "Unique valid records"),
    ]
    for index, card in enumerate(quality_cards):
        draw_card(pdf, 36 + index * (card_w + 8), height - 185, card_w, 72, *card)

    draw_section_title(pdf, "Repair and exception ledger", 36, height - 226)
    repair_rows = [
        ["Missing unit price", str(metrics["repairs"]["missing_price_from_master"]), "Explicit product-master lookup"],
        ["Missing discount", str(metrics["repairs"]["missing_discount_to_zero"]), "Defaulted to 0 by stated rule"],
        ["Region aliases", str(metrics["repairs"]["region_alias_normalized"]), "Canonical region mapping"],
        ["Revenue outlier", str(metrics["outlier_rows_flagged"]), "Retained and flagged for review"],
    ]
    draw_table(pdf, ["Issue", "Rows", "Treatment"], repair_rows, [150, 64, 265], 36, height - 248, 28)

    draw_section_title(pdf, "Rejected-row reasons", 36, height - 410)
    reason_rows = [[row["reason"], str(int(row["rows"]))] for _, row in rejection_counts.iterrows()]
    draw_table(pdf, ["Reason", "Rows"], reason_rows, [350, 80], 36, height - 432, 27)

    pdf.setFillColor(PANEL)
    pdf.setStrokeColor(LINE)
    pdf.roundRect(36, 103, width - 72, 112, 8, fill=1, stroke=1)
    pdf.setFillColor(INK)
    pdf.setFont("Helvetica-Bold", 11)
    pdf.drawString(52, 190, "Reconciliation control")
    equation = f"{metrics['input_rows']:,} input = {metrics['accepted_rows']:,} accepted + {metrics['rejected_rows']} rejected + {metrics['duplicate_rows_removed']} duplicates"
    pdf.setFillColor(GREEN)
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(52, 161, equation)
    pdf.setFillColor(MUTED)
    pdf.setFont("Helvetica", 8.5)
    pdf.drawString(52, 139, "Accepted order IDs are unique. Revenue is calculated only after cleaning and validation.")
    pdf.drawString(52, 123, "Rejected and duplicate rows remain auditable; none are silently discarded.")
    pdf.showPage()

    # Page 4 - delivery contract and actions.
    draw_header(pdf, "Sales Insight Audit", "Actions and reproducibility", 4)
    draw_section_title(pdf, "Recommended next actions", 36, height - 126)
    actions = [
        ("1", "Confirm metric contract", "Freeze revenue, return, currency, date, discount, and customer definitions before the full run."),
        ("2", "Investigate mix shift", f"Review why {metrics['top_product']} and {metrics['top_region']} lead the portfolio before allocating spend or inventory."),
        ("3", "Review flagged orders", "Validate high-value orders against invoices or source-system records; do not delete them automatically."),
        ("4", "Operationalize reruns", "Schedule the same schema, validation, reconciliation, summaries, and brief only after source access is approved."),
    ]
    y = height - 162
    for number, title, detail in actions:
        pdf.setFillColor(NAVY)
        pdf.circle(52, y + 6, 14, fill=1, stroke=0)
        pdf.setFillColor(white)
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawCentredString(52, y + 2.5, number)
        pdf.setFillColor(INK)
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawString(79, y + 7, title)
        draw_wrapped(pdf, detail, 79, y - 8, width - 118, size=8.2, leading=10.5, color=MUTED, max_lines=2)
        y -= 74

    draw_section_title(pdf, "Reproducible delivery map", 36, height - 480)
    steps = [
        ("RAW", "raw_sales.csv"),
        ("CLEAN", "cleaned_sales.csv"),
        ("AUDIT", "rejects CSV + quality JSON"),
        ("ANALYZE", "summary CSV files"),
        ("REPORT", "PDF + manifest"),
    ]
    box_w = (width - 72 - 32) / 5
    for index, (label, detail) in enumerate(steps):
        x = 36 + index * (box_w + 8)
        pdf.setFillColor([NAVY, BLUE, CYAN, PURPLE, GREEN][index])
        pdf.roundRect(x, height - 570, box_w, 62, 7, fill=1, stroke=0)
        pdf.setFillColor(white)
        pdf.setFont("Helvetica-Bold", 8)
        pdf.drawString(x + 9, height - 530, label)
        draw_wrapped(pdf, detail, x + 9, height - 546, box_w - 18, size=6.5, leading=8, color=white, max_lines=2)

    draw_section_title(pdf, "Acceptance evidence", 36, height - 626)
    acceptance = [
        "Row-count equation balances and accepted order IDs are unique.",
        "All source-to-output transformations are explicit and rerunnable.",
        "Missing values are repaired only by approved rules; other rows are rejected with reasons.",
        "The PDF contains no external data, credential, identity, or client claim.",
    ]
    y = height - 654
    for item in acceptance:
        pdf.setFillColor(GREEN)
        pdf.circle(43, y + 2, 2.3, fill=1, stroke=0)
        y = draw_wrapped(pdf, item, 54, y, width - 94, size=8.5, leading=11, color=INK) - 4

    pdf.save()


def analyze(source_path: Path, dist_dir: Path, pdf_path: Path) -> dict:
    dist_dir.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(source_path, dtype=str, keep_default_na=False)
    input_rows = len(raw)

    duplicate_mask = raw.duplicated(subset=["order_id"], keep="first")
    duplicates = raw.loc[duplicate_mask].copy()
    duplicates["reject_reason"] = "duplicate_order_id"
    working = raw.loc[~duplicate_mask].copy()

    original_region = working["region"].astype(str)
    working["region"] = original_region.map(canonical_region)
    region_repairs = int((working["region"] != original_region.str.strip()).sum())

    working["order_date_parsed"] = pd.to_datetime(working["order_date"], errors="coerce")
    working["quantity_num"] = pd.to_numeric(working["quantity"], errors="coerce")
    working["unit_price_num"] = pd.to_numeric(working["unit_price"], errors="coerce")
    working["unit_cost_num"] = pd.to_numeric(working["unit_cost"], errors="coerce")
    working["discount_num"] = pd.to_numeric(working["discount_rate"], errors="coerce")

    valid_product = working["product"].isin(PRODUCT_MASTER)
    missing_price = working["unit_price_num"].isna() & valid_product
    working.loc[missing_price, "unit_price_num"] = working.loc[missing_price, "product"].map(
        {name: details["price"] for name, details in PRODUCT_MASTER.items()}
    )
    missing_discount = working["discount_num"].isna()
    working.loc[missing_discount, "discount_num"] = 0.0

    reasons: list[list[str]] = [[] for _ in range(len(working))]
    for pos, (_, row) in enumerate(working.iterrows()):
        if pd.isna(row["order_date_parsed"]):
            reasons[pos].append("invalid_order_date")
        if pd.isna(row["quantity_num"]) or float(row["quantity_num"]) <= 0:
            reasons[pos].append("nonpositive_or_invalid_quantity")
        if row["product"] not in PRODUCT_MASTER:
            reasons[pos].append("missing_or_unknown_product")
        if pd.isna(row["unit_price_num"]) or float(row["unit_price_num"]) <= 0:
            reasons[pos].append("missing_or_invalid_unit_price")
        if pd.isna(row["unit_cost_num"]) or float(row["unit_cost_num"]) < 0:
            reasons[pos].append("missing_or_invalid_unit_cost")
        if pd.isna(row["discount_num"]) or not 0 <= float(row["discount_num"]) < 1:
            reasons[pos].append("invalid_discount_rate")

    working["reject_reason"] = [";".join(values) for values in reasons]
    rejected = working.loc[working["reject_reason"] != ""].copy()
    accepted = working.loc[working["reject_reason"] == ""].copy()

    accepted["order_date"] = accepted["order_date_parsed"].dt.strftime("%Y-%m-%d")
    accepted["quantity"] = accepted["quantity_num"].astype(int)
    accepted["unit_price"] = accepted["unit_price_num"].round(2)
    accepted["unit_cost"] = accepted["unit_cost_num"].round(2)
    accepted["discount_rate"] = accepted["discount_num"].round(4)
    accepted["net_revenue"] = (
        accepted["quantity"] * accepted["unit_price"] * (1 - accepted["discount_rate"])
    ).round(2)
    accepted["cost_of_goods"] = (accepted["quantity"] * accepted["unit_cost"]).round(2)
    accepted["gross_profit"] = (accepted["net_revenue"] - accepted["cost_of_goods"]).round(2)

    q1 = accepted["net_revenue"].quantile(0.25)
    q3 = accepted["net_revenue"].quantile(0.75)
    outlier_threshold = q3 + 1.5 * (q3 - q1)
    accepted["revenue_outlier"] = accepted["net_revenue"] > outlier_threshold
    accepted = accepted.sort_values(["order_date", "order_id"]).reset_index(drop=True)

    rejected_rows = pd.concat(
        [
            duplicates.assign(reject_reason="duplicate_order_id"),
            rejected[raw.columns.tolist() + ["reject_reason"]],
        ],
        ignore_index=True,
    )

    monthly = (
        accepted.assign(month=pd.to_datetime(accepted["order_date"]).dt.to_period("M").astype(str))
        .groupby("month", as_index=False)
        .agg(orders=("order_id", "count"), units=("quantity", "sum"), net_revenue=("net_revenue", "sum"), gross_profit=("gross_profit", "sum"))
    )
    products = (
        accepted.groupby("product", as_index=False)
        .agg(orders=("order_id", "count"), quantity=("quantity", "sum"), net_revenue=("net_revenue", "sum"), gross_profit=("gross_profit", "sum"))
        .sort_values("net_revenue", ascending=False)
    )
    products["gross_margin_pct"] = products["gross_profit"] / products["net_revenue"] * 100
    regions = (
        accepted.groupby("region", as_index=False)
        .agg(orders=("order_id", "count"), net_revenue=("net_revenue", "sum"), gross_profit=("gross_profit", "sum"))
        .sort_values("net_revenue", ascending=False)
    )
    regions["gross_margin_pct"] = regions["gross_profit"] / regions["net_revenue"] * 100
    channels = (
        accepted.groupby("channel", as_index=False)
        .agg(orders=("order_id", "count"), net_revenue=("net_revenue", "sum"), gross_profit=("gross_profit", "sum"))
        .sort_values("net_revenue", ascending=False)
    )
    channels["gross_margin_pct"] = channels["gross_profit"] / channels["net_revenue"] * 100

    revenue_by_year = accepted.assign(year=pd.to_datetime(accepted["order_date"]).dt.year).groupby("year")["net_revenue"].sum()
    revenue_2024 = float(revenue_by_year.get(2024, 0.0))
    revenue_2025 = float(revenue_by_year.get(2025, 0.0))
    net_revenue = float(accepted["net_revenue"].sum())
    gross_profit = float(accepted["gross_profit"].sum())
    top_product = products.iloc[0]
    top_region = regions.iloc[0]
    online_revenue = float(channels.loc[channels["channel"] == "Online", "net_revenue"].sum())

    reason_counts = (
        rejected["reject_reason"].value_counts().rename_axis("reason").reset_index(name="rows")
    )
    metrics = {
        "built_at": BUILT_AT,
        "input_rows": input_rows,
        "duplicate_rows_removed": int(duplicate_mask.sum()),
        "rejected_rows": len(rejected),
        "accepted_rows": len(accepted),
        "accepted_unique_order_ids": int(accepted["order_id"].nunique()),
        "reconciliation_ok": input_rows == len(accepted) + len(rejected) + int(duplicate_mask.sum()),
        "repairs": {
            "missing_price_from_master": int(missing_price.sum()),
            "missing_discount_to_zero": int(missing_discount.sum()),
            "region_alias_normalized": region_repairs,
        },
        "outlier_threshold": round(float(outlier_threshold), 2),
        "outlier_rows_flagged": int(accepted["revenue_outlier"].sum()),
        "net_revenue": round(net_revenue, 2),
        "gross_profit": round(gross_profit, 2),
        "gross_margin_pct": round(gross_profit / net_revenue * 100, 2),
        "revenue_2024": round(revenue_2024, 2),
        "revenue_2025": round(revenue_2025, 2),
        "yoy_revenue_growth_pct": round((revenue_2025 / revenue_2024 - 1) * 100, 2),
        "top_product": str(top_product["product"]),
        "top_product_share_pct": round(float(top_product["net_revenue"]) / net_revenue * 100, 2),
        "top_region": str(top_region["region"]),
        "top_region_share_pct": round(float(top_region["net_revenue"]) / net_revenue * 100, 2),
        "online_share_pct": round(online_revenue / net_revenue * 100, 2),
    }

    clean_columns = [
        "order_id",
        "order_date",
        "product",
        "region",
        "channel",
        "customer_segment",
        "quantity",
        "unit_price",
        "unit_cost",
        "discount_rate",
        "currency",
        "net_revenue",
        "cost_of_goods",
        "gross_profit",
        "revenue_outlier",
    ]
    accepted[clean_columns].to_csv(dist_dir / "cleaned_sales.csv", index=False, lineterminator="\n")
    rejected_rows.to_csv(dist_dir / "rejected_rows.csv", index=False, lineterminator="\n")
    monthly.to_csv(dist_dir / "monthly_summary.csv", index=False, float_format="%.2f", lineterminator="\n")
    products.to_csv(dist_dir / "product_summary.csv", index=False, float_format="%.2f", lineterminator="\n")
    regions.to_csv(dist_dir / "region_summary.csv", index=False, float_format="%.2f", lineterminator="\n")
    channels.to_csv(dist_dir / "channel_summary.csv", index=False, float_format="%.2f", lineterminator="\n")
    (dist_dir / "data_quality_report.json").write_text(json.dumps(metrics, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    build_pdf(pdf_path, metrics, monthly, products, regions, channels, reason_counts)

    output_files = sorted(
        path
        for path in dist_dir.iterdir()
        if path.is_file() and path.name != "analysis_manifest.json"
    )
    manifest = {
        "built_at": BUILT_AT,
        "source": {"path": source_path.name, "sha256": sha256(source_path)},
        "report": {"path": pdf_path.name, "sha256": sha256(pdf_path)},
        "outputs": [{"path": path.name, "sha256": sha256(path)} for path in output_files],
        "privacy": "deterministic fictional data only",
        "reconciliation_ok": metrics["reconciliation_ok"],
    }
    (dist_dir / "analysis_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return metrics


if __name__ == "__main__":
    base = Path(__file__).resolve().parent
    workspace = base.parents[3]
    analyze(
        base / "fixtures" / "raw_sales.csv",
        base / "dist",
        workspace / "output" / "pdf" / "Sales_Insight_Audit_Case_Study.pdf",
    )
