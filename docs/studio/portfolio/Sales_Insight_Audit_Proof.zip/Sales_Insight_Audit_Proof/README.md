# Sales Insight Audit - Synthetic Reproducible Proof

This portfolio sample turns a fictional raw sales ledger into a cleaned CSV, rejected-row ledger, metric summaries, data-quality report, reproducibility manifest, and four-page decision brief.

No client data, account data, credentials, external API, or private business information is used. The source contains deterministic defects so the audit can prove what was repaired, rejected, deduplicated, and retained.

## Known fixture contract

- 1,206 input rows;
- 6 exact duplicate order IDs removed;
- 5 invalid rows rejected;
- 1,195 accepted rows with unique order IDs;
- 4 missing prices filled from the explicit fictional product master;
- 3 missing discounts defaulted to zero;
- 3 region aliases normalized;
- one valid high-value order retained and flagged as an outlier.

## Reproduce

Use the bundled Codex Python runtime because it includes pandas and ReportLab:

```bash
PY=/Users/yuhenghe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
"$PY" build_proof.py
"$PY" -m unittest discover -s tests -p 'test_*.py'
```

The build writes analysis files under `dist/`, the final PDF to `output/pdf/Sales_Insight_Audit_Case_Study.pdf`, and the deterministic portfolio archive to `output/portfolio/Sales_Insight_Audit_Proof.zip`.

## Scope boundary

This sample demonstrates a data contract, cleaning audit, descriptive analysis, reconciliation, and decision brief. It does not claim access to a client's data or prove causality, forecasting accuracy, or a previously completed client engagement. Real definitions, currency rules, outlier treatment, and business questions must be approved in a funded data-audit milestone.
