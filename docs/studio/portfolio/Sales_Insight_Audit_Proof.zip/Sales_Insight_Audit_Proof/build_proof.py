#!/usr/bin/env python3
"""Build and package the deterministic Sales Insight Audit proof."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

from analyze_sales import analyze
from generate_fixture import write_fixture


BASE = Path(__file__).resolve().parent
WORKSPACE = BASE.parents[3]
FIXED_ZIP_TIME = (2026, 7, 17, 4, 0, 0)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def add_file(archive: zipfile.ZipFile, path: Path, arcname: str) -> None:
    info = zipfile.ZipInfo(arcname, date_time=FIXED_ZIP_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, path.read_bytes())


def main() -> int:
    source = BASE / "fixtures" / "raw_sales.csv"
    dist = BASE / "dist"
    report = WORKSPACE / "output" / "pdf" / "Sales_Insight_Audit_Case_Study.pdf"
    portfolio = WORKSPACE / "output" / "portfolio" / "Sales_Insight_Audit_Proof.zip"

    write_fixture(source)
    metrics = analyze(source, dist, report)
    portfolio.parent.mkdir(parents=True, exist_ok=True)

    entries = [
        (BASE / "README.md", "Sales_Insight_Audit_Proof/README.md"),
        (BASE / "generate_fixture.py", "Sales_Insight_Audit_Proof/generate_fixture.py"),
        (BASE / "analyze_sales.py", "Sales_Insight_Audit_Proof/analyze_sales.py"),
        (BASE / "build_proof.py", "Sales_Insight_Audit_Proof/build_proof.py"),
        (BASE / "tests" / "test_sales_analysis.py", "Sales_Insight_Audit_Proof/tests/test_sales_analysis.py"),
        (source, "Sales_Insight_Audit_Proof/fixtures/raw_sales.csv"),
        (report, "Sales_Insight_Audit_Proof/Sales_Insight_Audit_Case_Study.pdf"),
    ]
    entries.extend(
        (path, f"Sales_Insight_Audit_Proof/dist/{path.name}")
        for path in sorted(dist.iterdir())
        if path.is_file()
    )

    with zipfile.ZipFile(portfolio, "w") as archive:
        for path, arcname in sorted(entries, key=lambda item: item[1]):
            add_file(archive, path, arcname)

    print(
        json.dumps(
            {
                "metrics": metrics,
                "report": str(report.relative_to(WORKSPACE)),
                "report_sha256": digest(report),
                "portfolio": str(portfolio.relative_to(WORKSPACE)),
                "portfolio_sha256": digest(portfolio),
                "zip_entries": len(entries),
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
