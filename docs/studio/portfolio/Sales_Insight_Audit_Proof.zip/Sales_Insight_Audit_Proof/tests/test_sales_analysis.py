from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))

from analyze_sales import analyze  # noqa: E402
from generate_fixture import write_fixture  # noqa: E402


class SalesInsightTest(unittest.TestCase):
    def test_fixture_and_reconciliation_contract(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "raw_sales.csv"
            dist = root / "dist"
            pdf = root / "report.pdf"
            write_fixture(source)
            result = analyze(source, dist, pdf)

            self.assertEqual(result["input_rows"], 1206)
            self.assertEqual(result["duplicate_rows_removed"], 6)
            self.assertEqual(result["rejected_rows"], 5)
            self.assertEqual(result["accepted_rows"], 1195)
            self.assertEqual(result["accepted_rows"] + result["rejected_rows"] + result["duplicate_rows_removed"], result["input_rows"])
            self.assertEqual(result["repairs"]["missing_price_from_master"], 4)
            self.assertEqual(result["repairs"]["missing_discount_to_zero"], 3)
            self.assertEqual(result["repairs"]["region_alias_normalized"], 3)
            self.assertGreaterEqual(result["outlier_rows_flagged"], 1)
            self.assertTrue(pdf.is_file())
            self.assertGreater(pdf.stat().st_size, 10_000)

            report = json.loads((dist / "data_quality_report.json").read_text())
            self.assertTrue(report["reconciliation_ok"])
            self.assertEqual(report["accepted_unique_order_ids"], 1195)

    def test_build_is_deterministic_for_core_metrics(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "raw_sales.csv"
            write_fixture(source)
            first = analyze(source, root / "a", root / "a.pdf")
            second = analyze(source, root / "b", root / "b.pdf")
            for key in (
                "input_rows",
                "accepted_rows",
                "rejected_rows",
                "duplicate_rows_removed",
                "net_revenue",
                "gross_profit",
                "outlier_rows_flagged",
            ):
                self.assertEqual(first[key], second[key])


if __name__ == "__main__":
    unittest.main()
