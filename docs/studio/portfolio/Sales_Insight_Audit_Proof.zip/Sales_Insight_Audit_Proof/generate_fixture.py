#!/usr/bin/env python3
"""Generate a deterministic fictional sales ledger with known quality defects."""

from __future__ import annotations

import csv
import random
from datetime import date
from pathlib import Path


SEED = 20260717
PRODUCTS = {
    "Atlas Pro": {"price": 249.0, "cost": 141.0},
    "Nova Lite": {"price": 119.0, "cost": 61.0},
    "Orbit Kit": {"price": 179.0, "cost": 98.0},
    "Pulse Mini": {"price": 79.0, "cost": 36.0},
    "Vertex Hub": {"price": 329.0, "cost": 190.0},
}
REGIONS = ["North", "South", "East", "West"]
CHANNELS = ["Direct", "Online", "Partner"]
SEGMENTS = ["SMB", "Mid-market", "Enterprise"]
FIELDS = [
    "order_id",
    "order_date",
    "product",
    "region",
    "channel",
    "customer_segment",
    "quantity",
    "unit_price",
    "unit_cost",
    "discount_rate",
    "currency",
]


def month_start(index: int) -> date:
    year = 2024 + index // 12
    month = index % 12 + 1
    return date(year, month, 1)


def generate_rows() -> list[dict[str, str]]:
    rng = random.Random(SEED)
    product_names = list(PRODUCTS)
    rows: list[dict[str, str]] = []

    for index in range(1200):
        month_index = index % 24
        start = month_start(month_index)
        product = rng.choices(product_names, weights=[19, 27, 20, 23, 11], k=1)[0]
        region = rng.choices(REGIONS, weights=[28, 22, 31, 19], k=1)[0]
        channel = rng.choices(CHANNELS, weights=[34, 45, 21], k=1)[0]
        segment = rng.choices(SEGMENTS, weights=[50, 34, 16], k=1)[0]
        day = rng.randint(1, 28)
        quantity = rng.randint(1, 9)
        if start.year == 2025:
            quantity += rng.choices([0, 1, 2], weights=[45, 40, 15], k=1)[0]
        if start.month in {10, 11, 12}:
            quantity += rng.choices([0, 1, 2], weights=[35, 45, 20], k=1)[0]

        base = PRODUCTS[product]
        unit_price = base["price"] * rng.uniform(0.985, 1.025)
        unit_cost = base["cost"] * rng.uniform(0.97, 1.035)
        discount = rng.choices([0.0, 0.03, 0.05, 0.08, 0.12], weights=[38, 18, 25, 14, 5], k=1)[0]
        rows.append(
            {
                "order_id": f"ORD-{index + 1:05d}",
                "order_date": f"{start.year:04d}-{start.month:02d}-{day:02d}",
                "product": product,
                "region": region,
                "channel": channel,
                "customer_segment": segment,
                "quantity": str(quantity),
                "unit_price": f"{unit_price:.2f}",
                "unit_cost": f"{unit_cost:.2f}",
                "discount_rate": f"{discount:.2f}",
                "currency": "USD",
            }
        )

    # Known repair cases.
    for idx in (10, 11, 12, 13):
        rows[idx]["unit_price"] = ""
    rows[20]["region"] = " north "
    rows[21]["region"] = "NORTH"
    rows[22]["region"] = "e."
    for idx in (70, 71, 72):
        rows[idx]["discount_rate"] = ""

    # Known rejection cases.
    rows[30]["quantity"] = "-2"
    rows[31]["quantity"] = "0"
    rows[40]["product"] = ""
    rows[41]["product"] = "Unknown Bundle"
    rows[50]["order_date"] = "2025-13-40"

    # Valid high-value order used to prove outlier flagging without deletion.
    rows[60]["quantity"] = "75"

    # Six exact duplicate order IDs/rows.
    rows.extend(dict(row) for row in rows[:6])
    return rows


def write_fixture(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(generate_rows())


if __name__ == "__main__":
    write_fixture(Path(__file__).with_name("fixtures") / "raw_sales.csv")
