# Evidence Contract Prototype Proof

This self-contained package demonstrates a bounded evidence contract for a synthetic data interface. It does not contain customer data and does not claim model accuracy, compliance certification or production readiness.

The evaluator verifies that every acceptance check names known evidence, rejects duplicate source identifiers, counts unresolved issues and returns a machine-readable `PASS` or `REVIEW` release state. Explicit transformations are recorded so hidden coercions cannot silently pass.

Run the included assertions after unzipping:

```sh
node verify.mjs
```

Expected synthetic results:

- `review-receipt.json`: 5 sources, 4 checks, 1 open issue, 0 silent coercions, `REVIEW`.
- `pass-receipt.json`: 5 sources, 4 checks, 0 open issues, 0 silent coercions, `PASS`.
