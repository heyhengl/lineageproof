import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { evaluateEvidenceReceipt } from "./evaluate-evidence.mjs";

async function fixture(name) {
  return JSON.parse(await readFile(new URL(`./fixtures/${name}`, import.meta.url), "utf8"));
}

const review = evaluateEvidenceReceipt(await fixture("review-receipt.json"));
assert.deepEqual(review, {
  artifact_id: "synthetic-invoice-summary-v1",
  source_count: 5,
  check_count: 4,
  open_issue_count: 1,
  silent_coercion_count: 0,
  release_state: "REVIEW",
});

const approved = evaluateEvidenceReceipt(await fixture("pass-receipt.json"));
assert.equal(approved.release_state, "PASS");
assert.equal(approved.open_issue_count, 0);
assert.equal(approved.silent_coercion_count, 0);

const unknown = await fixture("pass-receipt.json");
unknown.acceptance_checks[0].source_refs = ["missing-source"];
assert.throws(() => evaluateEvidenceReceipt(unknown), /unknown source/);

console.log(JSON.stringify({ review, approved, invalid_reference_rejected: true }, null, 2));
