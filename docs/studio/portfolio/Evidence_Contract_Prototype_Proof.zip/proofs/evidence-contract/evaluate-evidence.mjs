const allowedStates = new Set(["PASS", "REVIEW"]);

function assertNonEmptyString(value, field) {
  if (typeof value !== "string" || value.trim() === "") throw new Error(`${field} must be a non-empty string`);
}

export function evaluateEvidenceReceipt(receipt) {
  if (!receipt || typeof receipt !== "object" || Array.isArray(receipt)) throw new Error("receipt must be an object");
  assertNonEmptyString(receipt.artifact_id, "artifact_id");
  if (!Array.isArray(receipt.sources) || receipt.sources.length === 0) throw new Error("sources must be a non-empty array");
  if (!Array.isArray(receipt.acceptance_checks) || receipt.acceptance_checks.length === 0) throw new Error("acceptance_checks must be a non-empty array");
  if (!Array.isArray(receipt.issues)) throw new Error("issues must be an array");
  if (!Array.isArray(receipt.transformations)) throw new Error("transformations must be an array");

  const sourceIds = new Set();
  for (const [index, source] of receipt.sources.entries()) {
    assertNonEmptyString(source?.id, `sources[${index}].id`);
    assertNonEmptyString(source?.label, `sources[${index}].label`);
    if (sourceIds.has(source.id)) throw new Error(`duplicate source id: ${source.id}`);
    sourceIds.add(source.id);
  }

  for (const [index, check] of receipt.acceptance_checks.entries()) {
    assertNonEmptyString(check?.id, `acceptance_checks[${index}].id`);
    if (!allowedStates.has(check?.state)) throw new Error(`invalid check state: ${check?.state}`);
    if (!Array.isArray(check.source_refs) || check.source_refs.length === 0) throw new Error(`check ${check.id} must name evidence`);
    for (const sourceRef of check.source_refs) {
      if (!sourceIds.has(sourceRef)) throw new Error(`check ${check.id} references unknown source: ${sourceRef}`);
    }
  }

  for (const [index, issue] of receipt.issues.entries()) {
    assertNonEmptyString(issue?.id, `issues[${index}].id`);
    if (!allowedStates.has(issue?.state)) throw new Error(`invalid issue state: ${issue?.state}`);
  }

  const openIssueCount = receipt.issues.filter((issue) => issue.state === "REVIEW").length;
  const reviewCheckCount = receipt.acceptance_checks.filter((check) => check.state === "REVIEW").length;
  const silentCoercionCount = receipt.transformations.filter((entry) => entry.explicit !== true).length;

  return {
    artifact_id: receipt.artifact_id,
    source_count: sourceIds.size,
    check_count: receipt.acceptance_checks.length,
    open_issue_count: openIssueCount,
    silent_coercion_count: silentCoercionCount,
    release_state: openIssueCount > 0 || reviewCheckCount > 0 || silentCoercionCount > 0 ? "REVIEW" : "PASS",
  };
}
