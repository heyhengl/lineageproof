# Synthetic Webhook Reliability Proof

This small, dependency-free Node.js proof demonstrates the reliability contract behind a webhook-to-ERP integration. It uses fictional Australian phone numbers and never contacts VOIPline, an ERP, an SMS service, or any external endpoint.

## What it proves

- HMAC verification before an event is accepted.
- Australian phone normalization into E.164 for deterministic customer matching.
- Idempotent event ingestion and call-log upserts.
- A visible unmatched-call queue instead of silent record loss.
- A transactional outbox entry for a missed-call notification without sending a real message.
- Bounded rejection records that store a payload hash and controlled reason, not a raw webhook body.
- Input/processed/duplicate/rejected reconciliation in a machine-readable run report.

The proof is intentionally vendor- and language-independent. A production client implementation can use PHP 8 and MySQL after the ERP schema, VOIPline authentication method, webhook payloads, retry contract, and notification provider are approved. This package is not evidence of access to VOIPline or of a previous telephony engagement.

## Run

```bash
npm run build
npm test
```

Requires Node.js 22.5+ because it uses the built-in `node:sqlite` module. No package installation is required.

## Expected synthetic result

- 6 delivery attempts reconciled as 4 processed, 1 duplicate, and 1 rejected signature.
- 3 call records: 2 matched and 1 unmatched.
- 1 missed-call notification staged in the outbox; 0 messages sent.
- A voicemail update reuses the existing call record and does not create another notification.

## Production boundary

- Secrets belong in a managed environment or secret store, never in source or logs.
- Real webhook signatures and replay windows must follow the provider's published contract.
- Notifications and reporting are separate funded milestones after the call-ingestion slice is accepted.
- The synthetic SQLite schema is an executable audit model, not a drop-in replacement for the client's MySQL schema.
