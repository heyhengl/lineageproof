import assert from "node:assert/strict";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { WebhookPipeline, normalizePhone, signEvent } from "../src/webhook_pipeline.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const secret = "unit-test-secret";

function createPipeline() {
  const pipeline = new WebhookPipeline({
    schemaPath: path.join(root, "schema.sql"),
    secret,
    now: () => "2026-07-17T00:05:00.000Z",
  });
  pipeline.addCustomers([
    { customer_id: "CUST-1", phone: "0412 345 678", email: "one@example.invalid" },
    { customer_id: "CUST-2", phone: "02 5555 0100", email: "two@example.invalid" },
  ]);
  return pipeline;
}

function event(overrides = {}) {
  return {
    event_id: "EVT-1",
    call_id: "CALL-1",
    type: "completed",
    direction: "inbound",
    remote_phone: "0412 345 678",
    occurred_at: "2026-07-17T00:00:00Z",
    ...overrides,
  };
}

test("normalizes Australian mobile and landline numbers into E.164", () => {
  assert.equal(normalizePhone("0412 345 678"), "+61412345678");
  assert.equal(normalizePhone("02 5555 0100"), "+61255550100");
  assert.equal(normalizePhone("+61 (2) 5555 0100"), "+61255550100");
});

test("accepts a signed event once and treats redelivery as a duplicate", (t) => {
  const pipeline = createPipeline();
  t.after(() => pipeline.close());
  const payload = event();
  assert.equal(pipeline.ingest(payload, signEvent(payload, secret)).outcome, "processed");
  assert.equal(pipeline.ingest(payload, signEvent(payload, secret)).outcome, "duplicate");
  assert.equal(pipeline.count("webhook_events"), 1);
  assert.equal(pipeline.count("call_logs"), 1);
});

test("rejects a bad signature without storing a raw webhook event", (t) => {
  const pipeline = createPipeline();
  t.after(() => pipeline.close());
  const result = pipeline.ingest(event(), "0".repeat(64));
  assert.deepEqual(result, { outcome: "rejected", reason: "signature_invalid" });
  assert.equal(pipeline.count("webhook_events"), 0);
  assert.equal(pipeline.count("rejected_events"), 1);
});

test("routes an unknown phone to a visible unmatched queue", (t) => {
  const pipeline = createPipeline();
  t.after(() => pipeline.close());
  const payload = event({ remote_phone: "0499 999 999" });
  const result = pipeline.ingest(payload, signEvent(payload, secret));
  assert.equal(result.matched, false);
  assert.equal(pipeline.count("unmatched_calls"), 1);
  assert.equal(pipeline.getCall("CALL-1").customer_id, null);
});

test("stages one missed-call notification and a voicemail updates the same call", (t) => {
  const pipeline = createPipeline();
  t.after(() => pipeline.close());
  const missed = event({ event_id: "EVT-MISSED", call_id: "CALL-MISSED", type: "missed_call", remote_phone: "02 5555 0100" });
  const voicemail = event({ event_id: "EVT-VM", call_id: "CALL-MISSED", type: "voicemail", remote_phone: "+61 2 5555 0100", occurred_at: "2026-07-17T00:01:00Z" });
  pipeline.ingest(missed, signEvent(missed, secret));
  pipeline.ingest(voicemail, signEvent(voicemail, secret));
  assert.equal(pipeline.getCall("CALL-MISSED").status, "voicemail");
  assert.equal(pipeline.getOutbox().length, 1);
  assert.equal(pipeline.getOutbox()[0].status, "pending");
});

test("does not stage notifications for an unmatched missed call", (t) => {
  const pipeline = createPipeline();
  t.after(() => pipeline.close());
  const payload = event({ type: "missed_call", remote_phone: "0499 999 999" });
  pipeline.ingest(payload, signEvent(payload, secret));
  assert.equal(pipeline.count("notification_outbox"), 0);
  assert.equal(pipeline.summary().notifications_sent, 0);
});
