PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS customers (
  customer_id TEXT PRIMARY KEY,
  phone_e164 TEXT NOT NULL UNIQUE,
  email TEXT
);

CREATE TABLE IF NOT EXISTS webhook_events (
  event_id TEXT PRIMARY KEY,
  call_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  direction TEXT NOT NULL,
  remote_phone_e164 TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  received_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS call_logs (
  call_id TEXT PRIMARY KEY,
  customer_id TEXT REFERENCES customers(customer_id),
  direction TEXT NOT NULL,
  status TEXT NOT NULL,
  remote_phone_e164 TEXT NOT NULL,
  started_at TEXT NOT NULL,
  last_event_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS unmatched_calls (
  call_id TEXT PRIMARY KEY REFERENCES call_logs(call_id),
  remote_phone_e164 TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS notification_outbox (
  outbox_key TEXT PRIMARY KEY,
  call_id TEXT NOT NULL REFERENCES call_logs(call_id),
  customer_id TEXT NOT NULL REFERENCES customers(customer_id),
  channel TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  attempts INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rejected_events (
  event_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  received_at TEXT NOT NULL
);
