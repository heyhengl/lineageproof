import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { WebhookPipeline, signEvent } from "./webhook_pipeline.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const dist = path.join(root, "dist");
const dbPath = path.join(dist, "webhook_audit.sqlite");
const secret = "synthetic-demo-secret-not-for-production";

fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });

const customers = JSON.parse(fs.readFileSync(path.join(root, "fixtures", "customers.json"), "utf8"));
const attempts = JSON.parse(fs.readFileSync(path.join(root, "fixtures", "events.json"), "utf8"));
const fixedNow = () => "2026-07-17T00:05:00.000Z";
const pipeline = new WebhookPipeline({
  databasePath: dbPath,
  schemaPath: path.join(root, "schema.sql"),
  secret,
  now: fixedNow,
});

pipeline.addCustomers(customers);
const outcomes = attempts.map(({ event, signature_mode }) => {
  const signature = signature_mode === "valid" ? signEvent(event, secret) : "0".repeat(64);
  return pipeline.ingest(event, signature);
});

const outcomeCounts = outcomes.reduce((counts, outcome) => {
  counts[outcome.outcome] = (counts[outcome.outcome] ?? 0) + 1;
  return counts;
}, {});
const summary = pipeline.summary();
const report = {
  proof: "synthetic_webhook_reliability",
  generated_at: fixedNow(),
  external_calls: 0,
  input_attempts: attempts.length,
  outcomes: {
    processed: outcomeCounts.processed ?? 0,
    duplicate: outcomeCounts.duplicate ?? 0,
    rejected: outcomeCounts.rejected ?? 0,
  },
  reconciliation_ok:
    attempts.length === (outcomeCounts.processed ?? 0) + (outcomeCounts.duplicate ?? 0) + (outcomeCounts.rejected ?? 0),
  ...summary,
  boundaries: [
    "Fictional data only",
    "No VOIPline or ERP access",
    "No messages sent",
    "Production PHP/MySQL mapping requires funded discovery",
  ],
};

fs.writeFileSync(path.join(dist, "run_report.json"), `${JSON.stringify(report, null, 2)}\n`);
pipeline.close();
console.log(JSON.stringify(report, null, 2));
