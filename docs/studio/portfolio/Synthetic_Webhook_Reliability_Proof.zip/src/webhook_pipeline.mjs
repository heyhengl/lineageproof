import crypto from "node:crypto";
import fs from "node:fs";
import { DatabaseSync } from "node:sqlite";

const EVENT_TYPES = new Set(["ringing", "answered", "completed", "missed_call", "voicemail"]);
const DIRECTIONS = new Set(["inbound", "outbound"]);

export function normalizePhone(value, defaultCountry = "AU") {
  if (typeof value !== "string" || value.trim() === "") {
    throw new Error("phone_missing");
  }

  const trimmed = value.trim();
  const hasPlus = trimmed.startsWith("+");
  let digits = trimmed.replace(/\D/g, "");

  if (digits.startsWith("00")) {
    digits = digits.slice(2);
    return validateE164(`+${digits}`);
  }

  if (hasPlus) {
    return validateE164(`+${digits}`);
  }

  if (defaultCountry === "AU") {
    if (digits.startsWith("0")) {
      return validateE164(`+61${digits.slice(1)}`);
    }
    if (digits.startsWith("61")) {
      return validateE164(`+${digits}`);
    }
  }

  throw new Error("phone_country_code_required");
}

function validateE164(value) {
  if (!/^\+[1-9]\d{7,14}$/.test(value)) {
    throw new Error("phone_not_e164");
  }
  return value;
}

export function signEvent(event, secret) {
  return crypto.createHmac("sha256", secret).update(JSON.stringify(event)).digest("hex");
}

function hashPayload(event) {
  return crypto.createHash("sha256").update(JSON.stringify(event)).digest("hex");
}

function verifySignature(event, signature, secret) {
  if (typeof signature !== "string" || !/^[0-9a-f]{64}$/i.test(signature)) {
    return false;
  }
  const expected = Buffer.from(signEvent(event, secret), "hex");
  const supplied = Buffer.from(signature, "hex");
  return supplied.length === expected.length && crypto.timingSafeEqual(supplied, expected);
}

function assertEvent(event) {
  for (const key of ["event_id", "call_id", "type", "direction", "remote_phone", "occurred_at"]) {
    if (typeof event?.[key] !== "string" || event[key].trim() === "") {
      throw new Error(`invalid_${key}`);
    }
  }
  if (!EVENT_TYPES.has(event.type)) throw new Error("invalid_type");
  if (!DIRECTIONS.has(event.direction)) throw new Error("invalid_direction");
  if (Number.isNaN(Date.parse(event.occurred_at))) throw new Error("invalid_occurred_at");
}

export class WebhookPipeline {
  constructor({ databasePath = ":memory:", schemaPath, secret, defaultCountry = "AU", now = () => new Date().toISOString() }) {
    if (!secret) throw new Error("secret_required");
    this.db = new DatabaseSync(databasePath);
    this.db.exec(fs.readFileSync(schemaPath, "utf8"));
    this.secret = secret;
    this.defaultCountry = defaultCountry;
    this.now = now;
  }

  addCustomers(customers) {
    const statement = this.db.prepare(`
      INSERT INTO customers (customer_id, phone_e164, email)
      VALUES (?, ?, ?)
      ON CONFLICT(customer_id) DO UPDATE SET
        phone_e164 = excluded.phone_e164,
        email = excluded.email
    `);
    for (const customer of customers) {
      statement.run(customer.customer_id, normalizePhone(customer.phone, this.defaultCountry), customer.email ?? null);
    }
  }

  ingest(event, signature) {
    const receivedAt = this.now();
    const payloadHash = hashPayload(event);

    if (!verifySignature(event, signature, this.secret)) {
      this.reject(event?.event_id ?? "unknown", "signature_invalid", payloadHash, receivedAt);
      return { outcome: "rejected", reason: "signature_invalid" };
    }

    try {
      assertEvent(event);
    } catch (error) {
      this.reject(event?.event_id ?? "unknown", error.message, payloadHash, receivedAt);
      return { outcome: "rejected", reason: error.message };
    }

    const existing = this.db.prepare("SELECT event_id FROM webhook_events WHERE event_id = ?").get(event.event_id);
    if (existing) return { outcome: "duplicate", event_id: event.event_id };

    let phone;
    try {
      phone = normalizePhone(event.remote_phone, this.defaultCountry);
    } catch (error) {
      this.reject(event.event_id, error.message, payloadHash, receivedAt);
      return { outcome: "rejected", reason: error.message };
    }

    this.db.exec("BEGIN IMMEDIATE");
    try {
      const customer = this.db.prepare("SELECT customer_id FROM customers WHERE phone_e164 = ?").get(phone);
      const customerId = customer?.customer_id ?? null;

      this.db.prepare(`
        INSERT INTO webhook_events
          (event_id, call_id, event_type, direction, remote_phone_e164, payload_hash, occurred_at, received_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(event.event_id, event.call_id, event.type, event.direction, phone, payloadHash, event.occurred_at, receivedAt);

      this.db.prepare(`
        INSERT INTO call_logs
          (call_id, customer_id, direction, status, remote_phone_e164, started_at, last_event_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(call_id) DO UPDATE SET
          customer_id = COALESCE(call_logs.customer_id, excluded.customer_id),
          direction = excluded.direction,
          status = excluded.status,
          remote_phone_e164 = excluded.remote_phone_e164,
          last_event_at = excluded.last_event_at
      `).run(event.call_id, customerId, event.direction, event.type, phone, event.occurred_at, event.occurred_at);

      if (customerId === null) {
        this.db.prepare(`
          INSERT INTO unmatched_calls (call_id, remote_phone_e164, reason, status, created_at)
          VALUES (?, ?, 'customer_phone_not_found', 'open', ?)
          ON CONFLICT(call_id) DO UPDATE SET
            remote_phone_e164 = excluded.remote_phone_e164,
            reason = excluded.reason
        `).run(event.call_id, phone, receivedAt);
      } else {
        this.db.prepare("DELETE FROM unmatched_calls WHERE call_id = ?").run(event.call_id);
      }

      if (event.type === "missed_call" && customerId !== null) {
        this.db.prepare(`
          INSERT INTO notification_outbox
            (outbox_key, call_id, customer_id, channel, payload_json, status, attempts, created_at)
          VALUES (?, ?, ?, 'email', ?, 'pending', 0, ?)
          ON CONFLICT(outbox_key) DO NOTHING
        `).run(
          `${event.call_id}:missed_call`,
          event.call_id,
          customerId,
          JSON.stringify({ call_id: event.call_id, customer_id: customerId, template: "missed_call" }),
          receivedAt,
        );
      }

      this.db.exec("COMMIT");
      return { outcome: "processed", event_id: event.event_id, call_id: event.call_id, matched: customerId !== null };
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }

  reject(eventId, reason, payloadHash, receivedAt) {
    this.db.prepare(`
      INSERT INTO rejected_events (event_id, reason, payload_hash, received_at)
      VALUES (?, ?, ?, ?)
    `).run(String(eventId).slice(0, 120), String(reason).slice(0, 120), payloadHash, receivedAt);
  }

  count(table) {
    const allowed = new Set(["customers", "webhook_events", "call_logs", "unmatched_calls", "notification_outbox", "rejected_events"]);
    if (!allowed.has(table)) throw new Error("table_not_allowed");
    return Number(this.db.prepare(`SELECT COUNT(*) AS count FROM ${table}`).get().count);
  }

  getCall(callId) {
    return this.db.prepare("SELECT * FROM call_logs WHERE call_id = ?").get(callId);
  }

  getOutbox() {
    return this.db.prepare("SELECT * FROM notification_outbox ORDER BY outbox_key").all();
  }

  summary() {
    const calls = this.db.prepare(`
      SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN customer_id IS NOT NULL THEN 1 ELSE 0 END) AS matched,
        SUM(CASE WHEN customer_id IS NULL THEN 1 ELSE 0 END) AS unmatched
      FROM call_logs
    `).get();
    return {
      accepted_events: this.count("webhook_events"),
      rejected_events: this.count("rejected_events"),
      calls: {
        total: Number(calls.total),
        matched: Number(calls.matched ?? 0),
        unmatched: Number(calls.unmatched ?? 0),
      },
      open_unmatched: this.count("unmatched_calls"),
      notifications_staged: this.count("notification_outbox"),
      notifications_sent: 0,
    };
  }

  close() {
    this.db.close();
  }
}
