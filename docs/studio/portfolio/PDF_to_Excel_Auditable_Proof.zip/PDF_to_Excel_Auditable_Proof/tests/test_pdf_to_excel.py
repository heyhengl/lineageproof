from __future__ import annotations

import csv
import json
import sys
import unittest
from pathlib import Path

from pypdf import PdfReader


BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))

import extract_pdf  # noqa: E402
import generate_source  # noqa: E402


class PdfToExcelProofTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        generate_source.main()
        extract_pdf.main()

    def test_source_and_extraction_reconcile(self) -> None:
        report = json.loads((BASE / "dist/extraction_report.json").read_text())
        self.assertEqual(len(PdfReader(str(BASE / "fixtures/Synthetic_Service_Records.pdf")).pages), 4)
        self.assertEqual(report["page_count"], 4)
        self.assertEqual(report["extracted_rows"], 36)
        self.assertEqual(report["ready_rows"], 35)
        self.assertEqual(report["review_rows"], 1)
        self.assertEqual(report["issue_count"], 1)
        self.assertGreater(report["normalized_wrapped_cells"], 0)
        self.assertEqual(report["source_total"], report["extracted_total"])
        self.assertEqual(report["grand_total_delta"], 0.0)

    def test_order_text_and_review_boundary(self) -> None:
        with (BASE / "dist/extracted_records.csv").open(newline="", encoding="utf-8") as handle:
            records = list(csv.DictReader(handle))
        expected = json.loads((BASE / "fixtures/source_records.json").read_text())
        self.assertEqual([row["record_id"] for row in records], [row["record_id"] for row in expected])
        self.assertEqual(len({row["record_id"] for row in records}), 36)
        self.assertTrue(all("\n" not in row["description"] for row in records))
        self.assertEqual([row["description"] for row in records], [row["description"] for row in expected])
        review = [row for row in records if row["qa_status"] == "Needs Review"]
        self.assertEqual([row["record_id"] for row in review], ["SR-0023"])
        self.assertEqual(review[0]["unit_rate"], "")
        self.assertIn("no rate was invented", review[0]["qa_note"])

    def test_page_qa_and_issue_register(self) -> None:
        with (BASE / "dist/page_quality.csv").open(newline="", encoding="utf-8") as handle:
            pages = list(csv.DictReader(handle))
        with (BASE / "dist/issues.csv").open(newline="", encoding="utf-8") as handle:
            issues = list(csv.DictReader(handle))
        self.assertEqual(len(pages), 4)
        self.assertTrue(all(row["source_rows"] == row["extracted_rows"] == "9" for row in pages))
        self.assertTrue(all(float(row["total_delta"]) == 0.0 for row in pages))
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["field"], "Unit Rate")
        self.assertEqual(issues[0]["action"], "Open")


if __name__ == "__main__":
    unittest.main()
