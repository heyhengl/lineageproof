#!/usr/bin/env python3
"""Create a deterministic, self-auditing PDF-to-Excel proof archive."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
OUTPUT_ZIP = ROOT / "output" / "portfolio" / "PDF_to_Excel_Auditable_Proof.zip"
XLSX = ROOT / "outputs" / "019f6a63-e059-7e70-b917-71b039c67d82" / "PDF_to_Excel_Auditable_Sample.xlsx"
CASE_STUDY = ROOT / "output" / "pdf" / "PDF_to_Excel_Auditable_Case_Study.pdf"
ARCHIVE_ROOT = "PDF_to_Excel_Auditable_Proof"
FIXED_TIME = (1980, 1, 1, 0, 0, 0)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    return info


def main() -> None:
    OUTPUT_ZIP.parent.mkdir(parents=True, exist_ok=True)
    entries = {
        f"{ARCHIVE_ROOT}/README.md": BASE / "README.md",
        f"{ARCHIVE_ROOT}/source/Synthetic_Service_Records.pdf": BASE / "fixtures" / "Synthetic_Service_Records.pdf",
        f"{ARCHIVE_ROOT}/source/source_records.json": BASE / "fixtures" / "source_records.json",
        f"{ARCHIVE_ROOT}/source/source_manifest.json": BASE / "fixtures" / "source_manifest.json",
        f"{ARCHIVE_ROOT}/delivery/PDF_to_Excel_Auditable_Sample.xlsx": XLSX,
        f"{ARCHIVE_ROOT}/delivery/PDF_to_Excel_Auditable_Case_Study.pdf": CASE_STUDY,
        f"{ARCHIVE_ROOT}/qa/extracted_records.csv": BASE / "dist" / "extracted_records.csv",
        f"{ARCHIVE_ROOT}/qa/page_quality.csv": BASE / "dist" / "page_quality.csv",
        f"{ARCHIVE_ROOT}/qa/issues.csv": BASE / "dist" / "issues.csv",
        f"{ARCHIVE_ROOT}/qa/source_inventory.csv": BASE / "dist" / "source_inventory.csv",
        f"{ARCHIVE_ROOT}/qa/extraction_report.json": BASE / "dist" / "extraction_report.json",
        f"{ARCHIVE_ROOT}/scripts/generate_source.py": BASE / "generate_source.py",
        f"{ARCHIVE_ROOT}/scripts/extract_pdf.py": BASE / "extract_pdf.py",
        f"{ARCHIVE_ROOT}/scripts/build_workbook.mjs": BASE / "build_workbook.mjs",
        f"{ARCHIVE_ROOT}/scripts/normalize_xlsx.py": BASE / "normalize_xlsx.py",
        f"{ARCHIVE_ROOT}/scripts/verify_workbook.mjs": BASE / "verify_workbook.mjs",
        f"{ARCHIVE_ROOT}/scripts/build_case_study.py": BASE / "build_case_study.py",
        f"{ARCHIVE_ROOT}/scripts/package_proof.py": BASE / "package_proof.py",
        f"{ARCHIVE_ROOT}/tests/test_pdf_to_excel.py": BASE / "tests" / "test_pdf_to_excel.py",
    }
    for archive_name, path in entries.items():
        if not path.exists():
            raise FileNotFoundError(f"{archive_name}: {path}")
    manifest = {
        "proof_kind": "synthetic_pdf_to_excel_auditable_conversion",
        "contains_customer_data": False,
        "entry_count_excluding_manifest": len(entries),
        "files": {
            name: {"sha256": sha256(path), "bytes": path.stat().st_size}
            for name, path in sorted(entries.items())
        },
    }
    manifest_path = BASE / "dist" / "artifact_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with zipfile.ZipFile(OUTPUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(entries.items()):
            archive.writestr(archive_info(name), path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        archive.writestr(
            archive_info(f"{ARCHIVE_ROOT}/artifact_manifest.json"),
            manifest_path.read_bytes(),
            compress_type=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        )
    with zipfile.ZipFile(OUTPUT_ZIP) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"Corrupt ZIP entry: {bad}")
        if len(archive.namelist()) != len(entries) + 1:
            raise RuntimeError("Unexpected ZIP entry count")
    print(json.dumps({"zip": str(OUTPUT_ZIP), "sha256": sha256(OUTPUT_ZIP), "entries": len(entries) + 1}, sort_keys=True))


if __name__ == "__main__":
    main()
