#!/usr/bin/env python3
"""Build an English PDF case study from the verified proof artifacts."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from reportlab.lib.utils import ImageReader


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
OUTPUT = ROOT / "output" / "pdf" / "PDF_to_Excel_Auditable_Case_Study.pdf"
XLSX = ROOT / "outputs" / "019f6a63-e059-7e70-b917-71b039c67d82" / "PDF_to_Excel_Auditable_Sample.xlsx"
SOURCE = BASE / "fixtures" / "Synthetic_Service_Records.pdf"
REPORT = BASE / "dist" / "extraction_report.json"
PREVIEW_DIR = ROOT / "tmp" / "spreadsheets" / "pdf-to-excel"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class InvariantCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        kwargs["invariant"] = 1
        super().__init__(*args, **kwargs)


def fit_image(path: Path, max_width: float, max_height: float) -> Image:
    width, height = ImageReader(str(path)).getSize()
    scale = min(max_width / width, max_height / height)
    return Image(str(path), width=width * scale, height=height * scale)


def page_frame(pdf: canvas.Canvas, doc: SimpleDocTemplate) -> None:
    pdf.saveState()
    width, height = A4
    pdf.setFillColor(colors.HexColor("#102A43"))
    pdf.rect(0, height - 12 * mm, width, 12 * mm, fill=1, stroke=0)
    pdf.setFillColor(colors.white)
    pdf.setFont("Helvetica-Bold", 8.5)
    pdf.drawString(18 * mm, height - 7.7 * mm, "MICROSTUDIO | PDF-TO-EXCEL AUDITABLE PROOF")
    pdf.setFillColor(colors.HexColor("#64748B"))
    pdf.setFont("Helvetica", 8)
    pdf.drawString(18 * mm, 10 * mm, "Synthetic portfolio evidence - no customer data")
    pdf.drawRightString(width - 18 * mm, 10 * mm, f"Page {doc.page}")
    pdf.restoreState()


def main() -> None:
    report = json.loads(REPORT.read_text())
    overview_png = PREVIEW_DIR / "final-overview.png"
    source_png = PREVIEW_DIR / "source-page-1.png"
    extracted_png = PREVIEW_DIR / "final-spotlight-extracted.png"
    for path in (overview_png, source_png, extracted_png, XLSX, SOURCE):
        if not path.exists():
            raise FileNotFoundError(path)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)

    styles = getSampleStyleSheet()
    title = ParagraphStyle("Title", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=24, leading=28, textColor=colors.HexColor("#102A43"), alignment=TA_LEFT, spaceAfter=4 * mm)
    h1 = ParagraphStyle("H1", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=colors.HexColor("#102A43"), spaceAfter=4 * mm)
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=11, leading=14, textColor=colors.HexColor("#1D4ED8"), spaceBefore=2 * mm, spaceAfter=2 * mm)
    body = ParagraphStyle("Body", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.5, leading=13.2, textColor=colors.HexColor("#243B53"), spaceAfter=2.5 * mm)
    small = ParagraphStyle("Small", parent=body, fontSize=8.2, leading=10.5, textColor=colors.HexColor("#52667A"))
    center = ParagraphStyle("Center", parent=small, alignment=TA_CENTER)
    bullet = ParagraphStyle("Bullet", parent=body, leftIndent=5 * mm, firstLineIndent=-3 * mm, bulletIndent=1 * mm, spaceAfter=2 * mm)

    doc = SimpleDocTemplate(str(OUTPUT), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=20 * mm, bottomMargin=18 * mm, title="PDF-to-Excel Auditable Conversion Proof", author="MicroStudio", subject="Synthetic PDF-to-Excel portfolio case study")
    story = []

    story.append(Paragraph("PDF-to-Excel<br/>Auditable Conversion Proof", title))
    story.append(Paragraph("A synthetic four-page service-record PDF converted into a typed, filter-ready workbook with source order, page reconciliation, formulas, and an explicit issue register.", body))
    kpis = [
        ["SOURCE", "OUTPUT", "READY", "REVIEW", "TOTAL DELTA"],
        [f"{report['page_count']} pages", f"{report['extracted_rows']} rows", str(report["ready_rows"]), str(report["review_rows"]), f"${report['grand_total_delta']:.2f}"],
    ]
    kpi_table = Table(kpis, colWidths=[34 * mm] * 5, rowHeights=[9 * mm, 13 * mm])
    kpi_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#102A43")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 7.5),
        ("BACKGROUND", (0, 1), (-1, 1), colors.HexColor("#EAF2FF")),
        ("TEXTCOLOR", (0, 1), (-1, 1), colors.HexColor("#102A43")),
        ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 1), (-1, 1), 12),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#8DB3E2")),
        ("INNERGRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
    ]))
    story.append(kpi_table)
    story.append(Spacer(1, 5 * mm))
    story.append(Paragraph("Workbook overview", h2))
    story.append(fit_image(overview_png, 174 * mm, 112 * mm))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph("The summary is formula-driven from the extracted records and page QA sheets. The one deliberate unclear token is not silently repaired.", center))

    story.append(PageBreak())
    story.append(Paragraph("1. Synthetic source with realistic extraction friction", h1))
    story.append(Paragraph("The source fixture repeats the same table structure across four pages, includes wrapped descriptions, typed dates and amounts, and one deliberately unclear unit-rate token. It contains no customer or platform data.", body))
    story.append(fit_image(source_png, 174 * mm, 111 * mm))
    story.append(Spacer(1, 4 * mm))
    for item in [
        "Repeated headers are identified and excluded from data rows.",
        "Cell-internal line breaks are normalized without changing the text sequence.",
        "Every record keeps source_page and source_order provenance.",
        "The printed page total is extracted independently for reconciliation.",
    ]:
        story.append(Paragraph(item, bullet, bulletText="-"))

    story.append(PageBreak())
    story.append(Paragraph("2. Structured output with visible QA", h1))
    story.append(Paragraph("The output uses typed dates, quantities, rates, and amounts. Recalculated amounts and deltas are formulas, while uncertain source content is preserved in QA Note and Issues.", body))
    story.append(fit_image(extracted_png, 174 * mm, 112 * mm))
    story.append(Spacer(1, 4 * mm))
    qa_data = [
        ["Control", "Verified result"],
        ["Record inventory", "36 of 36 source records, in original order"],
        ["Wrapped cells", f"{report['normalized_wrapped_cells']} cells normalized to single-line values"],
        ["Page reconciliation", "4 of 4 pages have zero amount delta"],
        ["Review boundary", "1 unclear token left blank; 1 Issues row opened"],
    ]
    qa_table = Table(qa_data, colWidths=[48 * mm, 122 * mm])
    qa_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#102A43")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (0, -1), "Helvetica-Bold"),
        ("TEXTCOLOR", (0, 1), (-1, -1), colors.HexColor("#243B53")),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(qa_table)

    story.append(PageBreak())
    story.append(Paragraph("3. Delivery map and acceptance boundary", h1))
    story.append(Paragraph("The proof separates source evidence, extracted data, quality controls, and unresolved issues so another operator can audit the conversion without the original builder.", body))
    map_data = [
        ["Workbook sheet", "Purpose"],
        ["Overview", "Formula-driven counts, ready/review totals, and amount reconciliation"],
        ["Extracted Data", "Filter-ready records with source provenance and formula checks"],
        ["Page QA", "Source-vs-output row counts and amount totals by page"],
        ["Issues", "Unclear values, source token, action status, and review note"],
        ["Source Inventory", "File, pages, source hash, extraction method, and total"],
    ]
    map_table = Table(map_data, colWidths=[45 * mm, 125 * mm])
    map_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#102A43")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("TEXTCOLOR", (0, 1), (-1, -1), colors.HexColor("#243B53")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(map_table)
    story.append(Spacer(1, 5 * mm))
    story.append(Paragraph("Production acceptance boundary", h2))
    for item in [
        "Inventory the files and page count before accepting the full conversion.",
        "Approve the target columns and one representative output before bulk work.",
        "Flag handwriting, image-only scans, merged layouts, and unreadable tokens for revised scope.",
        "Accept on file coverage, agreed schema, row consistency, page sampling, and explicit issues - not an unsupported perfect-OCR claim.",
    ]:
        story.append(Paragraph(item, bullet, bulletText="-"))
    story.append(Spacer(1, 3 * mm))
    story.append(Paragraph("Frozen artifact fingerprints", h2))
    story.append(Paragraph(f"Source PDF SHA-256: {sha256(SOURCE)}", small))
    story.append(Paragraph(f"Workbook SHA-256: {sha256(XLSX)}", small))
    story.append(Paragraph("All source values are fictional. The proof package includes code, extracted CSV/JSON, tests, the source PDF, workbook, and this case study.", small))

    doc.build(story, onFirstPage=page_frame, onLaterPages=page_frame, canvasmaker=InvariantCanvas)
    print(OUTPUT)


if __name__ == "__main__":
    main()
