import fs from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const projectRoot = fileURLToPath(new URL("../../../../", import.meta.url)).replace(/\/$/, "");
const workbookPath = `${projectRoot}/outputs/019f6a63-e059-7e70-b917-71b039c67d82/PDF_to_Excel_Auditable_Sample.xlsx`;
const previewDir = `${projectRoot}/tmp/spreadsheets/pdf-to-excel`;
await fs.mkdir(previewDir, { recursive: true });

const input = await FileBlob.load(workbookPath);
const workbook = await SpreadsheetFile.importXlsx(input);
console.log((await workbook.inspect({ kind: "workbook,sheet,table", maxChars: 7500, tableMaxRows: 4, tableMaxCols: 8 })).ndjson);
console.log((await workbook.inspect({ kind: "table", range: "Overview!A1:H18", include: "values,formulas", tableMaxRows: 20, tableMaxCols: 10, maxChars: 6500 })).ndjson);
console.log((await workbook.inspect({ kind: "table", range: "Page QA!A1:H5", include: "values,formulas", tableMaxRows: 8, tableMaxCols: 10, maxChars: 4000 })).ndjson);
console.log((await workbook.inspect({ kind: "table", range: "Extracted Data!A20:N25", include: "values,formulas", tableMaxRows: 8, tableMaxCols: 16, maxChars: 5000 })).ndjson);
console.log((await workbook.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A", options: { useRegex: true, maxResults: 100 }, summary: "post-export formula error scan" })).ndjson);

for (const sheetName of ["Overview", "Extracted Data", "Page QA", "Issues", "Source Inventory"]) {
  const preview = await workbook.render({ sheetName, autoCrop: "all", scale: 1.25, format: "png" });
  const fileName = sheetName.toLowerCase().replaceAll(" ", "-");
  await fs.writeFile(`${previewDir}/final-${fileName}.png`, new Uint8Array(await preview.arrayBuffer()));
}
const spotlight = await workbook.render({ sheetName: "Extracted Data", range: "A1:N14", scale: 1.35, format: "png" });
await fs.writeFile(`${previewDir}/final-spotlight-extracted.png`, new Uint8Array(await spotlight.arrayBuffer()));
