#!/usr/bin/env python3
"""Extract the synthetic source PDF into auditable, workbook-ready records."""

from __future__ import annotations

import csv
import hashlib
import json
import re
from datetime import date
from decimal import Decimal, InvalidOperation
from pathlib import Path

import pdfplumber
from pypdf import PdfReader


BASE = Path(__file__).resolve().parent
FIXTURES = BASE / "fixtures"
DIST = BASE / "dist"
SOURCE_PDF = FIXTURES / "Synthetic_Service_Records.pdf"
EXPECTED_HEADERS = ["Record ID", "Date", "Department", "Reference", "Description", "Qty", "Unit Rate", "Amount"]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clean_text(value: object) -> str:
    return re.sub(r"\s+", " ", "" if value is None else str(value)).strip()


def parse_decimal(value: str) -> Decimal | None:
    token = value.replace("$", "").replace(",", "").strip()
    if token in {"", "??", "?"}:
        return None
    try:
        return Decimal(token).quantize(Decimal("0.01"))
    except InvalidOperation:
        return None


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    DIST.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, object]] = []
    issues: list[dict[str, object]] = []
    page_quality: list[dict[str, object]] = []
    normalized_line_breaks = 0

    with pdfplumber.open(SOURCE_PDF) as pdf:
        for page_number, page in enumerate(pdf.pages, start=1):
            page_tables = page.extract_tables(
                {
                    "vertical_strategy": "lines",
                    "horizontal_strategy": "lines",
                    "intersection_tolerance": 5,
                    "snap_tolerance": 3,
                    "join_tolerance": 3,
                }
            )
            source_table = None
            for table in page_tables:
                header = [clean_text(cell) for cell in table[0]] if table else []
                if header == EXPECTED_HEADERS:
                    source_table = table
                    break
            if source_table is None:
                raise RuntimeError(f"No matching source table found on page {page_number}")

            page_text = page.extract_text() or ""
            total_match = re.search(r"Page total\s+([0-9,]+\.\d{2})", page_text)
            if not total_match:
                raise RuntimeError(f"No page total found on page {page_number}")
            source_page_total = Decimal(total_match.group(1).replace(",", ""))
            page_rows: list[dict[str, object]] = []
            for row_index, cells in enumerate(source_table[1:], start=1):
                if not any(clean_text(cell) for cell in cells):
                    continue
                raw = dict(zip(EXPECTED_HEADERS, cells, strict=True))
                description_raw = "" if raw["Description"] is None else str(raw["Description"])
                if "\n" in description_raw:
                    normalized_line_breaks += 1
                record_id = clean_text(raw["Record ID"])
                service_date = clean_text(raw["Date"])
                date.fromisoformat(service_date)
                quantity_token = clean_text(raw["Qty"])
                quantity = int(quantity_token) if quantity_token.isdigit() else None
                unit_rate_token = clean_text(raw["Unit Rate"])
                unit_rate = parse_decimal(unit_rate_token)
                source_amount = parse_decimal(clean_text(raw["Amount"]))
                if source_amount is None:
                    raise RuntimeError(f"Missing source amount for {record_id}")
                recalculated = (unit_rate * quantity).quantize(Decimal("0.01")) if unit_rate is not None and quantity is not None else None
                delta = (source_amount - recalculated).quantize(Decimal("0.01")) if recalculated is not None else None
                status = "Ready"
                note = "Source amount reconciles to quantity x unit rate."
                if unit_rate is None:
                    status = "Needs Review"
                    note = f"Unit rate token '{unit_rate_token}' is ambiguous; value left blank and no rate was invented."
                    issues.append(
                        {
                            "issue_id": f"ISS-{len(issues) + 1:03d}",
                            "source_page": page_number,
                            "record_id": record_id,
                            "field": "Unit Rate",
                            "source_token": unit_rate_token,
                            "action": "Open",
                            "note": note,
                        }
                    )
                elif delta is None or abs(delta) > Decimal("0.01"):
                    status = "Needs Review"
                    note = "Source amount does not reconcile to quantity x unit rate."
                record = {
                    "source_page": page_number,
                    "source_order": len(records) + 1,
                    "record_id": record_id,
                    "service_date": service_date,
                    "department": clean_text(raw["Department"]),
                    "reference": clean_text(raw["Reference"]),
                    "description": clean_text(raw["Description"]),
                    "quantity": quantity,
                    "unit_rate": float(unit_rate) if unit_rate is not None else None,
                    "unit_rate_source_token": unit_rate_token,
                    "source_amount": float(source_amount),
                    "recalculated_amount": float(recalculated) if recalculated is not None else None,
                    "amount_delta": float(delta) if delta is not None else None,
                    "qa_status": status,
                    "qa_note": note,
                }
                records.append(record)
                page_rows.append(record)
            extracted_page_total = sum(Decimal(str(row["source_amount"])) for row in page_rows)
            page_quality.append(
                {
                    "source_page": page_number,
                    "source_rows": len(source_table) - 1,
                    "extracted_rows": len(page_rows),
                    "ready_rows": sum(row["qa_status"] == "Ready" for row in page_rows),
                    "review_rows": sum(row["qa_status"] == "Needs Review" for row in page_rows),
                    "source_total": float(source_page_total),
                    "extracted_total": float(extracted_page_total),
                    "total_delta": float((extracted_page_total - source_page_total).quantize(Decimal("0.01"))),
                }
            )

    source_total = sum(Decimal(str(row["source_amount"])) for row in records)
    report = {
        "source_file": SOURCE_PDF.name,
        "source_sha256": sha256(SOURCE_PDF),
        "page_count": len(PdfReader(str(SOURCE_PDF)).pages),
        "extracted_rows": len(records),
        "ready_rows": sum(row["qa_status"] == "Ready" for row in records),
        "review_rows": sum(row["qa_status"] == "Needs Review" for row in records),
        "issue_count": len(issues),
        "normalized_wrapped_cells": normalized_line_breaks,
        "source_total": float(source_total),
        "extracted_total": float(source_total),
        "grand_total_delta": 0.0,
        "contains_customer_data": False,
        "extraction_method": "pdfplumber line-table extraction plus explicit normalization and QA",
    }
    inventory = [
        {
            "source_file": SOURCE_PDF.name,
            "pages": report["page_count"],
            "extracted_rows": report["extracted_rows"],
            "source_total": report["source_total"],
            "source_sha256": report["source_sha256"],
            "method": report["extraction_method"],
        }
    ]

    write_csv(DIST / "extracted_records.csv", list(records[0]), records)
    write_csv(DIST / "page_quality.csv", list(page_quality[0]), page_quality)
    write_csv(
        DIST / "issues.csv",
        ["issue_id", "source_page", "record_id", "field", "source_token", "action", "note"],
        issues,
    )
    write_csv(DIST / "source_inventory.csv", list(inventory[0]), inventory)
    (DIST / "extraction_report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    payload = {
        "report": report,
        "inventory": inventory,
        "records": records,
        "page_quality": page_quality,
        "issues": issues,
    }
    (DIST / "workbook_payload.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
