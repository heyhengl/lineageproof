#!/usr/bin/env python3
"""Normalize XLSX archive metadata without authoring workbook content."""

from __future__ import annotations

import re
import tempfile
import zipfile
from pathlib import Path


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
XLSX = ROOT / "outputs" / "019f6a63-e059-7e70-b917-71b039c67d82" / "PDF_to_Excel_Auditable_Sample.xlsx"
FIXED_TIME = (1980, 1, 1, 0, 0, 0)


def main() -> None:
    with zipfile.ZipFile(XLSX, "r") as source:
        entries = {name: source.read(name) for name in source.namelist()}
    core_name = "docProps/core.xml"
    if core_name in entries:
        text = entries[core_name].decode("utf-8")
        text = re.sub(
            r"(<dcterms:(?:created|modified)[^>]*>).*?(</dcterms:(?:created|modified)>)",
            r"\g<1>2026-07-17T00:00:00Z\g<2>",
            text,
        )
        entries[core_name] = text.encode("utf-8")
    # artifact-tool assigns random relationship IDs on every export. They are
    # non-business metadata, but they affect byte hashes. Canonicalize each
    # relationship set in document order and update its owning XML part.
    for rel_name in sorted(name for name in entries if name.endswith(".rels")):
        rel_text = entries[rel_name].decode("utf-8-sig")
        old_ids = re.findall(r'\bId="([^"]+)"', rel_text)
        replacements = {old_id: f"rId{index}" for index, old_id in enumerate(old_ids, start=1)}
        for old_id, new_id in replacements.items():
            rel_text = rel_text.replace(f'Id="{old_id}"', f'Id="{new_id}"')
        entries[rel_name] = rel_text.encode("utf-8")

        if "/_rels/" in rel_name:
            parent, rel_file = rel_name.split("/_rels/", 1)
            source_name = f"{parent}/{rel_file[:-5]}"
        elif rel_name.startswith("_rels/"):
            source_name = rel_name.removeprefix("_rels/")[:-5]
        else:
            source_name = ""
        if source_name in entries:
            source_text = entries[source_name].decode("utf-8-sig")
            for old_id, new_id in replacements.items():
                source_text = source_text.replace(old_id, new_id)
            entries[source_name] = source_text.encode("utf-8")
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False, dir=XLSX.parent) as handle:
        temp_path = Path(handle.name)
    try:
        with zipfile.ZipFile(temp_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
            for name in sorted(entries):
                info = zipfile.ZipInfo(name, FIXED_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                target.writestr(info, entries[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        temp_path.replace(XLSX)
    finally:
        temp_path.unlink(missing_ok=True)
    print(XLSX)


if __name__ == "__main__":
    main()
