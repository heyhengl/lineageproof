import fs from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const base = fileURLToPath(new URL("./", import.meta.url)).replace(/\/$/, "");
const projectRoot = fileURLToPath(new URL("../../../../", import.meta.url)).replace(/\/$/, "");
const outputDir = `${projectRoot}/outputs/019f6a63-e059-7e70-b917-71b039c67d82`;
const previewDir = `${projectRoot}/tmp/spreadsheets/pdf-to-excel`;
const payload = JSON.parse(await fs.readFile(`${base}/dist/workbook_payload.json`, "utf8"));
await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(previewDir, { recursive: true });

const workbook = Workbook.create();
const overview = workbook.worksheets.add("Overview");
const extracted = workbook.worksheets.add("Extracted Data");
const pageQa = workbook.worksheets.add("Page QA");
const issues = workbook.worksheets.add("Issues");
const inventory = workbook.worksheets.add("Source Inventory");

const navy = "#102A43";
const blue = "#1D4ED8";
const ink = "#172B4D";
const muted = "#64748B";
const line = "#D9E2EC";
const paleBlue = "#EAF2FF";
const paleGreen = "#E9F7EF";
const paleAmber = "#FFF7E6";
const paleRed = "#FDECEC";

function header(range) {
  range.format = {
    fill: navy,
    font: { bold: true, color: "#FFFFFF", size: 10 },
    verticalAlignment: "center",
  };
  range.format.rowHeight = 27;
}

function body(range) {
  range.format = {
    font: { color: ink, size: 10 },
    verticalAlignment: "center",
  };
}

function borderRows(range) {
  range.format.borders = {
    insideHorizontal: { style: "thin", color: line },
    bottom: { style: "thin", color: line },
  };
}

// Overview
overview.showGridLines = false;
overview.getRange("A1:H2").merge();
overview.getRange("A1").values = [["PDF-to-Excel - auditable conversion proof"]];
overview.getRange("A1:H2").format = {
  fill: navy,
  font: { bold: true, color: "#FFFFFF", size: 19 },
  verticalAlignment: "center",
};
overview.getRange("A3:H3").merge();
overview.getRange("A3").values = [["Synthetic four-page source converted into ordered, filter-ready records with page-level reconciliation and an explicit issue register."]];
overview.getRange("A3:H3").format = {
  fill: paleBlue,
  font: { color: ink, italic: true, size: 10 },
  wrapText: true,
  verticalAlignment: "center",
};
overview.getRange("A3:H3").format.rowHeight = 34;

const cards = [
  { range: "A5:B7", label: "Source pages", formula: "=COUNTA('Page QA'!$A$2:$A$5)", fill: paleBlue, format: "0" },
  { range: "D5:E7", label: "Extracted rows", formula: "=COUNTA('Extracted Data'!$C$2:$C$37)", fill: paleGreen, format: "0" },
  { range: "G5:H7", label: "Rows ready", formula: "=COUNTIF('Extracted Data'!$M$2:$M$37,\"Ready\")", fill: paleGreen, format: "0" },
  { range: "A9:B11", label: "Rows for review", formula: "=COUNTIF('Extracted Data'!$M$2:$M$37,\"Needs Review\")", fill: paleAmber, format: "0" },
  { range: "D9:E11", label: "Source total", formula: "=SUM('Page QA'!$F$2:$F$5)", fill: paleBlue, format: '"$"#,##0.00' },
  { range: "G9:H11", label: "Page total delta", formula: "=SUM('Page QA'!$H$2:$H$5)", fill: paleGreen, format: '"$"#,##0.00' },
];
for (const card of cards) {
  const [start, end] = card.range.split(":");
  const startCol = start.replace(/\d/g, "");
  const startRow = Number(start.replace(/\D/g, ""));
  const endCol = end.replace(/\d/g, "");
  const panel = overview.getRange(card.range);
  panel.format.fill = card.fill;
  panel.format.borders = { preset: "outside", style: "thin", color: line };
  overview.getRange(`${startCol}${startRow}`).values = [[card.label]];
  overview.getRange(`${startCol}${startRow}`).format.font = { bold: true, color: muted, size: 9 };
  overview.getRange(`${startCol}${startRow + 1}:${endCol}${startRow + 2}`).merge();
  overview.getRange(`${startCol}${startRow + 1}`).formulas = [[card.formula]];
  overview.getRange(`${startCol}${startRow + 1}`).format = {
    font: { bold: true, color: navy, size: 18 },
    verticalAlignment: "center",
  };
  overview.getRange(`${startCol}${startRow + 1}`).format.numberFormat = card.format;
}

overview.getRange("A13:H13").merge();
overview.getRange("A13").values = [["Conversion controls"]];
overview.getRange("A13:H13").format = { fill: blue, font: { bold: true, color: "#FFFFFF", size: 11 } };
overview.getRange("A14:H18").values = [
  ["1", "Source order", "Every row carries source page and source order.", null, "4", "No guessing", "Unclear values remain blank and enter Issues.", null],
  ["2", "Wrapped text", "PDF line breaks become clean single-line cell text.", null, "5", "Typed fields", "Dates and amounts remain sortable numeric values.", null],
  ["3", "Page QA", "Counts and amounts reconcile page by page.", null, "6", "Filter-ready", "Headers, tables, filters, and frozen panes are applied.", null],
  [null, null, null, null, null, null, null, null],
  ["Scope", "Synthetic portfolio evidence only. Production work begins after file inventory, schema approval, and a funded representative sample.", null, null, null, null, null, null],
];
overview.getRange("A14:H18").format = { font: { color: ink, size: 10 }, wrapText: true, verticalAlignment: "center" };
overview.getRange("A14:H16").format.borders = { insideHorizontal: { style: "thin", color: line } };
overview.getRange("B18:H18").merge();
overview.getRange("A18:H18").format.fill = "#F8FAFC";
overview.getRange("A18").format.font = { bold: true, color: muted };
overview.getRange("A14:H16").format.rowHeight = 36;
overview.getRange("A18:H18").format.rowHeight = 40;
overview.getRange("A1:H18").format.columnWidth = 14;
overview.getRange("B1:B18").format.columnWidth = 19;
overview.getRange("C1:C18").format.columnWidth = 28;
overview.getRange("F1:F18").format.columnWidth = 19;
overview.getRange("G1:G18").format.columnWidth = 28;
overview.freezePanes.freezeRows(3);

// Extracted Data
const extractedHeaders = ["Source Page", "Source Order", "Record ID", "Service Date", "Department", "Reference", "Description", "Qty", "Unit Rate", "Source Amount", "Recalculated", "Delta", "QA Status", "QA Note"];
const extractedRows = payload.records.map((row) => [
  row.source_page,
  row.source_order,
  row.record_id,
  new Date(`${row.service_date}T00:00:00Z`),
  row.department,
  row.reference,
  row.description,
  row.quantity,
  row.unit_rate,
  row.source_amount,
  null,
  null,
  null,
  row.qa_note,
]);
extracted.getRange(`A1:N${extractedRows.length + 1}`).values = [extractedHeaders, ...extractedRows];
extracted.getRange("K2").formulas = [["=IF(OR(H2=\"\",I2=\"\"),\"\",ROUND(H2*I2,2))"]];
extracted.getRange("K2:K37").fillDown();
extracted.getRange("L2").formulas = [["=IF(K2=\"\",\"\",ROUND(J2-K2,2))"]];
extracted.getRange("L2:L37").fillDown();
extracted.getRange("M2").formulas = [["=IF(OR(H2=\"\",I2=\"\"),\"Needs Review\",IF(ABS(L2)<=0.01,\"Ready\",\"Needs Review\"))"]];
extracted.getRange("M2:M37").fillDown();
header(extracted.getRange("A1:N1"));
body(extracted.getRange("A2:N37"));
borderRows(extracted.getRange("A1:N37"));
extracted.getRange("A2:B37").format.numberFormat = "0";
extracted.getRange("D2:D37").format.numberFormat = "yyyy-mm-dd";
extracted.getRange("H2:H37").format.numberFormat = "0";
extracted.getRange("I2:L37").format.numberFormat = '"$"#,##0.00';
extracted.getRange("A1:N37").format.columnWidth = 13;
extracted.getRange("C1:C37").format.columnWidth = 15;
extracted.getRange("D1:D37").format.columnWidth = 15;
extracted.getRange("E1:E37").format.columnWidth = 18;
extracted.getRange("F1:F37").format.columnWidth = 17;
extracted.getRange("G1:G37").format.columnWidth = 46;
extracted.getRange("N1:N37").format.columnWidth = 48;
extracted.getRange("G2:G37").format.wrapText = true;
extracted.getRange("N2:N37").format.wrapText = true;
extracted.getRange("M2:M37").conditionalFormats.add("containsText", { text: "Needs Review", format: { fill: paleAmber, font: { color: "#92400E", bold: true } } });
extracted.getRange("M2:M37").conditionalFormats.add("containsText", { text: "Ready", format: { fill: paleGreen, font: { color: "#166534", bold: true } } });
extracted.tables.add("A1:N37", true, "ExtractedRecordsTable").style = "TableStyleMedium2";
extracted.freezePanes.freezeRows(1);
extracted.freezePanes.freezeColumns(2);
extracted.showGridLines = false;

// Page QA
const pageRows = payload.page_quality.map((row) => [row.source_page, row.source_rows, null, null, null, row.source_total, null, null]);
pageQa.getRange("A1:H5").values = [["Source Page", "Source Rows", "Extracted Rows", "Ready", "Needs Review", "Source Total", "Extracted Total", "Total Delta"], ...pageRows];
pageQa.getRange("C2").formulas = [["=COUNTIF('Extracted Data'!$A$2:$A$37,A2)"]];
pageQa.getRange("C2:C5").fillDown();
pageQa.getRange("D2").formulas = [["=COUNTIFS('Extracted Data'!$A$2:$A$37,A2,'Extracted Data'!$M$2:$M$37,\"Ready\")"]];
pageQa.getRange("D2:D5").fillDown();
pageQa.getRange("E2").formulas = [["=COUNTIFS('Extracted Data'!$A$2:$A$37,A2,'Extracted Data'!$M$2:$M$37,\"Needs Review\")"]];
pageQa.getRange("E2:E5").fillDown();
pageQa.getRange("G2").formulas = [["=SUMIF('Extracted Data'!$A$2:$A$37,A2,'Extracted Data'!$J$2:$J$37)"]];
pageQa.getRange("G2:G5").fillDown();
pageQa.getRange("H2").formulas = [["=ROUND(G2-F2,2)"]];
pageQa.getRange("H2:H5").fillDown();
header(pageQa.getRange("A1:H1"));
body(pageQa.getRange("A2:H5"));
pageQa.getRange("A2:E5").format.numberFormat = "0";
pageQa.getRange("F2:H5").format.numberFormat = '"$"#,##0.00';
pageQa.getRange("A1:H5").format.columnWidth = 17;
pageQa.getRange("A1:H5").format.borders = { insideHorizontal: { style: "thin", color: line }, bottom: { style: "thin", color: line } };
pageQa.getRange("H2:H5").conditionalFormats.add("cellIs", { operator: "notEqual", formula: 0, format: { fill: paleRed, font: { color: "#991B1B", bold: true } } });
pageQa.tables.add("A1:H5", true, "PageQualityTable").style = "TableStyleMedium2";
pageQa.freezePanes.freezeRows(1);
pageQa.showGridLines = false;

// Issues
const issueRows = payload.issues.map((row) => [row.issue_id, row.source_page, row.record_id, row.field, row.source_token, row.action, row.note]);
issues.getRange(`A1:G${issueRows.length + 1}`).values = [["Issue ID", "Source Page", "Record ID", "Field", "Source Token", "Action", "Note"], ...issueRows];
header(issues.getRange("A1:G1"));
body(issues.getRange(`A2:G${issueRows.length + 1}`));
issues.getRange("A1:G2").format.columnWidth = 16;
issues.getRange("G1:G2").format.columnWidth = 58;
issues.getRange("G2:G2").format.wrapText = true;
issues.getRange("F2:F100").dataValidation = { rule: { type: "list", values: ["Open", "Reviewed", "Accepted"] } };
issues.getRange("F2:F2").conditionalFormats.add("containsText", { text: "Open", format: { fill: paleAmber, font: { color: "#92400E", bold: true } } });
issues.tables.add("A1:G2", true, "IssuesTable").style = "TableStyleMedium2";
issues.freezePanes.freezeRows(1);
issues.showGridLines = false;

// Source Inventory
const inv = payload.inventory[0];
inventory.getRange("A1:F2").values = [
  ["Source File", "Pages", "Extracted Rows", "Source Total", "Source SHA-256", "Extraction Method"],
  [inv.source_file, inv.pages, inv.extracted_rows, inv.source_total, inv.source_sha256, inv.method],
];
header(inventory.getRange("A1:F1"));
body(inventory.getRange("A2:F2"));
inventory.getRange("B2:C2").format.numberFormat = "0";
inventory.getRange("D2:D2").format.numberFormat = '"$"#,##0.00';
inventory.getRange("A1:F2").format.columnWidth = 18;
inventory.getRange("A1:A2").format.columnWidth = 32;
inventory.getRange("E1:E2").format.columnWidth = 68;
inventory.getRange("F1:F2").format.columnWidth = 58;
inventory.getRange("E2:F2").format.wrapText = true;
inventory.tables.add("A1:F2", true, "SourceInventoryTable").style = "TableStyleMedium2";
inventory.freezePanes.freezeRows(1);
inventory.showGridLines = false;

const overviewCheck = await workbook.inspect({
  kind: "table",
  range: "Overview!A1:H18",
  include: "values,formulas",
  tableMaxRows: 20,
  tableMaxCols: 10,
  maxChars: 6500,
});
console.log(overviewCheck.ndjson);
const qaCheck = await workbook.inspect({
  kind: "table",
  range: "Page QA!A1:H5",
  include: "values,formulas",
  tableMaxRows: 8,
  tableMaxCols: 10,
  maxChars: 4000,
});
console.log(qaCheck.ndjson);
const errorCheck = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 100 },
  summary: "final formula error scan",
});
console.log(errorCheck.ndjson);

for (const sheetName of ["Overview", "Extracted Data", "Page QA", "Issues", "Source Inventory"]) {
  const preview = await workbook.render({ sheetName, autoCrop: "all", scale: 1.25, format: "png" });
  const fileName = sheetName.toLowerCase().replaceAll(" ", "-");
  await fs.writeFile(`${previewDir}/build-${fileName}.png`, new Uint8Array(await preview.arrayBuffer()));
}
const spotlight = await workbook.render({ sheetName: "Extracted Data", range: "A1:N14", scale: 1.35, format: "png" });
await fs.writeFile(`${previewDir}/spotlight-extracted.png`, new Uint8Array(await spotlight.arrayBuffer()));

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(`${outputDir}/PDF_to_Excel_Auditable_Sample.xlsx`);
