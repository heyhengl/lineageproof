#!/usr/bin/env python3
"""Generate a deterministic synthetic multi-page PDF for extraction QA."""

from __future__ import annotations

import hashlib
import json
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


BASE = Path(__file__).resolve().parent
FIXTURES = BASE / "fixtures"
SOURCE_PDF = FIXTURES / "Synthetic_Service_Records.pdf"
SOURCE_RECORDS = FIXTURES / "source_records.json"
SOURCE_MANIFEST = FIXTURES / "source_manifest.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_records() -> list[dict[str, object]]:
    departments = ["Operations", "Field Services", "Customer Care", "Logistics"]
    descriptions = [
        "Preventive maintenance and calibration for mobile scanner fleet",
        "Warehouse inventory reconciliation and label replacement",
        "Customer onboarding records review - batch 07",
        "Safety inspection and compliance note consolidation",
        "Regional dispatch support - Sao Paulo service desk",
        "Invoice archive cleanup for Cafe branch records",
        "Quarterly meter reading validation and exception tagging",
        "Equipment return intake and serial-number verification",
        "Service request triage with multiline source note retained",
    ]
    rates = [Decimal("42.50"), Decimal("58.00"), Decimal("73.25"), Decimal("95.00"), Decimal("120.40")]
    records: list[dict[str, object]] = []
    start = date(2026, 6, 1)
    for index in range(36):
        source_order = index + 1
        page = index // 9 + 1
        quantity = index % 5 + 1
        rate = rates[(index * 3) % len(rates)]
        amount = (rate * quantity).quantize(Decimal("0.01"))
        ambiguous = source_order == 23
        records.append(
            {
                "source_page": page,
                "source_order": source_order,
                "record_id": f"SR-{source_order:04d}",
                "service_date": (start + timedelta(days=index)).isoformat(),
                "department": departments[index % len(departments)],
                "reference": f"REF-{2026000 + source_order}",
                "description": descriptions[index % len(descriptions)],
                "quantity": quantity,
                "unit_rate_token": "??" if ambiguous else f"{rate:.2f}",
                "expected_unit_rate": None if ambiguous else float(rate),
                "source_amount": float(amount),
                "expected_status": "Needs Review" if ambiguous else "Ready",
            }
        )
    return records


class InvariantCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        kwargs["invariant"] = 1
        super().__init__(*args, **kwargs)


def build_pdf(records: list[dict[str, object]]) -> None:
    page_size = landscape(A4)
    doc = SimpleDocTemplate(
        str(SOURCE_PDF),
        pagesize=page_size,
        leftMargin=15 * mm,
        rightMargin=15 * mm,
        topMargin=14 * mm,
        bottomMargin=14 * mm,
        title="Synthetic Service Records",
        author="MicroStudio",
        subject="Synthetic PDF-to-Excel extraction fixture",
    )
    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "Title",
        parent=styles["Title"],
        fontName="Helvetica-Bold",
        fontSize=19,
        leading=22,
        textColor=colors.HexColor("#102A43"),
        alignment=TA_LEFT,
        spaceAfter=3 * mm,
    )
    subtitle = ParagraphStyle(
        "Subtitle",
        parent=styles["BodyText"],
        fontName="Helvetica",
        fontSize=8.8,
        leading=11,
        textColor=colors.HexColor("#52667A"),
        spaceAfter=4 * mm,
    )
    cell = ParagraphStyle(
        "Cell",
        parent=styles["BodyText"],
        fontName="Helvetica",
        fontSize=7.5,
        leading=9,
        textColor=colors.HexColor("#172B4D"),
    )
    cell_right = ParagraphStyle("CellRight", parent=cell, alignment=2)
    story = []
    headers = ["Record ID", "Date", "Department", "Reference", "Description", "Qty", "Unit Rate", "Amount"]
    for page_number in range(1, 5):
        page_records = [r for r in records if r["source_page"] == page_number]
        page_total = sum(Decimal(str(r["source_amount"])) for r in page_records)
        story.append(Paragraph("Synthetic Service Records", title))
        story.append(
            Paragraph(
                f"Portfolio fixture - Page {page_number} of 4. All names, references, and values are fictional. "
                "Wrapped descriptions and one deliberate unclear token test extraction QA.",
                subtitle,
            )
        )
        rows: list[list[object]] = [headers]
        for record in page_records:
            display_description = str(record["description"])
            if int(record["source_order"]) in {1, 10, 19, 28}:
                words = display_description.split()
                display_description = " ".join(words[:4]) + "<br/>" + " ".join(words[4:])
            rows.append(
                [
                    Paragraph(str(record["record_id"]), cell),
                    Paragraph(str(record["service_date"]), cell),
                    Paragraph(str(record["department"]), cell),
                    Paragraph(str(record["reference"]), cell),
                    Paragraph(display_description, cell),
                    Paragraph(str(record["quantity"]), cell_right),
                    Paragraph(str(record["unit_rate_token"]), cell_right),
                    Paragraph(f"{float(record['source_amount']):.2f}", cell_right),
                ]
            )
        table = Table(
            rows,
            repeatRows=1,
            colWidths=[24 * mm, 25 * mm, 28 * mm, 30 * mm, 91 * mm, 15 * mm, 23 * mm, 24 * mm],
            rowHeights=[9 * mm] + [13.2 * mm] * len(page_records),
        )
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#102A43")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 8),
                    ("ALIGN", (5, 0), (-1, -1), "RIGHT"),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("GRID", (0, 0), (-1, -1), 0.45, colors.HexColor("#CBD5E1")),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8FAFC")]),
                    ("LEFTPADDING", (0, 0), (-1, -1), 4),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                    ("TOPPADDING", (0, 0), (-1, -1), 3),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ]
            )
        )
        story.append(table)
        story.append(Spacer(1, 4 * mm))
        total_table = Table(
            [["Page total", f"{page_total:.2f}"]],
            colWidths=[35 * mm, 30 * mm],
            hAlign="RIGHT",
        )
        total_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#EAF2FF")),
                    ("TEXTCOLOR", (0, 0), (-1, -1), colors.HexColor("#102A43")),
                    ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 9),
                    ("ALIGN", (1, 0), (1, 0), "RIGHT"),
                    ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#8DB3E2")),
                    ("TOPPADDING", (0, 0), (-1, -1), 5),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ]
            )
        )
        story.append(total_table)
        if page_number < 4:
            story.append(PageBreak())
    doc.build(story, canvasmaker=InvariantCanvas)


def main() -> None:
    FIXTURES.mkdir(parents=True, exist_ok=True)
    records = build_records()
    build_pdf(records)
    SOURCE_RECORDS.write_text(json.dumps(records, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    page_totals = {
        str(page): round(sum(float(r["source_amount"]) for r in records if r["source_page"] == page), 2)
        for page in range(1, 5)
    }
    manifest = {
        "fixture_kind": "synthetic_pdf_to_excel_source",
        "source_pdf": SOURCE_PDF.name,
        "source_pdf_sha256": sha256(SOURCE_PDF),
        "page_count": 4,
        "record_count": len(records),
        "page_totals": page_totals,
        "grand_total": round(sum(float(r["source_amount"]) for r in records), 2),
        "deliberate_review_records": ["SR-0023"],
        "contains_customer_data": False,
    }
    SOURCE_MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(manifest, sort_keys=True))


if __name__ == "__main__":
    main()
