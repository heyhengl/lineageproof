# PDF-to-Excel Auditable Conversion Proof

This portfolio sample uses entirely synthetic service records. It demonstrates a controlled conversion from a four-page text/table PDF into a filter-ready Excel workbook without claiming customer work or unsupported OCR accuracy.

## What it proves

- Preserves all 36 source records in original page/order sequence.
- Normalizes wrapped PDF cell text into legible single-line Excel values.
- Reconciles record counts and source amounts on every page.
- Leaves one deliberately unclear unit-rate token blank and records it in `Issues` instead of guessing.
- Produces a workbook with source provenance, formulas, filters, page QA, and an issue register.

## Rebuild

Use the bundled Codex Python, Node.js, and `@oai/artifact-tool` runtime. Create a temporary `node_modules` symlink in this directory before running the workbook builder.

```bash
python3 generate_source.py
python3 extract_pdf.py
node build_workbook.mjs
python3 normalize_xlsx.py
node verify_workbook.mjs
python3 build_case_study.py
python3 package_proof.py
python3 -m unittest tests/test_pdf_to_excel.py
```

The source PDF, source records, and all values are fictional. No customer data, credentials, macros, links, or private trading logic are included.
