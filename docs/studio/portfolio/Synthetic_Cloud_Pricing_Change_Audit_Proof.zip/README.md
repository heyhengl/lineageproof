# Synthetic Cloud Pricing Change QA

This is an offline, synthetic proof for normalizing AWS and Azure retail price
payloads, storing the current snapshot in SQLite, and producing deterministic
new/removed/price-changed results.

It contains no account, credential, customer data, production endpoint, or
claim of a live provider deployment. The fixtures are deliberately marked
`synthetic_fixture: true`, and the runner refuses an unmarked payload.

## Architecture boundary

- Price ingestion is API-first. AWS exposes the Price List Query API and Azure
  exposes the unauthenticated Retail Prices API.
- Browser automation belongs in a separate UI-contract layer for calculator
  page behavior. It is not used as the primary price authority when a provider
  API exists.
- This proof exercises provider adapters, schema validation, deduplication,
  daily comparison, CSV reports, SQLite persistence, and a reproducible run
  receipt. It does not call either provider.

Official references:

- AWS `GetProducts`: https://docs.aws.amazon.com/aws-cost-management/latest/APIReference/API_pricing_GetProducts.html
- Azure Retail Prices: https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices

## Build the proof

```bash
python3 cloud_pricing_audit.py \
  --aws-previous fixtures/aws_previous.json \
  --aws-current fixtures/aws_current.json \
  --azure-previous fixtures/azure_previous.json \
  --azure-current fixtures/azure_current.json \
  --as-of 2026-08-08T22:30:00+08:00 \
  --output dist
```

Expected synthetic result:

- previous/current unique records: `4/5`
- new/removed/price-changed/unchanged: `2/1/2/1`
- current duplicate rows: `1`

## Verify

```bash
python3 -m unittest discover -s tests -v
```

The generated `dist/` directory contains `current_snapshot.csv`,
`changes.csv`, `summary.json`, and `audit.sqlite`.
