from __future__ import annotations

import json
import sqlite3
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from cloud_pricing_audit import (  # noqa: E402
    build_audit,
    compare_snapshots,
    load_synthetic_payload,
    normalize_aws,
    normalize_azure,
    validate_and_deduplicate,
)


FIXTURES = ROOT / "fixtures"


class CloudPricingAuditTests(unittest.TestCase):
    def test_refuses_unmarked_payload(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "payload.json"
            path.write_text('{"Items": []}', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "refusing unmarked"):
                load_synthetic_payload(path)

    def test_aws_adapter_normalizes_price_and_identity(self) -> None:
        records = normalize_aws(load_synthetic_payload(FIXTURES / "aws_previous.json"))
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0]["provider"], "aws")
        self.assertEqual(records[0]["hourly_price"], "0.0208")
        self.assertEqual(records[0]["region"], "us-east-1")

    def test_azure_adapter_infers_explicit_linux_product(self) -> None:
        records = normalize_azure(
            load_synthetic_payload(FIXTURES / "azure_previous.json")
        )
        self.assertEqual(len(records), 2)
        self.assertTrue(all(record["operating_system"] == "Linux" for record in records))

    def test_duplicate_row_is_reported_and_removed(self) -> None:
        raw = normalize_azure(load_synthetic_payload(FIXTURES / "azure_current.json"))
        unique, duplicates, invalid = validate_and_deduplicate(raw)
        self.assertEqual(len(raw), 4)
        self.assertEqual(len(unique), 3)
        self.assertEqual(len(duplicates), 1)
        self.assertTrue(duplicates[0]["same_price"])
        self.assertEqual(invalid, [])

    def test_comparison_has_expected_change_classes(self) -> None:
        previous_raw = normalize_aws(
            load_synthetic_payload(FIXTURES / "aws_previous.json")
        ) + normalize_azure(load_synthetic_payload(FIXTURES / "azure_previous.json"))
        current_raw = normalize_aws(
            load_synthetic_payload(FIXTURES / "aws_current.json")
        ) + normalize_azure(load_synthetic_payload(FIXTURES / "azure_current.json"))
        previous, _, _ = validate_and_deduplicate(previous_raw)
        current, _, _ = validate_and_deduplicate(current_raw)
        statuses = [row["status"] for row in compare_snapshots(previous, current)]
        self.assertEqual(statuses.count("new"), 2)
        self.assertEqual(statuses.count("removed"), 1)
        self.assertEqual(statuses.count("price_changed"), 2)
        self.assertEqual(statuses.count("unchanged"), 1)

    def test_build_writes_reproducible_reports_and_sqlite(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "dist"
            summary = build_audit(
                aws_previous=FIXTURES / "aws_previous.json",
                aws_current=FIXTURES / "aws_current.json",
                azure_previous=FIXTURES / "azure_previous.json",
                azure_current=FIXTURES / "azure_current.json",
                as_of=datetime.fromisoformat("2026-08-08T22:30:00+08:00"),
                output=output,
            )
            self.assertEqual(summary["previous"]["unique_records"], 4)
            self.assertEqual(summary["current"]["unique_records"], 5)
            self.assertEqual(
                summary["change_counts"],
                {"new": 2, "removed": 1, "price_changed": 2, "unchanged": 1},
            )
            self.assertEqual(summary["current"]["duplicate_records"], 1)
            saved = json.loads((output / "summary.json").read_text(encoding="utf-8"))
            self.assertEqual(
                saved["run_receipt"]["receipt_sha256"],
                summary["run_receipt"]["receipt_sha256"],
            )
            with sqlite3.connect(output / "audit.sqlite") as connection:
                snapshot_count = connection.execute(
                    "SELECT COUNT(*) FROM pricing_snapshot"
                ).fetchone()[0]
                change_count = connection.execute(
                    "SELECT COUNT(*) FROM pricing_change"
                ).fetchone()[0]
                receipt_count = connection.execute(
                    "SELECT COUNT(*) FROM run_receipt"
                ).fetchone()[0]
            self.assertEqual((snapshot_count, change_count, receipt_count), (5, 6, 1))


if __name__ == "__main__":
    unittest.main()
