#!/usr/bin/env python3
"""Build a deterministic audit from synthetic AWS and Azure price payloads."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
from collections import Counter
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable


FIELDS = (
    "provider",
    "sku",
    "instance_type",
    "region",
    "operating_system",
    "price_type",
    "currency",
    "unit",
    "hourly_price",
    "last_updated",
)
KEY_FIELDS = (
    "provider",
    "sku",
    "region",
    "operating_system",
    "price_type",
    "currency",
    "unit",
)
REQUIRED_FIELDS = KEY_FIELDS + ("hourly_price",)


def parse_timestamp(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError(f"timestamp must include a timezone: {value}")
    return parsed


def decimal_text(value: Any) -> str:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"invalid price: {value!r}") from exc
    if not number.is_finite() or number < 0:
        raise ValueError(f"invalid price: {value!r}")
    return format(number.normalize(), "f")


def load_synthetic_payload(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("synthetic_fixture") is not True:
        raise ValueError(f"refusing unmarked non-synthetic payload: {path}")
    return payload


def _aws_price_dimensions(product: dict[str, Any]) -> Iterable[dict[str, Any]]:
    for term in (product.get("terms") or {}).get("OnDemand", {}).values():
        for dimension in (term.get("priceDimensions") or {}).values():
            yield dimension


def normalize_aws(payload: dict[str, Any]) -> list[dict[str, str]]:
    publication = str(payload.get("PublicationDate") or "")
    records: list[dict[str, str]] = []
    for encoded in payload.get("PriceList") or []:
        item = json.loads(encoded) if isinstance(encoded, str) else encoded
        product = item.get("product") or {}
        attrs = product.get("attributes") or {}
        for dimension in _aws_price_dimensions(item):
            price_per_unit = dimension.get("pricePerUnit") or {}
            if "USD" not in price_per_unit:
                continue
            records.append(
                {
                    "provider": "aws",
                    "sku": str(product.get("sku") or ""),
                    "instance_type": str(attrs.get("instanceType") or ""),
                    "region": str(attrs.get("regionCode") or attrs.get("location") or ""),
                    "operating_system": str(attrs.get("operatingSystem") or "not_explicit"),
                    "price_type": "OnDemand",
                    "currency": "USD",
                    "unit": str(dimension.get("unit") or ""),
                    "hourly_price": decimal_text(price_per_unit["USD"]),
                    "last_updated": str(item.get("publicationDate") or publication),
                }
            )
    return records


def _azure_operating_system(item: dict[str, Any]) -> str:
    explicit = item.get("operatingSystem")
    if explicit:
        return str(explicit)
    product = str(item.get("productName") or "").casefold()
    if "windows" in product:
        return "Windows"
    if "linux" in product:
        return "Linux"
    return "not_explicit"


def normalize_azure(payload: dict[str, Any]) -> list[dict[str, str]]:
    records: list[dict[str, str]] = []
    for item in payload.get("Items") or []:
        records.append(
            {
                "provider": "azure",
                "sku": str(item.get("skuId") or item.get("armSkuName") or ""),
                "instance_type": str(item.get("armSkuName") or item.get("skuName") or ""),
                "region": str(item.get("armRegionName") or ""),
                "operating_system": _azure_operating_system(item),
                "price_type": str(item.get("priceType") or item.get("type") or ""),
                "currency": str(item.get("currencyCode") or ""),
                "unit": str(item.get("unitOfMeasure") or ""),
                "hourly_price": decimal_text(item.get("retailPrice")),
                "last_updated": str(item.get("effectiveStartDate") or ""),
            }
        )
    return records


def record_key(record: dict[str, str]) -> tuple[str, ...]:
    return tuple(record[field] for field in KEY_FIELDS)


def validate_and_deduplicate(
    records: Iterable[dict[str, str]],
) -> tuple[list[dict[str, str]], list[dict[str, Any]], list[dict[str, Any]]]:
    unique: dict[tuple[str, ...], dict[str, str]] = {}
    duplicates: list[dict[str, Any]] = []
    invalid: list[dict[str, Any]] = []
    for index, record in enumerate(records):
        missing = [field for field in REQUIRED_FIELDS if not record.get(field)]
        if missing:
            invalid.append({"row": index, "missing_fields": missing})
            continue
        key = record_key(record)
        if key in unique:
            duplicates.append(
                {
                    "key": list(key),
                    "same_price": unique[key]["hourly_price"] == record["hourly_price"],
                }
            )
            continue
        unique[key] = record
    ordered = [unique[key] for key in sorted(unique)]
    return ordered, duplicates, invalid


def compare_snapshots(
    previous: list[dict[str, str]],
    current: list[dict[str, str]],
) -> list[dict[str, str]]:
    old = {record_key(record): record for record in previous}
    new = {record_key(record): record for record in current}
    changes: list[dict[str, str]] = []
    for key in sorted(set(old) | set(new)):
        before = old.get(key)
        after = new.get(key)
        if before is None:
            status = "new"
        elif after is None:
            status = "removed"
        elif before["hourly_price"] != after["hourly_price"]:
            status = "price_changed"
        else:
            status = "unchanged"
        base = after or before
        assert base is not None
        changes.append(
            {
                **{field: base[field] for field in KEY_FIELDS},
                "status": status,
                "previous_price": before["hourly_price"] if before else "",
                "current_price": after["hourly_price"] if after else "",
            }
        )
    return changes


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def write_csv(path: Path, rows: list[dict[str, str]], fields: Iterable[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fields),
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def write_sqlite(
    path: Path,
    *,
    current: list[dict[str, str]],
    changes: list[dict[str, str]],
    receipt: dict[str, Any],
) -> None:
    if path.exists():
        path.unlink()
    with sqlite3.connect(path) as connection:
        connection.execute(
            "CREATE TABLE pricing_snapshot ("
            + ", ".join(f"{field} TEXT NOT NULL" for field in FIELDS)
            + ")"
        )
        connection.executemany(
            "INSERT INTO pricing_snapshot VALUES (" + ",".join("?" for _ in FIELDS) + ")",
            [tuple(row[field] for field in FIELDS) for row in current],
        )
        change_fields = KEY_FIELDS + ("status", "previous_price", "current_price")
        connection.execute(
            "CREATE TABLE pricing_change ("
            + ", ".join(f"{field} TEXT NOT NULL" for field in change_fields)
            + ")"
        )
        connection.executemany(
            "INSERT INTO pricing_change VALUES ("
            + ",".join("?" for _ in change_fields)
            + ")",
            [tuple(row[field] for field in change_fields) for row in changes],
        )
        connection.execute(
            "CREATE TABLE run_receipt (as_of TEXT NOT NULL, receipt_sha256 TEXT NOT NULL, payload TEXT NOT NULL)"
        )
        connection.execute(
            "INSERT INTO run_receipt VALUES (?, ?, ?)",
            (receipt["as_of"], receipt["receipt_sha256"], json.dumps(receipt, sort_keys=True)),
        )


def build_audit(
    *,
    aws_previous: Path,
    aws_current: Path,
    azure_previous: Path,
    azure_current: Path,
    as_of: datetime,
    output: Path,
) -> dict[str, Any]:
    if as_of.tzinfo is None:
        raise ValueError("as_of must include a timezone")
    payloads = {
        "aws_previous": load_synthetic_payload(aws_previous),
        "aws_current": load_synthetic_payload(aws_current),
        "azure_previous": load_synthetic_payload(azure_previous),
        "azure_current": load_synthetic_payload(azure_current),
    }
    previous_raw = normalize_aws(payloads["aws_previous"]) + normalize_azure(
        payloads["azure_previous"]
    )
    current_raw = normalize_aws(payloads["aws_current"]) + normalize_azure(
        payloads["azure_current"]
    )
    previous, previous_duplicates, previous_invalid = validate_and_deduplicate(previous_raw)
    current, current_duplicates, current_invalid = validate_and_deduplicate(current_raw)
    changes = compare_snapshots(previous, current)
    counts = Counter(change["status"] for change in changes)

    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "current_snapshot.csv", current, FIELDS)
    change_fields = KEY_FIELDS + ("status", "previous_price", "current_price")
    write_csv(output / "changes.csv", changes, change_fields)

    receipt_base = {
        "as_of": as_of.isoformat(),
        "source_mode": "synthetic_offline_only",
        "previous_sha256": canonical_hash(previous),
        "current_sha256": canonical_hash(current),
        "changes_sha256": canonical_hash(changes),
    }
    receipt = {**receipt_base, "receipt_sha256": canonical_hash(receipt_base)}
    summary = {
        "schema_version": 1,
        "as_of": as_of.isoformat(),
        "source_mode": "synthetic_offline_only",
        "previous": {
            "raw_records": len(previous_raw),
            "unique_records": len(previous),
            "duplicate_records": len(previous_duplicates),
            "invalid_records": len(previous_invalid),
        },
        "current": {
            "raw_records": len(current_raw),
            "unique_records": len(current),
            "duplicate_records": len(current_duplicates),
            "invalid_records": len(current_invalid),
        },
        "change_counts": {
            name: counts.get(name, 0)
            for name in ("new", "removed", "price_changed", "unchanged")
        },
        "duplicates": {
            "previous": previous_duplicates,
            "current": current_duplicates,
        },
        "invalid": {
            "previous": previous_invalid,
            "current": current_invalid,
        },
        "run_receipt": receipt,
    }
    (output / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    write_sqlite(output / "audit.sqlite", current=current, changes=changes, receipt=receipt)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--aws-previous", type=Path, required=True)
    parser.add_argument("--aws-current", type=Path, required=True)
    parser.add_argument("--azure-previous", type=Path, required=True)
    parser.add_argument("--azure-current", type=Path, required=True)
    parser.add_argument("--as-of", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    summary = build_audit(
        aws_previous=args.aws_previous,
        aws_current=args.aws_current,
        azure_previous=args.azure_previous,
        azure_current=args.azure_current,
        as_of=parse_timestamp(args.as_of),
        output=args.output,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
