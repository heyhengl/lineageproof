import csv
import json
import shutil
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

SAMPLE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SAMPLE_ROOT))

from import_products import run_import


class ProductImportTest(unittest.TestCase):
    def run_sample(self, temporary_root: Path, run_at: str, fixtures: Path = SAMPLE_ROOT / "fixtures") -> dict:
        return run_import(
            fixtures,
            temporary_root / "catalog.sqlite",
            temporary_root / "products.csv",
            temporary_root / "rejects.json",
            temporary_root / "run_report.json",
            run_at,
        )

    def test_validates_reconciles_and_quarantines(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            report = self.run_sample(root, "2026-07-17T00:00:00+00:00")

            self.assertEqual(report["status"], "pass_with_rejects")
            self.assertTrue(report["row_count_reconciled"])
            self.assertEqual(report["totals"]["input"], 8)
            self.assertEqual(report["totals"]["accepted"], 6)
            self.assertEqual(report["totals"]["inserted"], 6)
            self.assertEqual(report["totals"]["updated"], 0)
            self.assertEqual(report["totals"]["rejected"], 2)
            self.assertEqual(report["totals"]["catalog_count"], 6)

            rejects = json.loads((root / "rejects.json").read_text(encoding="utf-8"))
            self.assertEqual({item["sku"] for item in rejects}, {"A-100", "B-BAD"})
            self.assertTrue(all(set(item) == {"source", "row_number", "sku", "error"} for item in rejects))

            with (root / "products.csv").open(encoding="utf-8", newline="") as product_file:
                rows = list(csv.DictReader(product_file))
            self.assertEqual([row["sku"] for row in rows], sorted(row["sku"] for row in rows))
            self.assertEqual(next(row for row in rows if row["sku"] == "B-200")["price_cents"], "2499")

    def test_second_run_updates_without_duplicates(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            self.run_sample(root, "2026-07-17T00:00:00+00:00")
            report = self.run_sample(root, "2026-07-18T00:00:00+00:00")

            self.assertEqual(report["totals"]["inserted"], 0)
            self.assertEqual(report["totals"]["updated"], 6)
            self.assertEqual(report["totals"]["catalog_count"], 6)
            with sqlite3.connect(root / "catalog.sqlite") as connection:
                count, distinct_count = connection.execute(
                    "SELECT COUNT(*), COUNT(DISTINCT sku) FROM products"
                ).fetchone()
            self.assertEqual((count, distinct_count), (6, 6))

    def test_one_unavailable_feed_does_not_block_other_sources(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            run_root = root / "run"
            self.run_sample(run_root, "2026-07-16T00:00:00+00:00")
            fixtures = root / "fixtures"
            shutil.copytree(SAMPLE_ROOT / "fixtures", fixtures)
            (fixtures / "source_c.xml").unlink()

            report = self.run_sample(run_root, "2026-07-17T00:00:00+00:00", fixtures)

            self.assertEqual(report["status"], "partial_failure")
            self.assertEqual(report["totals"]["input"], 5)
            self.assertEqual(report["totals"]["accepted"], 4)
            self.assertEqual(report["totals"]["rejected"], 1)
            self.assertEqual(report["totals"]["catalog_count"], 6)
            self.assertEqual(report["totals"]["updated"], 4)
            self.assertEqual(
                report["source_failures"],
                [
                    {
                        "source": "xml-store",
                        "error_type": "FileNotFoundError",
                        "error": "feed unavailable or unreadable",
                    }
                ],
            )


if __name__ == "__main__":
    unittest.main()
