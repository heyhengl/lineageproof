#!/usr/bin/env python3
"""Normalize three synthetic product feeds into an idempotent SQLite catalog."""

from __future__ import annotations

import argparse
import csv
import json
import re
import sqlite3
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

SKU_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9-]{1,31}$")
OUTPUT_COLUMNS = [
    "sku",
    "source",
    "name",
    "description",
    "price_cents",
    "inventory",
    "options_json",
    "image_url",
]


def clean_text(value: Any) -> str:
    return " ".join(str(value or "").split())


def load_json_feed(path: Path) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return [
        {
            "source": "json-store",
            "sku": item.get("sku"),
            "name": item.get("name"),
            "description": item.get("description"),
            "price": item.get("price"),
            "inventory": item.get("inventory"),
            "options": item.get("options", []),
            "image_url": item.get("image_url"),
        }
        for item in payload["products"]
    ]


def load_csv_feed(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8", newline="") as feed_file:
        rows = list(csv.DictReader(feed_file))
    return [
        {
            "source": "csv-store",
            "sku": row.get("product_code"),
            "name": row.get("title"),
            "description": row.get("details"),
            "price": Decimal(row["price_cents"]) / Decimal(100),
            "inventory": row.get("stock"),
            "options": row.get("variants", "").split("|") if row.get("variants") else [],
            "image_url": row.get("image"),
        }
        for row in rows
    ]


def load_xml_feed(path: Path) -> list[dict[str, Any]]:
    root = ET.parse(path).getroot()
    return [
        {
            "source": "xml-store",
            "sku": item.get("code"),
            "name": item.findtext("title"),
            "description": item.findtext("summary"),
            "price": item.findtext("price"),
            "inventory": item.findtext("quantity"),
            "options": [node.text or "" for node in item.findall("./options/option")],
            "image_url": item.findtext("image"),
        }
        for item in root.findall("product")
    ]


def normalize_product(raw: dict[str, Any]) -> dict[str, Any]:
    sku = clean_text(raw.get("sku")).upper()
    if not SKU_PATTERN.fullmatch(sku):
        raise ValueError("sku must contain 2-32 uppercase letters, digits, or hyphens")

    name = clean_text(raw.get("name"))
    if not name:
        raise ValueError("name is required")

    try:
        price = Decimal(str(raw.get("price"))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except (InvalidOperation, ValueError):
        raise ValueError("price must be a decimal number") from None
    if price < 0:
        raise ValueError("price must be non-negative")

    try:
        inventory = int(str(raw.get("inventory")))
    except (TypeError, ValueError):
        raise ValueError("inventory must be an integer") from None
    if inventory < 0:
        raise ValueError("inventory must be non-negative")

    image_url = clean_text(raw.get("image_url"))
    parsed_image = urlparse(image_url)
    if parsed_image.scheme not in {"http", "https"} or not parsed_image.netloc:
        raise ValueError("image_url must be an absolute HTTP(S) URL")

    options = sorted({clean_text(value) for value in raw.get("options", []) if clean_text(value)})
    return {
        "sku": sku,
        "source": clean_text(raw.get("source")),
        "name": name,
        "description": clean_text(raw.get("description")),
        "price_cents": int(price * 100),
        "inventory": inventory,
        "options_json": json.dumps(options, ensure_ascii=False, separators=(",", ":")),
        "image_url": image_url,
    }


def initialize_database(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS products (
            sku TEXT PRIMARY KEY,
            source TEXT NOT NULL,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            price_cents INTEGER NOT NULL CHECK(price_cents >= 0),
            inventory INTEGER NOT NULL CHECK(inventory >= 0),
            options_json TEXT NOT NULL,
            image_url TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )


def export_catalog(connection: sqlite3.Connection, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    rows = connection.execute(
        "SELECT sku, source, name, description, price_cents, inventory, options_json, image_url "
        "FROM products ORDER BY sku"
    ).fetchall()
    with output.open("w", encoding="utf-8", newline="") as output_file:
        writer = csv.writer(output_file)
        writer.writerow(OUTPUT_COLUMNS)
        writer.writerows(rows)


def source_specs(
    fixtures: Path,
) -> list[tuple[str, Callable[[Path], list[dict[str, Any]]], Path]]:
    return [
        ("json-store", load_json_feed, fixtures / "source_a.json"),
        ("csv-store", load_csv_feed, fixtures / "source_b.csv"),
        ("xml-store", load_xml_feed, fixtures / "source_c.xml"),
    ]


def run_import(
    fixtures: Path,
    database: Path,
    output: Path,
    rejects_output: Path,
    report_output: Path,
    run_at: str,
) -> dict[str, Any]:
    database.parent.mkdir(parents=True, exist_ok=True)
    rejects: list[dict[str, Any]] = []
    source_counts: dict[str, dict[str, int]] = {}
    inserted = 0
    updated = 0
    accepted = 0
    seen_sources_by_sku: dict[str, str] = {}
    source_failures: list[dict[str, str]] = []

    with sqlite3.connect(database) as connection:
        initialize_database(connection)
        for expected_source, loader, source_path in source_specs(fixtures):
            try:
                raw_products = loader(source_path)
            except (OSError, KeyError, json.JSONDecodeError, csv.Error, ET.ParseError, InvalidOperation) as error:
                source_counts[expected_source] = {
                    "input": 0,
                    "accepted": 0,
                    "rejected": 0,
                    "failed": 1,
                }
                source_failures.append(
                    {
                        "source": expected_source,
                        "error_type": type(error).__name__,
                        "error": "feed unavailable or unreadable",
                    }
                )
                continue

            counts = {"input": len(raw_products), "accepted": 0, "rejected": 0, "failed": 0}
            source_counts[expected_source] = counts
            for row_number, raw in enumerate(raw_products, start=1):
                candidate_sku = clean_text(raw.get("sku")).upper()
                try:
                    product = normalize_product(raw)
                    prior_run_source = seen_sources_by_sku.get(product["sku"])
                    if prior_run_source is not None:
                        raise ValueError(f"duplicate sku also supplied by {prior_run_source}")

                    existing = connection.execute(
                        "SELECT source FROM products WHERE sku = ?", (product["sku"],)
                    ).fetchone()
                    if existing is not None and existing[0] != product["source"]:
                        raise ValueError(f"sku already owned by source {existing[0]}")

                    connection.execute(
                        """
                        INSERT INTO products (
                            sku, source, name, description, price_cents, inventory,
                            options_json, image_url, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(sku) DO UPDATE SET
                            source = excluded.source,
                            name = excluded.name,
                            description = excluded.description,
                            price_cents = excluded.price_cents,
                            inventory = excluded.inventory,
                            options_json = excluded.options_json,
                            image_url = excluded.image_url,
                            updated_at = excluded.updated_at
                        """,
                        tuple(product[column] for column in OUTPUT_COLUMNS) + (run_at,),
                    )
                    seen_sources_by_sku[product["sku"]] = product["source"]
                    inserted += int(existing is None)
                    updated += int(existing is not None)
                    accepted += 1
                    counts["accepted"] += 1
                except (InvalidOperation, ValueError) as error:
                    rejects.append(
                        {
                            "source": expected_source,
                            "row_number": row_number,
                            "sku": candidate_sku,
                            "error": str(error),
                        }
                    )
                    counts["rejected"] += 1

        catalog_count = connection.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        connection.commit()
        export_catalog(connection, output)

    rejects_output.parent.mkdir(parents=True, exist_ok=True)
    rejects_output.write_text(json.dumps(rejects, indent=2) + "\n", encoding="utf-8")
    report = {
        "run_at": run_at,
        "sources": source_counts,
        "source_failures": source_failures,
        "totals": {
            "input": sum(item["input"] for item in source_counts.values()),
            "accepted": accepted,
            "inserted": inserted,
            "updated": updated,
            "rejected": len(rejects),
            "catalog_count": catalog_count,
        },
        "row_count_reconciled": accepted + len(rejects)
        == sum(item["input"] for item in source_counts.values()),
        "status": (
            "partial_failure"
            if source_failures
            else "pass_with_rejects"
            if rejects
            else "pass"
        ),
    }
    report_output.parent.mkdir(parents=True, exist_ok=True)
    report_output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def parse_arguments() -> argparse.Namespace:
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures", type=Path, default=root / "fixtures")
    parser.add_argument("--database", type=Path, default=root / "dist" / "catalog.sqlite")
    parser.add_argument("--output", type=Path, default=root / "dist" / "products.csv")
    parser.add_argument("--rejects", type=Path, default=root / "dist" / "rejects.json")
    parser.add_argument("--report", type=Path, default=root / "dist" / "run_report.json")
    parser.add_argument(
        "--run-at",
        default=datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        help="ISO-8601 run timestamp stored on accepted rows",
    )
    parser.add_argument("--reset", action="store_true", help="remove the sample database before running")
    return parser.parse_args()


def main() -> None:
    arguments = parse_arguments()
    if arguments.reset and arguments.database.exists():
        arguments.database.unlink()
    report = run_import(
        arguments.fixtures,
        arguments.database,
        arguments.output,
        arguments.rejects,
        arguments.report,
        arguments.run_at,
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
