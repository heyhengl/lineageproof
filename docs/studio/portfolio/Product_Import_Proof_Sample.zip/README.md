# Three-Source Product Import Proof

This synthetic sample demonstrates a scheduled product-import workflow without contacting real websites or using client credentials. Three adapters read representative JSON, CSV, and XML feeds, normalize them to one schema, validate required fields, quarantine invalid or conflicting records, and idempotently upsert accepted products into SQLite.

## What it proves

- source-specific adapters can feed one normalized product model;
- prices are stored as integer cents rather than binary floating-point values;
- required fields, inventory, image URLs, variants, and duplicate SKUs are validated;
- invalid records are quarantined with bounded diagnostic fields instead of raw payload dumps;
- repeated runs update existing products instead of duplicating them;
- a normalized CSV export and machine-readable run report are produced;
- the implementation and tests use only the Python standard library.

The fixtures are fictional. This sample does not claim that an unknown site can be scraped lawfully or reliably before its API, feed, authentication, rate limits, robots policy, and terms are reviewed.

## Reproduce

```bash
python3 import_products.py --reset --run-at 2026-07-17T00:00:00+00:00
python3 -m unittest -v tests/test_import_products.py
```

Generated artifacts are written under `dist/`:

- `catalog.sqlite` - idempotent target catalog;
- `products.csv` - normalized, sorted export;
- `rejects.json` - validation and conflict quarantine;
- `run_report.json` - source and reconciliation counts.

`cron.example` shows a deployment shape only. Production scheduling must use a dedicated low-privilege account, environment-based secrets, source-specific backoff, permitted APIs/feeds where available, and a monitored failure channel.
