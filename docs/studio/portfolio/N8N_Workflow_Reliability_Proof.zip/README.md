# Synthetic n8n workflow reliability proof

This package contains one owned, synthetic and inactive n8n workflow export, ten deterministic fixture receipts and a Node.js verifier. It is published to make the service claim inspectable; it is not client work, a production deployment or evidence of throughput.

## Verify

From this directory, run:

```sh
node verify_intake_workflow.mjs
```

Expected summary:

- workflow active: `false`
- nodes: `7`
- fixture receipts: `10`
- adversarial cases: `3`
- credential bindings: `0`
- external-action nodes: `0`
- execution persistence: disabled by workflow settings

The verifier executes the embedded Code node against every frozen fixture, then checks a prohibited secret-like field, an unsupported field and an invalid root. The secret-like adversarial value uses the reserved `.invalid` domain and must not appear in the returned receipt.

## Boundaries

- Do not activate this export as published.
- It contains no credential binding, production identifier, private URL, customer data or external-action node.
- Authentication, request-size limits, rate limiting, retention, instance policy and isolated private deployment are outside this proof.
- Any paid sample begins with a separately supplied inactive export and sanitized fixture shapes. Do not share credentials, real execution payloads, private URLs or customer records in a public issue.
- This proof and its USD 249 opening scope are not an order, invoice or revenue event.
