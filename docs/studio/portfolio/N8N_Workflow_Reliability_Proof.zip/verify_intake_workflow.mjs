#!/usr/bin/env node

import assert from "node:assert/strict";
import crypto from "node:crypto";
import fs from "node:fs";

const root = new URL("./", import.meta.url);
const readJson = (name) => JSON.parse(fs.readFileSync(new URL(name, root), "utf8"));
const workflow = readJson("commerce-ops-metadata-intake.json");
const fixtures = readJson("commerce-ops-metadata-intake-fixtures.json");
const template = fs.readFileSync(new URL("intake_router_code.js", root), "utf8");
const compact = (value) => JSON.stringify(value, Object.keys(value).sort());
const stable = (value) => {
  if (Array.isArray(value)) return value.map(stable);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.keys(value).sort().map((key) => [key, stable(value[key])]));
};
const embeddedSource = template
  .replace("__CATALOG_JSON__", JSON.stringify(stable(fixtures.catalog)))
  .replace("__SCHEMA_JSON__", JSON.stringify(stable(fixtures.schema)));

assert.equal(workflow.active, false);
assert.equal(workflow.name, "Commerce Ops - Metadata Intake Draft Quote");
assert.deepEqual(new Set(workflow.nodes.map((node) => node.name)), new Set([
  "Receive Metadata-only Intake", "Route Metadata-only Intake", "Accepted?", "Out of Scope?",
  "Return Draft Quote", "Return Correction Required", "Return Out of Scope",
]));
assert.deepEqual(new Set(workflow.nodes.map((node) => node.type)), new Set([
  "n8n-nodes-base.webhook", "n8n-nodes-base.code", "n8n-nodes-base.if", "n8n-nodes-base.respondToWebhook",
]));
assert.equal(workflow.nodes.some((node) => Object.hasOwn(node, "credentials")), false);
const webhook = workflow.nodes.find((node) => node.name === "Receive Metadata-only Intake");
assert.equal(webhook.parameters.path, "commerce-ops-draft-intake");
assert.equal(webhook.parameters.responseMode, "responseNode");
const router = workflow.nodes.find((node) => node.name === "Route Metadata-only Intake");
assert.equal(router.parameters.jsCode, embeddedSource);

for (const gate of [
  "publicDeploymentAllowed", "automaticAcceptanceAllowed", "paymentActionAllowed", "accountActionAllowed",
]) assert.equal(workflow.meta[gate], false, `${gate} must remain false`);
for (const gate of ["authenticationRequiredBeforeActivation", "rateLimitRequiredBeforeActivation", "inputPersistenceDisabled"]) {
  assert.equal(workflow.meta[gate], true, `${gate} must remain true`);
}
assert.equal(workflow.settings.saveDataSuccessExecution, "none");
assert.equal(workflow.settings.saveDataErrorExecution, "none");
assert.equal(workflow.settings.saveExecutionProgress, false);
assert.equal(workflow.settings.saveManualExecutions, false);

const responseCodes = Object.fromEntries(workflow.nodes
  .filter((node) => node.type === "n8n-nodes-base.respondToWebhook")
  .map((node) => [node.name, node.parameters.options.responseCode]));
assert.deepEqual(responseCodes, {
  "Return Draft Quote": 200,
  "Return Correction Required": 422,
  "Return Out of Scope": 422,
});
const expectedConnections = {
  "Receive Metadata-only Intake": ["Route Metadata-only Intake"],
  "Route Metadata-only Intake": ["Accepted?"],
  "Accepted?": ["Return Draft Quote", "Out of Scope?"],
  "Out of Scope?": ["Return Out of Scope", "Return Correction Required"],
};
for (const [source, expected] of Object.entries(expectedConnections)) {
  const actual = workflow.connections[source].main.flat().map((edge) => edge.node);
  assert.deepEqual(actual, expected);
}

const intakeArchive = fs.readFileSync(new URL("../intake/commerce-ops-intake-contract-0.1.zip", root));
const releaseSha256 = crypto.createHash("sha256").update(intakeArchive).digest("hex");
assert.equal(releaseSha256, fixtures.contractReleaseSha256);
assert.equal(releaseSha256, workflow.meta.contractReleaseSha256);
assert.equal(fixtures.manifest.exampleCount, 10);
assert.equal(fixtures.cases.length, 10);

const execute = new Function("$json", `"use strict"; return (async () => { ${router.parameters.jsCode} })();`);
const dispositions = { accepted: 0, needs_correction: 0, out_of_scope: 0 };
let buyerEvidenceReceipts = 0;
let amazonBuyerEvidenceReceipts = 0;
let catalogBuyerEvidenceReceipts = 0;
let commerceBuyerEvidenceReceipts = 0;
let merchantBuyerEvidenceReceipts = 0;
let procurementBuyerEvidenceReceipts = 0;
for (const testCase of fixtures.cases) {
  const items = await execute({ body: testCase.request });
  assert.equal(items.length, 1, `${testCase.name}: exactly one receipt required`);
  assert.deepEqual(items[0].json, testCase.receipt, `${testCase.name}: Python and n8n receipt mismatch`);
  dispositions[items[0].json.disposition] += 1;
  assert.equal(items[0].json.automaticAcceptanceAllowed, false);
  assert.equal(items[0].json.paymentActionAllowed, false);
  assert.equal(items[0].json.accountActionAllowed, false);
  assert.equal(items[0].json.inputPersisted, false);
  if (items[0].json.quote) assert.equal(items[0].json.quote.requiresManualAcceptance, true);
  const receipt = items[0].json;
  const catalogProduct = receipt.product
    ? fixtures.catalog.products.find((product) => product.id === receipt.product.id)
    : null;
  if (
    receipt.disposition === 'accepted'
    && receipt.product.requestedTier !== 'workflow_deployment'
    && catalogProduct?.buyerEvidence
  ) {
    buyerEvidenceReceipts += 1;
    if (receipt.product.id === 'catalog-qa-shopify') catalogBuyerEvidenceReceipts += 1;
    if (receipt.product.id === 'commerce-reconciliation') commerceBuyerEvidenceReceipts += 1;
    if (receipt.product.id === 'amazon-settlement-v2-reconciliation') {
      amazonBuyerEvidenceReceipts += 1;
    }
    if (receipt.product.id === 'google-merchant-landing-page-parity') {
      merchantBuyerEvidenceReceipts += 1;
    }
    if (receipt.product.id === 'procurement-document-reconciliation') {
      procurementBuyerEvidenceReceipts += 1;
    }
    assert.deepEqual(
      receipt.buyerEvidence,
      catalogProduct.buyerEvidence,
    );
    assert.equal(receipt.buyerEvidence.syntheticOnly, true);
    assert.equal(receipt.buyerEvidence.containsCustomerData, false);
    assert.equal(receipt.buyerEvidence.manualTransferRequired, true);
    assert.equal(receipt.buyerEvidence.publicationAllowed, false);
    assert.equal(receipt.buyerEvidence.paymentActionAllowed, false);
  } else {
    assert.equal(receipt.buyerEvidence, null, `${testCase.name}: buyer evidence must be scoped`);
  }
}
assert.deepEqual(dispositions, { accepted: 6, needs_correction: 2, out_of_scope: 2 });
assert.equal(buyerEvidenceReceipts, 5);
assert.equal(amazonBuyerEvidenceReceipts, 1);
assert.equal(catalogBuyerEvidenceReceipts, 1);
assert.equal(commerceBuyerEvidenceReceipts, 1);
assert.equal(merchantBuyerEvidenceReceipts, 1);
assert.equal(procurementBuyerEvidenceReceipts, 1);

const secretValue = "must-not-echo@example.invalid";
const prohibitedRequest = { ...fixtures.cases[0].request, contactEmail: secretValue };
const prohibitedReceipt = (await execute({ body: prohibitedRequest }))[0].json;
assert.equal(prohibitedReceipt.disposition, "needs_correction");
assert.equal(prohibitedReceipt.quote, null);
assert.equal(prohibitedReceipt.issues.some((entry) => entry.code === "PROHIBITED_CONTACT_OR_SECRET_FIELD"), true);
assert.equal(JSON.stringify(prohibitedReceipt).includes(secretValue), false);

const unsupportedRequest = structuredClone(fixtures.cases[0].request);
unsupportedRequest.requirements.needsCustomUi = true;
const unsupportedReceipt = (await execute({ body: unsupportedRequest }))[0].json;
assert.equal(unsupportedReceipt.disposition, "out_of_scope");
assert.equal(unsupportedReceipt.quote, null);
assert.equal(unsupportedReceipt.issues.some((entry) => entry.code === "CUSTOM_UI_NOT_INCLUDED"), true);

const invalidReceipt = (await execute({ body: null }))[0].json;
assert.equal(invalidReceipt.disposition, "needs_correction");
assert.equal(invalidReceipt.requestId, null);
assert.equal(invalidReceipt.issues[0].code, "INVALID_ROOT");

process.stdout.write(`${JSON.stringify({
  status: "verified",
  active: workflow.active,
  nodes: workflow.nodes.length,
  examples: fixtures.cases.length,
  parityReceipts: fixtures.cases.length,
  dispositions,
  adversarialCases: 3,
  credentialBindings: 0,
  externalActionNodes: 0,
  executionPersistence: "disabled_by_workflow_settings",
  contractReleaseSha256: releaseSha256,
  buyerEvidenceReceipts,
  amazonBuyerEvidenceReceipts,
  catalogBuyerEvidenceReceipts,
  commerceBuyerEvidenceReceipts,
  merchantBuyerEvidenceReceipts,
  procurementBuyerEvidenceReceipts,
  buyerEvidencePubliclyHosted: false,
  automaticAcceptanceAllowed: false,
  paymentActionAllowed: false,
  accountActionAllowed: false,
}, null, 2)}\n`);
