#!/usr/bin/env python3
"""Verify the synthetic Videngineer-aligned n8n proof without network access."""

from __future__ import annotations

import json
import hashlib
import re
from pathlib import Path
from urllib.parse import urlparse


ROOT = Path(__file__).resolve().parent
WORKFLOW_PATH = ROOT / "videngineer-paid-test-workflow.json"
FIXTURE_DIR = ROOT / "fixtures"
RUNTIME_RECEIPT_PATH = ROOT / "runtime-receipt.json"
FORBIDDEN_KEY = re.compile(
    r"password|passcode|secret|token|api[_-]?key|authorization|cookie", re.I
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"{path.name} must contain an object")
    return value


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def walk_forbidden(value: object, path: str = "$") -> list[str]:
    errors: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if FORBIDDEN_KEY.search(key):
                errors.append(f"prohibited key at {path}.{key}")
            errors.extend(walk_forbidden(child, f"{path}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            errors.extend(walk_forbidden(child, f"{path}[{index}]"))
    return errors


def non_empty(value: object) -> bool:
    return isinstance(value, str) and bool(value.strip())


def validate_fixture(envelope: dict) -> list[str]:
    errors = walk_forbidden(envelope)
    if envelope.get("synthetic") is not True:
        errors.append("synthetic must be true")
    if envelope.get("transport") != "mcp_or_http":
        errors.append("transport must be mcp_or_http")

    auth = envelope.get("auth_context")
    if not isinstance(auth, dict) or auth.get("owner") != "buyer_managed":
        errors.append("auth owner must be buyer_managed")
    if not isinstance(auth, dict) or auth.get("credential_material_included") is not False:
        errors.append("credential material must be absent")

    recipient = envelope.get("recipient")
    if not non_empty(recipient) or not recipient.endswith(".invalid"):
        errors.append("recipient must use the reserved .invalid domain")

    analysis = envelope.get("analysis")
    if not isinstance(analysis, dict):
        return errors + ["analysis must be an object"]
    if not non_empty(analysis.get("video_id")):
        errors.append("analysis.video_id is required")

    video_url = analysis.get("video_url")
    if not non_empty(video_url):
        errors.append("analysis.video_url is required")
    else:
        parsed = urlparse(video_url)
        if parsed.scheme != "https" or not (parsed.hostname or "").endswith(".invalid"):
            errors.append("video_url must be synthetic HTTPS")

    if not non_empty(analysis.get("transcript_summary")):
        errors.append("analysis.transcript_summary is required")

    scenes = analysis.get("scenes")
    if not isinstance(scenes, list) or not 1 <= len(scenes) <= 10:
        errors.append("analysis.scenes must contain 1-10 entries")
    else:
        for index, scene in enumerate(scenes):
            if not isinstance(scene, dict):
                errors.append(f"analysis.scenes[{index}] must be an object")
                continue
            start = scene.get("start_seconds")
            end = scene.get("end_seconds")
            if not isinstance(start, (int, float)) or not isinstance(end, (int, float)) or end <= start:
                errors.append(f"analysis.scenes[{index}] has invalid timing")
            if not non_empty(scene.get("description")):
                errors.append(f"analysis.scenes[{index}].description is required")

    voice = analysis.get("voice_profile")
    if not isinstance(voice, dict) or not non_empty(voice.get("tone")):
        errors.append("analysis.voice_profile.tone is required")
    pace = voice.get("pace_wpm") if isinstance(voice, dict) else None
    if not isinstance(pace, (int, float)) or not 60 <= pace <= 240:
        errors.append("analysis.voice_profile.pace_wpm is invalid")

    playbook = analysis.get("build_playbook")
    if (
        not isinstance(playbook, list)
        or not 1 <= len(playbook) <= 5
        or any(not non_empty(step) for step in playbook)
    ):
        errors.append("analysis.build_playbook must contain 1-5 non-empty steps")
    return errors


def build_email_preview(envelope: dict) -> dict:
    analysis = envelope["analysis"]
    scene_lines = [
        f"{index}. {scene['start_seconds']}-{scene['end_seconds']}s — {scene['description']}"
        for index, scene in enumerate(analysis["scenes"], start=1)
    ]
    playbook_lines = [
        f"{index}. {step}"
        for index, step in enumerate(analysis["build_playbook"], start=1)
    ]
    text = "\n".join(
        [
            f"Video: {analysis['video_id']}",
            f"Summary: {analysis['transcript_summary']}",
            f"Voice: {analysis['voice_profile']['tone']}; {analysis['voice_profile']['pace_wpm']} wpm",
            "Scenes:",
            *scene_lines,
            "Build playbook:",
            *playbook_lines,
        ]
    )
    return {
        "channel": "preview_only",
        "to": envelope["recipient"],
        "subject": f"Synthetic video analysis — {analysis['video_id']}",
        "text": text,
    }


def main() -> None:
    workflow = read_json(WORKFLOW_PATH)
    runtime_receipt = read_json(RUNTIME_RECEIPT_PATH)
    serialized = WORKFLOW_PATH.read_text(encoding="utf-8")
    nodes = {node["name"]: node for node in workflow["nodes"]}
    expected_nodes = {
        "Manual Trigger",
        "Build Synthetic MCP Envelope",
        "Validate Structured Analysis",
        "Valid Payload?",
        "Build Email Preview",
        "Build Failure Receipt",
    }

    require(workflow["id"] == "VidengineerPaidTest20260810", "unexpected workflow id")
    require(workflow["active"] is False, "workflow must remain inactive")
    require(set(nodes) == expected_nodes, "unexpected node set")
    require(workflow["settings"]["saveDataErrorExecution"] == "none", "error persistence must be disabled")
    require(workflow["settings"]["saveDataSuccessExecution"] == "none", "success persistence must be disabled")

    prohibited_types = {
        "n8n-nodes-base.httpRequest",
        "n8n-nodes-base.emailSend",
        "n8n-nodes-base.gmail",
        "n8n-nodes-base.slack",
    }
    require(
        not any(node["type"] in prohibited_types for node in workflow["nodes"]),
        "proof must not contain an external-action node",
    )
    meta = workflow["meta"]
    require(meta["syntheticOnly"] is True, "synthetic-only flag missing")
    require(meta["credentialsIncluded"] is False, "credentials must be absent")
    require(meta["externalActionNodes"] == 0, "external-action count must be zero")
    require(meta["productionActivationAllowed"] is False, "production activation must be gated")
    require(meta["customerDataAllowed"] is False, "customer data must be prohibited")
    require("preview@example.invalid" in serialized, "reserved synthetic recipient missing")
    require("new URL(" not in serialized, "n8n Code sandbox must not rely on global URL")
    require("syntheticHttpsUrl" in serialized, "sandbox-safe URL rule missing")

    require(
        runtime_receipt["workflow"]["sha256"] == sha256(WORKFLOW_PATH),
        "runtime receipt workflow hash is stale",
    )
    require(
        runtime_receipt["first_runtime_attempt"]["business_status"] == "rejected",
        "first failed runtime attempt is not preserved",
    )
    repaired = runtime_receipt["repaired_runtime_execution"]
    require(repaired["finished"] is True, "repaired runtime did not finish")
    require(repaired["n8n_status"] == "success", "repaired n8n runtime failed")
    require(repaired["business_status"] == "pass", "repaired business path failed")
    require(repaired["last_node"] == "Build Email Preview", "unexpected repaired final node")
    require(repaired["validation_errors"] == [], "repaired runtime has validation errors")
    require(repaired["external_action_performed"] is False, "runtime performed an external action")
    safety = runtime_receipt["safety"]
    require(safety["external_network_calls"] == 0, "runtime receipt reports a network call")
    require(safety["credentials_used"] == 0, "runtime receipt reports credentials")
    require(safety["emails_sent"] == 0, "runtime receipt reports an email send")
    require(safety["cash_spent_rmb"] == 0, "runtime receipt reports cash spend")

    valid = read_json(FIXTURE_DIR / "valid-video-analysis.json")
    missing = read_json(FIXTURE_DIR / "missing-summary.json")
    forbidden = read_json(FIXTURE_DIR / "forbidden-secret-field.json")
    valid_errors = validate_fixture(valid)
    missing_errors = validate_fixture(missing)
    forbidden_errors = validate_fixture(forbidden)
    require(valid_errors == [], f"valid fixture rejected: {valid_errors}")
    require(
        "analysis.transcript_summary is required" in missing_errors,
        "missing-summary fixture did not fail the expected rule",
    )
    require(
        any("access_token" in error for error in forbidden_errors),
        "secret-like fixture did not fail the expected rule",
    )

    preview = build_email_preview(valid)
    require(preview["channel"] == "preview_only", "email output must remain a preview")
    require(preview["to"].endswith(".invalid"), "preview recipient must remain synthetic")
    require("Scenes:" in preview["text"], "scene section missing")
    require("Build playbook:" in preview["text"], "playbook section missing")
    require("SYNTHETIC_PROHIBITED_FIELD" not in preview["text"], "prohibited fixture leaked into preview")

    receipt = {
        "status": "pass",
        "workflow_active": workflow["active"],
        "node_count": len(workflow["nodes"]),
        "external_action_nodes": meta["externalActionNodes"],
        "valid_fixture_errors": len(valid_errors),
        "adversarial_fixtures_rejected": 2,
        "email_output": preview["channel"],
    }
    print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    print("PASS: synthetic structure, adversarial validation and email preview verified")


if __name__ == "__main__":
    main()
