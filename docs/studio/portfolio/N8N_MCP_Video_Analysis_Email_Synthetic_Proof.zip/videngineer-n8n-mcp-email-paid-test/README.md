# Synthetic video-analysis MCP/HTTP to email preview

This package is a reusable, inactive n8n proof prepared from Videngineer's
public request for a small paid first workflow. It uses fictional data only and
does not contain Videngineer data, credentials, private endpoints or customer
material. It is not client work, a production deployment or a completed paid
test.

## What it proves

- Accepts one structured video-analysis envelope representing an MCP or HTTP
  handoff.
- Requires a buyer-managed authentication boundary without embedding credential
  material.
- Validates the transcript summary, scenes, voice profile and build playbook.
- Rejects missing required fields, non-synthetic URLs and secret-like keys.
- Builds a concise email preview without including a send-email node.
- Keeps the workflow inactive and disables execution persistence.

## Offline verification

From the repository root:

```sh
python3 monetization/microstudio/sales/proofs/videngineer-n8n-mcp-email-paid-test/verify_videngineer_workflow.py
```

The verifier checks the workflow structure, one valid fixture and two
adversarial fixtures. It also confirms that the workflow contains no HTTP,
email, Slack or credential-binding node.

## Pinned n8n runtime

The existing workspace-local n8n `2.33.7` runtime can import and execute the
default synthetic path with no network access or credentials:

```sh
N8N_USER_FOLDER="$PWD/.tmp/n8n-runtime/user" \
  XDG_CONFIG_HOME="$PWD/.tmp/n8n-runtime/xdg-config" \
  XDG_CACHE_HOME="$PWD/.tmp/n8n-runtime/xdg-cache" \
  XDG_DATA_HOME="$PWD/.tmp/n8n-runtime/xdg-data" \
  TMPDIR="$PWD/.tmp/n8n-runtime/tmp" \
  .tmp/n8n-runtime/work/node_modules/.bin/n8n import:workflow \
  --input="monetization/microstudio/sales/proofs/videngineer-n8n-mcp-email-paid-test/videngineer-paid-test-workflow.json"

N8N_USER_FOLDER="$PWD/.tmp/n8n-runtime/user" \
  XDG_CONFIG_HOME="$PWD/.tmp/n8n-runtime/xdg-config" \
  XDG_CACHE_HOME="$PWD/.tmp/n8n-runtime/xdg-cache" \
  XDG_DATA_HOME="$PWD/.tmp/n8n-runtime/xdg-data" \
  TMPDIR="$PWD/.tmp/n8n-runtime/tmp" \
  N8N_RUNNERS_ENABLED=false \
  .tmp/n8n-runtime/work/node_modules/.bin/n8n execute \
  --id="VidengineerPaidTest20260810" --rawOutput
```

## Production boundary

The proof must not be activated or connected to a real MCP service, email
provider, Slack, Notion, Google Sheets or buyer account before a paid scope is
agreed. A production version must add buyer-owned credentials, authentication
failure tests, request limits, retention rules and a funded acceptance
milestone. None of those controls is implied by this offline proof.
