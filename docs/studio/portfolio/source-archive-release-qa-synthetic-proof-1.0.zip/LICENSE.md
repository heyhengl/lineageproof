Copyright (c) 2026 Source Archive QA Proof contributors

Permission is hereby granted, free of charge, to any person obtaining a copy of
this synthetic fixture, verification code, and associated documentation files,
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the materials, subject to inclusion of this copyright and permission notice.

THE MATERIALS ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY ARISING FROM, OUT OF OR IN
CONNECTION WITH THE MATERIALS OR THEIR USE.
