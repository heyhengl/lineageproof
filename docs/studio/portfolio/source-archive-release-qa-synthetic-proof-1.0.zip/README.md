# Source Archive Release QA — Synthetic Proof

This is an owned, synthetic, public-safe proof for a narrow release-artifact
quality-assurance service. It checks whether a supplied source archive matches
an explicit acceptance contract and whether its documented local commands are
reproducible.

The fixture contains no customer data, credentials, external accounts,
production endpoints, proprietary code, paid dependencies, or network calls.
It intentionally contains four deterministic exceptions:

1. the archive declares version `1.1.0` while the contract expects `1.2.0`;
2. `docs/USAGE.md` is required but absent;
3. `debug.tmp` is forbidden but present;
4. the expected `README.md` hash is intentionally incorrect.

The three owned-fixture commands still pass. This separates command
reproducibility from artifact-contract conformance instead of collapsing both
into one ambiguous result.

## Reproduce

Run from this directory with Python 3.11 or newer:

```bash
python3 tools/build_fixture.py
python3 tools/verify_release.py \
  --archive dist/releaseproof-demo-1.2.0.zip \
  --contract acceptance_contract.json \
  --output-dir evidence \
  --execute-owned-fixture
python3 -m unittest discover -s tests -v
python3 tools/package_proof.py
```

The verifier writes:

- `evidence/inventory.json` — path, size and SHA-256 inventory;
- `evidence/command_receipt.json` — exact argv and normalized output evidence;
- `evidence/exception_log.json` — stable exception codes and observed values;
- `evidence/summary.json` — pass/fail decision and receipt hashes.

The packager writes:

- `dist/source-archive-release-qa-synthetic-proof-1.0.zip`;
- `dist/SHA256SUMS`.

## Safety boundary

`--execute-owned-fixture` executes code from the archive. It is appropriate
here only because every fixture byte is owned and inspected. It is not a
general sandbox for untrusted client archives. A paid engagement would require
an agreed disposable execution environment, no secrets, no production access,
no network by default, and an explicit command allowlist.

The verifier rejects unsafe archive paths, duplicate members and symbolic
links before extraction. It only accepts commands whose executable is exactly
`python3`, applies a 30-second timeout, and supplies a minimal environment.

## Fixed-scope service represented

- one synthetic, public-sample or explicitly client-cleared source archive;
- one written acceptance contract;
- inventory and SHA-256 receipt;
- up to five documented local build, test, install or example commands;
- deterministic exception log and concise decision summary;
- no repository, ticketing, account, package-registry or production access;
- no code changes, security testing, licence judgment or package publication.

This proof is evidence of the method, not evidence of a customer engagement,
contract, revenue, security certification, or production readiness.
