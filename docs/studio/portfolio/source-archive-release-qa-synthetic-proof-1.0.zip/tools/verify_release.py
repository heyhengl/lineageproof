#!/usr/bin/env python3
"""Generate evidence for an owned synthetic source-archive acceptance audit."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import subprocess
import tempfile
from collections import Counter
from pathlib import Path, PurePosixPath
from zipfile import ZipFile, ZipInfo


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def is_safe_member(name: str) -> bool:
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and ".." not in path.parts


def is_symlink(info: ZipInfo) -> bool:
    return stat.S_ISLNK(info.external_attr >> 16)


def normalize_command_output(value: str) -> str:
    value = value.replace("\r\n", "\n")
    return re.sub(
        r"Ran (\d+) tests? in [0-9.]+s",
        r"Ran \1 tests in <elapsed>s",
        value,
    )


def add_exception(
    exceptions: list[dict[str, object]],
    code: str,
    path: str,
    expected: object,
    observed: object,
) -> None:
    exceptions.append(
        {
            "code": code,
            "expected": expected,
            "observed": observed,
            "path": path,
        }
    )


def inspect_archive(
    archive_path: Path,
    contract: dict[str, object],
    extract_root: Path,
) -> tuple[list[dict[str, object]], list[dict[str, object]], bool]:
    inventory: list[dict[str, object]] = []
    exceptions: list[dict[str, object]] = []
    safe_to_extract = True

    with ZipFile(archive_path) as archive:
        names = [info.filename for info in archive.infolist()]
        for name, count in sorted(Counter(names).items()):
            if count > 1:
                add_exception(
                    exceptions,
                    "duplicate_archive_member",
                    name,
                    1,
                    count,
                )
                safe_to_extract = False

        for info in sorted(archive.infolist(), key=lambda item: item.filename):
            if not is_safe_member(info.filename):
                add_exception(
                    exceptions,
                    "unsafe_archive_path",
                    info.filename,
                    "relative path without parent traversal",
                    info.filename,
                )
                safe_to_extract = False
                continue
            if is_symlink(info):
                add_exception(
                    exceptions,
                    "unsupported_symlink",
                    info.filename,
                    "regular file or directory",
                    "symbolic link",
                )
                safe_to_extract = False
                continue
            if info.is_dir():
                continue
            payload = archive.read(info)
            inventory.append(
                {
                    "path": info.filename,
                    "sha256": sha256_bytes(payload),
                    "size_bytes": len(payload),
                }
            )

        if safe_to_extract:
            for info in archive.infolist():
                if info.is_dir():
                    continue
                target = extract_root / PurePosixPath(info.filename)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(info))

    observed = {entry["path"]: entry for entry in inventory}
    for path in sorted(contract.get("required_files", [])):
        if path not in observed:
            add_exception(exceptions, "missing_required_file", path, "present", "absent")

    for path in sorted(contract.get("forbidden_files", [])):
        if path in observed:
            add_exception(exceptions, "forbidden_file_present", path, "absent", "present")

    for path, expected_hash in sorted(contract.get("expected_hashes", {}).items()):
        actual = observed.get(path, {}).get("sha256")
        if actual != expected_hash:
            add_exception(exceptions, "hash_mismatch", path, expected_hash, actual)

    version_source = contract.get("version_source", {})
    version_path = version_source.get("path")
    expected_version = contract.get("expected_version")
    if safe_to_extract and version_path in observed:
        source = (extract_root / version_path).read_text(encoding="utf-8")
        match = re.search(version_source.get("pattern", ""), source)
        actual_version = match.group(1) if match else None
        if actual_version != expected_version:
            add_exception(
                exceptions,
                "version_mismatch",
                version_path,
                expected_version,
                actual_version,
            )

    exceptions.sort(key=lambda item: (str(item["code"]), str(item["path"])))
    return inventory, exceptions, safe_to_extract


def run_commands(
    extract_root: Path,
    contract: dict[str, object],
    execute_owned_fixture: bool,
    safe_to_extract: bool,
) -> list[dict[str, object]]:
    receipts: list[dict[str, object]] = []
    for command in contract.get("commands", []):
        argv = command.get("argv", [])
        receipt: dict[str, object] = {
            "argv": argv,
            "id": command.get("id"),
        }
        if not safe_to_extract:
            receipt.update({"status": "blocked", "reason": "unsafe archive"})
        elif not execute_owned_fixture:
            receipt.update(
                {
                    "status": "not_executed",
                    "reason": "--execute-owned-fixture not supplied",
                }
            )
        elif not argv or argv[0] != "python3":
            receipt.update(
                {
                    "status": "blocked",
                    "reason": "executable not in owned-fixture allowlist",
                }
            )
        else:
            environment = {
                "LANG": "C.UTF-8",
                "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONNOUSERSITE": "1",
            }
            try:
                result = subprocess.run(
                    argv,
                    cwd=extract_root,
                    capture_output=True,
                    check=False,
                    env=environment,
                    text=True,
                    timeout=30,
                )
                stdout = normalize_command_output(result.stdout)
                stderr = normalize_command_output(result.stderr)
                receipt.update(
                    {
                        "exit_code": result.returncode,
                        "status": "passed" if result.returncode == 0 else "failed",
                        "stderr": stderr,
                        "stderr_sha256": sha256_bytes(stderr.encode("utf-8")),
                        "stdout": stdout,
                        "stdout_sha256": sha256_bytes(stdout.encode("utf-8")),
                    }
                )
            except subprocess.TimeoutExpired:
                receipt.update(
                    {
                        "status": "failed",
                        "reason": "30-second timeout",
                    }
                )
        receipts.append(receipt)
    return receipts


def verify(
    archive_path: Path,
    contract_path: Path,
    output_dir: Path,
    execute_owned_fixture: bool,
) -> dict[str, object]:
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory(prefix="source-archive-qa-") as temp_dir:
        extract_root = Path(temp_dir)
        inventory, exceptions, safe_to_extract = inspect_archive(
            archive_path,
            contract,
            extract_root,
        )
        commands = run_commands(
            extract_root,
            contract,
            execute_owned_fixture,
            safe_to_extract,
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    inventory_payload = {
        "archive": archive_path.name,
        "archive_sha256": sha256_file(archive_path),
        "file_count": len(inventory),
        "files": inventory,
    }
    command_payload = {
        "commands": commands,
        "execution_boundary": "owned synthetic fixture only",
        "network_required": False,
    }
    exception_payload = {
        "exception_count": len(exceptions),
        "exceptions": exceptions,
    }
    write_json(output_dir / "inventory.json", inventory_payload)
    write_json(output_dir / "command_receipt.json", command_payload)
    write_json(output_dir / "exception_log.json", exception_payload)

    commands_passed = all(item.get("status") == "passed" for item in commands)
    summary = {
        "archive": archive_path.name,
        "command_count": len(commands),
        "commands_passed": commands_passed,
        "contract": contract_path.name,
        "exception_codes": [item["code"] for item in exceptions],
        "exception_count": len(exceptions),
        "file_count": len(inventory),
        "overall_status": (
            "pass" if not exceptions and commands_passed and safe_to_extract else "fail"
        ),
        "receipt_sha256": {
            "command_receipt.json": sha256_file(output_dir / "command_receipt.json"),
            "exception_log.json": sha256_file(output_dir / "exception_log.json"),
            "inventory.json": sha256_file(output_dir / "inventory.json"),
        },
        "safe_to_extract": safe_to_extract,
    }
    write_json(output_dir / "summary.json", summary)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--contract", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--execute-owned-fixture", action="store_true")
    args = parser.parse_args()
    summary = verify(
        args.archive.resolve(),
        args.contract.resolve(),
        args.output_dir.resolve(),
        args.execute_owned_fixture,
    )
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
