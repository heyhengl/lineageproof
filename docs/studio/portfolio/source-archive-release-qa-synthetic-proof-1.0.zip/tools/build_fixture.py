#!/usr/bin/env python3
"""Build the owned source archive with deterministic metadata."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
FIXTURE_SOURCE = ROOT / "fixture_source"
DEFAULT_OUTPUT = ROOT / "dist" / "releaseproof-demo-1.2.0.zip"
DEFAULT_RECEIPT = ROOT / "evidence" / "build_receipt.json"
FIXED_ZIP_TIME = (2026, 1, 1, 0, 0, 0)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def build_archive(output: Path) -> dict[str, object]:
    output.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(path for path in FIXTURE_SOURCE.rglob("*") if path.is_file())
    with ZipFile(output, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(FIXTURE_SOURCE).as_posix()
            info = ZipInfo(relative, date_time=FIXED_ZIP_TIME)
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, path.read_bytes())
    return {
        "archive": output.name,
        "archive_sha256": sha256_file(output),
        "fixture_file_count": len(files),
        "fixture_paths": [
            path.relative_to(FIXTURE_SOURCE).as_posix() for path in files
        ],
        "network_used": False,
        "owned_synthetic_fixture": True,
        "paid_dependencies": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--receipt", type=Path, default=DEFAULT_RECEIPT)
    args = parser.parse_args()
    receipt = build_archive(args.output.resolve())
    write_json(args.receipt.resolve(), receipt)
    print(json.dumps(receipt, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
