from __future__ import annotations

import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "tools" / "build_fixture.py"
VERIFY = ROOT / "tools" / "verify_release.py"
CONTRACT = ROOT / "acceptance_contract.json"


class ReleaseQaProofTests(unittest.TestCase):
    def test_owned_fixture_produces_four_exceptions_and_passing_commands(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            archive = temp / "releaseproof-demo-1.2.0.zip"
            build_receipt = temp / "build_receipt.json"
            evidence = temp / "evidence"

            subprocess.run(
                [
                    "python3",
                    str(BUILD),
                    "--output",
                    str(archive),
                    "--receipt",
                    str(build_receipt),
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            subprocess.run(
                [
                    "python3",
                    str(VERIFY),
                    "--archive",
                    str(archive),
                    "--contract",
                    str(CONTRACT),
                    "--output-dir",
                    str(evidence),
                    "--execute-owned-fixture",
                ],
                check=True,
                capture_output=True,
                text=True,
            )

            summary = json.loads((evidence / "summary.json").read_text())
            self.assertEqual(summary["overall_status"], "fail")
            self.assertTrue(summary["commands_passed"])
            self.assertEqual(
                sorted(summary["exception_codes"]),
                [
                    "forbidden_file_present",
                    "hash_mismatch",
                    "missing_required_file",
                    "version_mismatch",
                ],
            )

    def test_parent_traversal_is_reported_and_not_extracted(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            archive = temp / "unsafe.zip"
            output = temp / "evidence"
            contract = temp / "contract.json"
            contract.write_text(
                json.dumps(
                    {
                        "commands": [],
                        "expected_hashes": {},
                        "forbidden_files": [],
                        "required_files": [],
                    }
                ),
                encoding="utf-8",
            )
            with ZipFile(archive, "w") as bundle:
                bundle.writestr("../escape.txt", "must not escape")

            subprocess.run(
                [
                    "python3",
                    str(VERIFY),
                    "--archive",
                    str(archive),
                    "--contract",
                    str(contract),
                    "--output-dir",
                    str(output),
                ],
                check=True,
                capture_output=True,
                text=True,
            )

            exceptions = json.loads(
                (output / "exception_log.json").read_text(encoding="utf-8")
            )
            self.assertEqual(
                [item["code"] for item in exceptions["exceptions"]],
                ["unsafe_archive_path"],
            )
            self.assertFalse((temp.parent / "escape.txt").exists())


if __name__ == "__main__":
    unittest.main()
