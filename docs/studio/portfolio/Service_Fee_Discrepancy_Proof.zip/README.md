# Service Fee Discrepancy Analysis — Synthetic Reproducible Proof

This portfolio sample audits a deterministic fictional service-fee ledger with Pandas and SQL. It produces row-level review flags, a rejected-row ledger, per-service reconciliation, a ranked discrepancy queue, a deterministic 95% spot-check subset, three decision-focused charts, an executable notebook, a short narrative, SQLite evidence, hashes, and a portable proof archive.

No client, account, payment, or personally identifiable data is used. The fixture is generated locally and labels every injected defect so the resulting audit can be verified rather than merely demonstrated.

## Known fixture contract

- 483 source rows: 480 generated transactions plus 3 duplicate source rows;
- 472 accepted unique transactions;
- 11 rejected source rows: 4 missing fees, 4 missing revenues, and 3 duplicates;
- 20 accepted transactions routed for review: 8 above policy, 7 below policy, and 5 arithmetic mismatches;
- every accepted row reconciles to the service profile and SQL results;
- the deterministic spot-check covers 449 rows, at least 95% of accepted rows.

## Reproduce

Use the bundled Codex Python runtime, which includes Pandas and Pillow:

```bash
PY=/Users/yuhenghe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3
"$PY" build_proof.py
"$PY" verify_proof.py
"$PY" -m unittest discover -s tests -p 'test_*.py'
```

The build writes inspectable artifacts to `dist/` and the deterministic handoff archive to `output/Service_Fee_Discrepancy_Proof.zip`.

## Decision boundary

The proof demonstrates ingestion, validation, fee-policy matching, row-level exception logic, service-level reconciliation, SQL parity, and reproducible reporting. It does not claim a prior client engagement or establish a real company's fee policy. A funded engagement must first confirm field definitions, currency and rounding rules, effective dates, tolerances, and authorized data handling.
