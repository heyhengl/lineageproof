#!/usr/bin/env python3
"""Verify the built service-fee discrepancy proof from disk."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pandas as pd

from build_proof import DIST, canonical_hash, sha256


def verify(dist: Path = DIST) -> dict[str, object]:
    receipt = json.loads((dist / "verification_receipt.json").read_text(encoding="utf-8"))
    for name, expected in receipt["artifact_hashes"].items():
        actual = sha256(dist / name)
        if actual != expected:
            raise AssertionError(f"artifact hash mismatch: {name}")
    summary = {key: value for key, value in receipt.items() if key not in {"artifact_hashes", "receipt_sha256"}}
    expected_receipt = canonical_hash({"summary": summary, "artifact_hashes": receipt["artifact_hashes"]})
    if receipt["receipt_sha256"] != expected_receipt:
        raise AssertionError("receipt digest mismatch")

    cleaned = pd.read_csv(dist / "cleaned_transactions.csv")
    rejected = pd.read_csv(dist / "rejected_rows.csv")
    spot = pd.read_csv(dist / "spot_check_95pct.csv")
    if len(cleaned) != receipt["accepted_rows"] or len(rejected) != receipt["rejected_rows"]:
        raise AssertionError("row reconciliation mismatch")
    if int(cleaned["is_suspect"].sum()) != receipt["suspect_rows"]:
        raise AssertionError("suspect-row reconciliation mismatch")
    if len(spot) != receipt["spot_check_rows"]:
        raise AssertionError("spot-check size mismatch")
    if not spot[["flag_matches_truth", "reason_matches_truth"]].all().all():
        raise AssertionError("spot-check truth mismatch")

    with sqlite3.connect(dist / "analysis.sqlite") as connection:
        sqlite_rows = connection.execute("SELECT COUNT(*), SUM(is_suspect) FROM transactions_clean").fetchone()
    if sqlite_rows != (len(cleaned), int(cleaned["is_suspect"].sum())):
        raise AssertionError("SQLite reconciliation mismatch")

    return {
        "verified": True,
        "accepted_rows": len(cleaned),
        "rejected_rows": len(rejected),
        "suspect_rows": int(cleaned["is_suspect"].sum()),
        "receipt_sha256": receipt["receipt_sha256"],
    }


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2))

