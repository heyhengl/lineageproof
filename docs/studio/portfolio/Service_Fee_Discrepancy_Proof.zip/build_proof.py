#!/usr/bin/env python3
"""Build a deterministic synthetic service-fee discrepancy proof."""

from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import zipfile
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
DIST = ROOT / "dist"
OUTPUT = ROOT / "output"
AS_OF = "2026-08-09T13:45:00+08:00"
SEED = 40635458
TOLERANCE = 0.02

POLICIES = [
    ("SVC-ALPHA", "Data API", 0.050, 0.045, 0.055),
    ("SVC-BRAVO", "Workflow Ops", 0.080, 0.073, 0.087),
    ("SVC-CHARLIE", "Premium Support", 0.120, 0.110, 0.130),
    ("SVC-DELTA", "Marketplace", 0.150, 0.138, 0.162),
    ("SVC-ECHO", "Usage Export", 0.030, 0.026, 0.034),
]

ANOMALIES = {
    **{index: "ABOVE_POLICY_RANGE" for index in [17, 61, 109, 157, 205, 253, 301, 349]},
    **{index: "BELOW_POLICY_RANGE" for index in [31, 83, 135, 187, 239, 291, 343]},
    **{index: "FEE_ARITHMETIC_MISMATCH" for index in [44, 128, 212, 296, 380]},
    **{index: "MISSING_LISTED_FEE" for index in [52, 180, 308, 436]},
    **{index: "MISSING_REALIZED_REVENUE" for index in [76, 204, 332, 460]},
}
DUPLICATE_SOURCE_INDICES = [24, 168, 312]

NAVY = "#152238"
INK = "#25334A"
MUTED = "#647184"
LINE = "#D8E0EA"
PANEL = "#F4F7FB"
WHITE = "#FFFFFF"
AMBER = "#D98B19"
RED = "#C94A4A"
BLUE = "#356AE6"
PALE_AMBER = "#F8E8C8"


@dataclass(frozen=True)
class Policy:
    service_code: str
    service_name: str
    expected_fee_rate: float
    minimum_fee_rate: float
    maximum_fee_rate: float


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def policy_frame() -> pd.DataFrame:
    return pd.DataFrame(
        POLICIES,
        columns=[
            "service_code",
            "service_name",
            "expected_fee_rate",
            "minimum_fee_rate",
            "maximum_fee_rate",
        ],
    ).assign(effective_from="2026-01-01", effective_to="2026-12-31")


def generate_fixture() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Generate raw transactions and explicit source-level ground truth."""
    rng = np.random.default_rng(SEED)
    policies = [Policy(*row) for row in POLICIES]
    rows: list[dict[str, Any]] = []
    truth: list[dict[str, Any]] = []
    start = date(2026, 1, 1)
    for index in range(1, 481):
        policy = policies[(index - 1) % len(policies)]
        month = (index - 1) // 80
        day = ((index * 7) % 27) + 1
        tx_date = date(start.year, start.month + month, day).isoformat()
        revenue = round(float(rng.uniform(180.0, 5400.0)), 2)
        jitter = float(rng.normal(0.0, (policy.maximum_fee_rate - policy.minimum_fee_rate) / 6))
        applied_fee_rate = round(
            min(policy.maximum_fee_rate - 0.0005, max(policy.minimum_fee_rate + 0.0005, policy.expected_fee_rate + jitter)),
            6,
        )
        expected_fee = round(revenue * applied_fee_rate, 2)
        listed_fee: float | None = expected_fee
        realized_revenue: float | None = revenue
        anomaly = ANOMALIES.get(index, "")
        expected_outcome = "accepted"
        expected_review = 0
        expected_reason = ""
        if anomaly == "ABOVE_POLICY_RANGE":
            applied_fee_rate = round(policy.maximum_fee_rate + 0.020, 6)
            listed_fee = round(revenue * applied_fee_rate, 2)
            expected_review = 1
            expected_reason = anomaly
        elif anomaly == "BELOW_POLICY_RANGE":
            applied_fee_rate = round(max(0.001, policy.minimum_fee_rate - 0.020), 6)
            listed_fee = round(revenue * applied_fee_rate, 2)
            expected_review = 1
            expected_reason = anomaly
        elif anomaly == "FEE_ARITHMETIC_MISMATCH":
            listed_fee = round(expected_fee + 0.11, 2)
            expected_review = 1
            expected_reason = anomaly
        elif anomaly == "MISSING_LISTED_FEE":
            listed_fee = None
            expected_outcome = "rejected"
            expected_reason = anomaly
        elif anomaly == "MISSING_REALIZED_REVENUE":
            realized_revenue = None
            expected_outcome = "rejected"
            expected_reason = anomaly
        source_row_id = f"SRC-{index:04d}"
        transaction_id = f"TX-2026-{index:04d}"
        rows.append(
            {
                "source_row_id": source_row_id,
                "transaction_id": transaction_id,
                "transaction_date": tx_date,
                "service_code": policy.service_code,
                "currency": "USD",
                "realized_revenue": realized_revenue,
                "applied_fee_rate": applied_fee_rate,
                "listed_fee": listed_fee,
                "synthetic_fixture": True,
            }
        )
        truth.append(
            {
                "source_row_id": source_row_id,
                "transaction_id": transaction_id,
                "expected_outcome": expected_outcome,
                "expected_review": expected_review,
                "expected_reason": expected_reason,
            }
        )

    for duplicate_number, original_index in enumerate(DUPLICATE_SOURCE_INDICES, start=1):
        original = dict(rows[original_index - 1])
        source_row_id = f"DUP-{duplicate_number:04d}"
        original["source_row_id"] = source_row_id
        rows.append(original)
        truth.append(
            {
                "source_row_id": source_row_id,
                "transaction_id": original["transaction_id"],
                "expected_outcome": "rejected",
                "expected_review": 0,
                "expected_reason": "DUPLICATE_TRANSACTION",
            }
        )
    return pd.DataFrame(rows), policy_frame(), pd.DataFrame(truth)


def analyze(
    raw: pd.DataFrame, policies: pd.DataFrame
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Validate source rows and calculate row-level fee exceptions."""
    required = [
        "source_row_id",
        "transaction_id",
        "transaction_date",
        "service_code",
        "currency",
        "realized_revenue",
        "applied_fee_rate",
        "listed_fee",
        "synthetic_fixture",
    ]
    missing_headers = [column for column in required if column not in raw.columns]
    if missing_headers:
        raise ValueError(f"missing required headers: {missing_headers}")
    if not raw["synthetic_fixture"].eq(True).all():  # noqa: E712
        raise ValueError("refusing unmarked non-synthetic rows")
    if raw["source_row_id"].duplicated().any():
        raise ValueError("source_row_id must be unique")

    rejected: list[dict[str, Any]] = []
    accepted_indices: list[int] = []
    seen_transactions: set[str] = set()
    for index, row in raw.iterrows():
        reason = ""
        if pd.isna(row["realized_revenue"]):
            reason = "MISSING_REALIZED_REVENUE"
        elif pd.isna(row["listed_fee"]):
            reason = "MISSING_LISTED_FEE"
        elif str(row["transaction_id"]) in seen_transactions:
            reason = "DUPLICATE_TRANSACTION"
        if reason:
            rejected.append(
                {
                    "source_row_id": row["source_row_id"],
                    "transaction_id": row["transaction_id"],
                    "rejection_reason": reason,
                }
            )
        else:
            accepted_indices.append(index)
            seen_transactions.add(str(row["transaction_id"]))

    accepted = raw.loc[accepted_indices].copy()
    accepted = accepted.merge(policies, on="service_code", how="left", validate="many_to_one")
    if accepted["expected_fee_rate"].isna().any():
        unknown = sorted(accepted.loc[accepted["expected_fee_rate"].isna(), "service_code"].unique())
        raise ValueError(f"unknown service code: {unknown}")
    accepted["expected_fee"] = (accepted["realized_revenue"] * accepted["applied_fee_rate"]).round(2)
    accepted["actual_fee_rate"] = accepted["listed_fee"] / accepted["realized_revenue"]
    accepted["fee_delta"] = (accepted["listed_fee"] - accepted["expected_fee"]).round(2)

    above = accepted["actual_fee_rate"] > accepted["maximum_fee_rate"]
    below = accepted["actual_fee_rate"] < accepted["minimum_fee_rate"]
    mismatch = accepted["fee_delta"].abs() > TOLERANCE
    accepted["review_reason"] = np.select(
        [above, below, mismatch],
        ["ABOVE_POLICY_RANGE", "BELOW_POLICY_RANGE", "FEE_ARITHMETIC_MISMATCH"],
        default="",
    )
    accepted["is_suspect"] = accepted["review_reason"].ne("").astype(int)
    accepted = accepted.sort_values("transaction_id").reset_index(drop=True)

    service_profile = (
        accepted.groupby(["service_code", "service_name"], as_index=False)
        .agg(
            transaction_count=("transaction_id", "count"),
            realized_revenue=("realized_revenue", "sum"),
            listed_fee=("listed_fee", "sum"),
            suspect_count=("is_suspect", "sum"),
            absolute_fee_delta=("fee_delta", lambda series: series.abs().sum()),
        )
        .sort_values("service_code")
    )
    for column in ["realized_revenue", "listed_fee", "absolute_fee_delta"]:
        service_profile[column] = service_profile[column].round(2)

    discrepancies = accepted.loc[accepted["is_suspect"].eq(1)].copy()
    discrepancies["review_priority"] = discrepancies["fee_delta"].abs().rank(method="first", ascending=False).astype(int)
    discrepancies = discrepancies.sort_values("review_priority").reset_index(drop=True)
    return accepted, pd.DataFrame(rejected), service_profile, discrepancies


def deterministic_spot_check(cleaned: pd.DataFrame, truth: pd.DataFrame) -> pd.DataFrame:
    merged = cleaned.merge(
        truth[["source_row_id", "expected_review", "expected_reason"]],
        on="source_row_id",
        how="left",
        validate="one_to_one",
    )
    merged["selection_hash"] = merged["transaction_id"].map(
        lambda value: hashlib.sha256(f"{SEED}:{value}".encode("utf-8")).hexdigest()
    )
    sample_size = math.ceil(len(merged) * 0.95)
    sample = merged.sort_values("selection_hash").head(sample_size).copy()
    sample["flag_matches_truth"] = sample["is_suspect"].eq(sample["expected_review"])
    sample["reason_matches_truth"] = sample["review_reason"].eq(sample["expected_reason"])
    return sample.sort_values("transaction_id").reset_index(drop=True)


def parse_queries(path: Path) -> dict[str, str]:
    queries: dict[str, str] = {}
    current = ""
    buffer: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith("-- "):
            if current and buffer:
                queries[current] = "\n".join(buffer).strip().rstrip(";")
            current = line[3:].strip()
            buffer = []
        else:
            buffer.append(line)
    if current and buffer:
        queries[current] = "\n".join(buffer).strip().rstrip(";")
    return queries


def write_sqlite(
    path: Path,
    policies: pd.DataFrame,
    cleaned: pd.DataFrame,
    rejected: pd.DataFrame,
    discrepancies: pd.DataFrame,
) -> dict[str, list[dict[str, Any]]]:
    if path.exists():
        path.unlink()
    with sqlite3.connect(path) as connection:
        policies.to_sql("fee_policy", connection, index=False)
        cleaned.to_sql("transactions_clean", connection, index=False)
        rejected.to_sql("rejected_rows", connection, index=False)
        discrepancies.to_sql("discrepancies", connection, index=False)
        results: dict[str, list[dict[str, Any]]] = {}
        for name, query in parse_queries(ROOT / "queries.sql").items():
            cursor = connection.execute(query)
            columns = [item[0] for item in cursor.description]
            results[name] = [dict(zip(columns, row)) for row in cursor.fetchall()]
    return results


def font(size: int, bold: bool = False) -> ImageFont.ImageFont:
    candidates = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Supplemental/HelveticaNeue.ttc",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size=size)
        except OSError:
            continue
    return ImageFont.load_default()


def chart_canvas(title: str, subtitle: str) -> tuple[Image.Image, ImageDraw.ImageDraw]:
    image = Image.new("RGB", (1400, 900), WHITE)
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, 1400, 12), fill=AMBER)
    draw.text((70, 52), title, fill=NAVY, font=font(42, True))
    draw.text((70, 112), subtitle, fill=MUTED, font=font(22))
    draw.line((70, 155, 1330, 155), fill=LINE, width=2)
    draw.text((70, 850), "Synthetic fixture • deterministic build • no client data", fill=MUTED, font=font(17))
    return image, draw


def draw_histogram(cleaned: pd.DataFrame, path: Path) -> None:
    image, draw = chart_canvas(
        "Where do realized fee rates sit?",
        "Distribution across accepted rows; amber marks the policy-review tail.",
    )
    values = cleaned["actual_fee_rate"].to_numpy() * 100
    counts, edges = np.histogram(values, bins=18)
    suspect_values = cleaned.loc[cleaned["is_suspect"].eq(1), "actual_fee_rate"].to_numpy() * 100
    suspect_counts, _ = np.histogram(suspect_values, bins=edges)
    plot = (100, 220, 1300, 760)
    x0, y0, x1, y1 = plot
    max_count = max(counts)
    bar_width = (x1 - x0) / len(counts)
    for index, count in enumerate(counts):
        left, right = edges[index], edges[index + 1]
        height = (count / max_count) * (y1 - y0 - 55)
        bx0 = x0 + index * bar_width + 3
        bx1 = x0 + (index + 1) * bar_width - 3
        draw.rectangle((bx0, y1 - height, bx1, y1), fill=BLUE)
        suspect_height = (suspect_counts[index] / max_count) * (y1 - y0 - 55)
        if suspect_height:
            draw.rectangle((bx0, y1 - suspect_height, bx1, y1), fill=AMBER)
    draw.line((x0, y1, x1, y1), fill=INK, width=2)
    for tick in np.linspace(edges[0], edges[-1], 7):
        px = x0 + (tick - edges[0]) / (edges[-1] - edges[0]) * (x1 - x0)
        draw.line((px, y1, px, y1 + 8), fill=INK, width=2)
        draw.text((px - 25, y1 + 14), f"{tick:.1f}%", fill=MUTED, font=font(16))
    draw.text((100, 185), f"{len(cleaned):,} accepted rows", fill=INK, font=font(21, True))
    draw.text((1030, 185), f"{int(cleaned['is_suspect'].sum())} review rows", fill=RED, font=font(21, True))
    image.save(path, optimize=False)


def draw_boxplot(cleaned: pd.DataFrame, path: Path) -> None:
    image, draw = chart_canvas(
        "Which services have the widest fee spread?",
        "Median and interquartile range by service; review rows are red points.",
    )
    x0, x1 = 360, 1290
    y_start, gap = 235, 100
    rate_max = max(0.18, float(cleaned["actual_fee_rate"].max()) * 1.05)
    for row_index, (service_code, group) in enumerate(cleaned.groupby("service_code", sort=True)):
        y = y_start + row_index * gap
        rates = group["actual_fee_rate"].to_numpy()
        q1, median, q3 = np.quantile(rates, [0.25, 0.5, 0.75])
        low, high = np.quantile(rates, [0.05, 0.95])
        scale = lambda value: x0 + value / rate_max * (x1 - x0)
        draw.text((75, y - 14), service_code, fill=INK, font=font(21, True))
        draw.line((scale(low), y, scale(high), y), fill=MUTED, width=3)
        draw.rectangle((scale(q1), y - 22, scale(q3), y + 22), fill=PANEL, outline=BLUE, width=4)
        draw.line((scale(median), y - 25, scale(median), y + 25), fill=NAVY, width=4)
        suspects = group.loc[group["is_suspect"].eq(1), "actual_fee_rate"]
        for value in suspects:
            px = scale(float(value))
            draw.ellipse((px - 7, y - 7, px + 7, y + 7), fill=RED)
    draw.line((x0, 760, x1, 760), fill=INK, width=2)
    for tick in np.linspace(0, rate_max, 7):
        px = x0 + tick / rate_max * (x1 - x0)
        draw.text((px - 20, 780), f"{tick * 100:.1f}%", fill=MUTED, font=font(16))
    image.save(path, optimize=False)


def draw_heatmap(cleaned: pd.DataFrame, path: Path) -> None:
    image, draw = chart_canvas(
        "When and where do review flags cluster?",
        "Monthly suspect counts by service; darker cells deserve earlier review.",
    )
    working = cleaned.assign(month=cleaned["transaction_date"].str[:7])
    pivot = working.pivot_table(index="service_code", columns="month", values="is_suspect", aggfunc="sum", fill_value=0)
    months = list(pivot.columns)
    services = list(pivot.index)
    x0, y0, cell_w, cell_h = 350, 240, 145, 88
    maximum = max(1, int(pivot.to_numpy().max()))
    for column, month in enumerate(months):
        draw.text((x0 + column * cell_w + 18, y0 - 48), month[5:], fill=INK, font=font(21, True))
    for row, service in enumerate(services):
        y = y0 + row * cell_h
        draw.text((75, y + 27), service, fill=INK, font=font(20, True))
        for column, month in enumerate(months):
            value = int(pivot.loc[service, month])
            ratio = value / maximum
            color = WHITE if value == 0 else (
                int(248 - 47 * ratio),
                int(232 - 158 * ratio),
                int(200 - 126 * ratio),
            )
            x = x0 + column * cell_w
            draw.rectangle((x, y, x + cell_w - 10, y + cell_h - 10), fill=color, outline=LINE, width=2)
            draw.text((x + 58, y + 24), str(value), fill=NAVY, font=font(25, True))
    draw.text((350, 720), "0 = no review flags", fill=MUTED, font=font(18))
    draw.text((1040, 720), f"max cell = {maximum}", fill=RED, font=font(18, True))
    image.save(path, optimize=False)


def notebook_payload() -> dict[str, Any]:
    def code(source: str) -> dict[str, Any]:
        return {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": source.splitlines(True)}

    def markdown(source: str) -> dict[str, Any]:
        return {"cell_type": "markdown", "metadata": {}, "source": source.splitlines(True)}

    return {
        "cells": [
            markdown("# Service fee discrepancy analysis\nDeterministic synthetic proof; no client data."),
            code("from pathlib import Path\nimport sqlite3\nimport pandas as pd\nDIST = Path('dist')\ntransactions = pd.read_csv(DIST / 'cleaned_transactions.csv')\npolicy = pd.read_csv(DIST / 'synthetic_fee_policy.csv')\n"),
            code("transactions.loc[transactions['is_suspect'].eq(1), ['transaction_id','service_code','fee_delta','review_reason']].sort_values('fee_delta', key=lambda s: s.abs(), ascending=False).head(20)\n"),
            code("with sqlite3.connect(DIST / 'analysis.sqlite') as connection:\n    sql_profile = pd.read_sql_query('SELECT service_code, COUNT(*) transaction_count, ROUND(SUM(realized_revenue),2) realized_revenue, ROUND(SUM(listed_fee),2) listed_fee, SUM(is_suspect) suspect_count FROM transactions_clean GROUP BY service_code ORDER BY service_code', connection)\nsql_profile\n"),
            markdown("The packaged build script generates the histogram, box plot, heat map, receipt, and archive from the same accepted-row table."),
        ],
        "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python", "version": "3"}},
        "nbformat": 4,
        "nbformat_minor": 5,
    }


def write_brief(path: Path, summary: dict[str, Any]) -> None:
    top_reason = max(summary["review_reason_counts"], key=summary["review_reason_counts"].get)
    text = f"""# Service Fee Discrepancy Analysis

**Synthetic portfolio proof · as of {AS_OF}**

## Decision

The accepted ledger contains **{summary['accepted_rows']} unique transactions** and **{summary['suspect_rows']} review flags**. The largest review class is `{top_reason}`. Review the ranked discrepancy queue before changing any service policy because missing values and duplicates were quarantined separately rather than blended into fee exceptions.

## Reconciliation

- Source rows: {summary['source_rows']}
- Accepted unique rows: {summary['accepted_rows']}
- Rejected rows: {summary['rejected_rows']}
- Review flags: {summary['suspect_rows']}
- Deterministic spot-check: {summary['spot_check_rows']} rows ({summary['spot_check_pct']:.0f}%), all matched fixture truth
- Pandas/SQL parity: passed for counts, revenue, fees, flags, and absolute fee delta

## Visual evidence

1. `fee_distribution_histogram.png` shows the overall realized-rate distribution.
2. `service_fee_boxplot.png` reveals spread and row-level outliers by service.
3. `monthly_discrepancy_heatmap.png` shows where review flags cluster over time.

## Scope boundary

This deterministic fixture proves the audit mechanics, not a real client's fee policy. Production work starts by confirming the source schema, policy effective dates, currency and rounding rules, tolerance, and authorized data-handling boundary.
"""
    path.write_text(text, encoding="utf-8")


def write_html(path: Path, summary: dict[str, Any]) -> None:
    rows = "".join(
        f"<tr><td>{name}</td><td>{count}</td></tr>"
        for name, count in sorted(summary["review_reason_counts"].items())
    )
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Service Fee Discrepancy Analysis — Synthetic Proof</title>
<style>body{{font:17px/1.55 Arial,sans-serif;color:#25334a;background:#fff;margin:0}}main{{max-width:1050px;margin:auto;padding:56px 28px}}h1{{font-size:44px;line-height:1.08;color:#152238}}.eyebrow{{color:#a86400;font-weight:700}}.decision{{border-left:5px solid #d98b19;padding:8px 24px;background:#f8f4ec;margin:34px 0}}table{{border-collapse:collapse;width:100%;max-width:620px}}td,th{{padding:12px;border-bottom:1px solid #d8e0ea;text-align:left}}img{{display:block;width:100%;height:auto;margin:26px 0 54px;border:1px solid #d8e0ea}}code{{background:#f4f7fb;padding:2px 5px}}footer{{color:#647184;margin-top:50px}}</style></head>
<body><main><p class="eyebrow">SYNTHETIC REPRODUCIBLE PROOF</p><h1>Service fee discrepancy analysis</h1>
<div class="decision"><strong>Decision:</strong> {summary['suspect_rows']} of {summary['accepted_rows']} accepted rows require review. Invalid and duplicate rows are quarantined separately.</div>
<h2>Reconciled outcome</h2><table><tr><th>Review reason</th><th>Rows</th></tr>{rows}</table>
<h2>Distribution</h2><img src="fee_distribution_histogram.png" alt="Histogram of realized service fee rates">
<h2>Service spread</h2><img src="service_fee_boxplot.png" alt="Box plot of fee rates by service">
<h2>Review concentration</h2><img src="monthly_discrepancy_heatmap.png" alt="Heat map of monthly review counts by service">
<footer>Fictional data. Deterministic local build. No client, account, or payment data.</footer></main></body></html>"""
    path.write_text(html, encoding="utf-8")


def deterministic_zip(path: Path, files: Iterable[Path]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source in sorted(files, key=lambda item: item.name):
            info = zipfile.ZipInfo(source.name, date_time=(2026, 8, 9, 5, 45, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, source.read_bytes())


def build(output: Path = DIST, archive_path: Path | None = None) -> dict[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    archive_path = archive_path or (OUTPUT / "Service_Fee_Discrepancy_Proof.zip")
    archive_path.parent.mkdir(parents=True, exist_ok=True)

    raw, policies, truth = generate_fixture()
    cleaned, rejected, service_profile, discrepancies = analyze(raw, policies)
    spot_check = deterministic_spot_check(cleaned, truth)

    raw.to_csv(output / "synthetic_transactions.csv", index=False, lineterminator="\n")
    policies.to_csv(output / "synthetic_fee_policy.csv", index=False, lineterminator="\n")
    truth.to_csv(output / "synthetic_ground_truth.csv", index=False, lineterminator="\n")
    cleaned.to_csv(output / "cleaned_transactions.csv", index=False, lineterminator="\n")
    rejected.to_csv(output / "rejected_rows.csv", index=False, lineterminator="\n")
    service_profile.to_csv(output / "service_profile.csv", index=False, lineterminator="\n")
    discrepancies.to_csv(output / "ranked_discrepancies.csv", index=False, lineterminator="\n")
    spot_check.to_csv(output / "spot_check_95pct.csv", index=False, lineterminator="\n")

    sql_results = write_sqlite(output / "analysis.sqlite", policies, cleaned, rejected, discrepancies)
    (output / "sql_results.json").write_text(json.dumps(sql_results, indent=2, sort_keys=True), encoding="utf-8")
    (output / "analysis.ipynb").write_text(json.dumps(notebook_payload(), indent=2), encoding="utf-8")

    truth_lookup = truth.set_index("source_row_id")
    cleaned_truth = cleaned.join(truth_lookup[["expected_review", "expected_reason"]], on="source_row_id")
    rejected_truth = rejected.join(truth_lookup[["expected_outcome", "expected_reason"]], on="source_row_id")
    all_flags_match = bool(
        cleaned_truth["is_suspect"].eq(cleaned_truth["expected_review"]).all()
        and cleaned_truth["review_reason"].eq(cleaned_truth["expected_reason"]).all()
    )
    all_rejections_match = bool(
        rejected_truth["expected_outcome"].eq("rejected").all()
        and rejected_truth["rejection_reason"].eq(rejected_truth["expected_reason"]).all()
    )
    pandas_reconciliation = {
        "accepted_rows": int(len(cleaned)),
        "realized_revenue": round(float(cleaned["realized_revenue"].sum()), 2),
        "listed_fee": round(float(cleaned["listed_fee"].sum()), 2),
        "suspect_rows": int(cleaned["is_suspect"].sum()),
        "absolute_fee_delta": round(float(cleaned["fee_delta"].abs().sum()), 2),
    }
    sql_reconciliation = sql_results["reconciliation"][0]
    sql_parity = all(
        float(sql_reconciliation[key]) == float(value)
        for key, value in pandas_reconciliation.items()
    )

    summary = {
        "as_of": AS_OF,
        "synthetic_fixture": True,
        "seed": SEED,
        "source_rows": int(len(raw)),
        "accepted_rows": int(len(cleaned)),
        "rejected_rows": int(len(rejected)),
        "suspect_rows": int(cleaned["is_suspect"].sum()),
        "review_reason_counts": {str(k): int(v) for k, v in cleaned.loc[cleaned["is_suspect"].eq(1), "review_reason"].value_counts().sort_index().items()},
        "rejection_reason_counts": {str(k): int(v) for k, v in rejected["rejection_reason"].value_counts().sort_index().items()},
        "spot_check_rows": int(len(spot_check)),
        "spot_check_pct": len(spot_check) / len(cleaned) * 100,
        "all_flags_match_fixture_truth": all_flags_match,
        "all_rejections_match_fixture_truth": all_rejections_match,
        "spot_check_matches_fixture_truth": bool(spot_check[["flag_matches_truth", "reason_matches_truth"]].all().all()),
        "pandas_sql_reconciliation_parity": sql_parity,
        "pandas_reconciliation": pandas_reconciliation,
    }
    write_brief(output / "narrative_report.md", summary)
    draw_histogram(cleaned, output / "fee_distribution_histogram.png")
    draw_boxplot(cleaned, output / "service_fee_boxplot.png")
    draw_heatmap(cleaned, output / "monthly_discrepancy_heatmap.png")
    write_html(output / "evidence_brief.html", summary)

    hash_targets = [path for path in output.iterdir() if path.is_file() and path.name not in {"verification_receipt.json", "SHA256SUMS"}]
    artifact_hashes = {path.name: sha256(path) for path in sorted(hash_targets)}
    receipt = {
        **summary,
        "artifact_hashes": artifact_hashes,
        "receipt_sha256": canonical_hash({"summary": summary, "artifact_hashes": artifact_hashes}),
    }
    (output / "verification_receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True), encoding="utf-8")
    all_package_files = hash_targets + [output / "verification_receipt.json", ROOT / "queries.sql", ROOT / "build_proof.py", ROOT / "verify_proof.py", ROOT / "README.md"]
    deterministic_zip(archive_path, all_package_files)
    sums = {path.name: sha256(path) for path in all_package_files}
    sums[archive_path.name] = sha256(archive_path)
    (output / "SHA256SUMS").write_text("".join(f"{digest}  {name}\n" for name, digest in sorted(sums.items())), encoding="utf-8")
    return receipt


if __name__ == "__main__":
    result = build()
    print(json.dumps({
        "accepted_rows": result["accepted_rows"],
        "rejected_rows": result["rejected_rows"],
        "suspect_rows": result["suspect_rows"],
        "spot_check_rows": result["spot_check_rows"],
        "receipt_sha256": result["receipt_sha256"],
    }, indent=2))
