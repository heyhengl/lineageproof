-- service_profile
SELECT
    service_code,
    COUNT(*) AS transaction_count,
    ROUND(SUM(realized_revenue), 2) AS realized_revenue,
    ROUND(SUM(listed_fee), 2) AS listed_fee,
    SUM(is_suspect) AS suspect_count,
    ROUND(SUM(ABS(fee_delta)), 2) AS absolute_fee_delta
FROM transactions_clean
GROUP BY service_code
ORDER BY service_code;

-- reason_rollup
SELECT
    review_reason,
    COUNT(*) AS row_count,
    ROUND(SUM(ABS(fee_delta)), 2) AS absolute_fee_delta
FROM transactions_clean
WHERE is_suspect = 1
GROUP BY review_reason
ORDER BY review_reason;

-- monthly_service_heatmap
SELECT
    substr(transaction_date, 1, 7) AS month,
    service_code,
    SUM(is_suspect) AS suspect_count
FROM transactions_clean
GROUP BY month, service_code
ORDER BY month, service_code;

-- reconciliation
SELECT
    COUNT(*) AS accepted_rows,
    ROUND(SUM(realized_revenue), 2) AS realized_revenue,
    ROUND(SUM(listed_fee), 2) AS listed_fee,
    SUM(is_suspect) AS suspect_rows,
    ROUND(SUM(ABS(fee_delta)), 2) AS absolute_fee_delta
FROM transactions_clean;

