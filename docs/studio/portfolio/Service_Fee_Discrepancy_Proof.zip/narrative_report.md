# Service Fee Discrepancy Analysis

**Synthetic portfolio proof · as of 2026-08-09T13:45:00+08:00**

## Decision

The accepted ledger contains **472 unique transactions** and **20 review flags**. The largest review class is `ABOVE_POLICY_RANGE`. Review the ranked discrepancy queue before changing any service policy because missing values and duplicates were quarantined separately rather than blended into fee exceptions.

## Reconciliation

- Source rows: 483
- Accepted unique rows: 472
- Rejected rows: 11
- Review flags: 20
- Deterministic spot-check: 449 rows (95%), all matched fixture truth
- Pandas/SQL parity: passed for counts, revenue, fees, flags, and absolute fee delta

## Visual evidence

1. `fee_distribution_histogram.png` shows the overall realized-rate distribution.
2. `service_fee_boxplot.png` reveals spread and row-level outliers by service.
3. `monthly_discrepancy_heatmap.png` shows where review flags cluster over time.

## Scope boundary

This deterministic fixture proves the audit mechanics, not a real client's fee policy. Production work starts by confirming the source schema, policy effective dates, currency and rounding rules, tolerance, and authorized data-handling boundary.
