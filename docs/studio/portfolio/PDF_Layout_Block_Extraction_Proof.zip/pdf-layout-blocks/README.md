# PDF Layout Block Extraction - Synthetic Proof

This privacy-safe prototype supports the proposal for 一品威客 task 1157909.
It is a synthetic technical proof, not a customer case study.

## What it proves

- Three-page born-digital PDF layout extraction.
- Title, subtitle, byline, continuation, body, pull-quote, image, and caption blocks.
- Cross-page article grouping and page-level reading order.
- Top-left PDF-point bbox, native bottom-left PDF bbox, and 144 dpi integer map-area coordinates.
- A versioned JSON response plus an OpenAPI 3.1 contract.
- Measured block, type, article, reading-order, and bbox results against frozen synthetic ground truth.
- An explicit open issue when a centered image and caption have ambiguous article ownership.

## Truth boundary

The proof does not establish OCR accuracy, arbitrary scan support, handwriting or complex-table handling, customer-file accuracy, production API hosting, authentication, monitoring, throughput, or SLA. All fixture values and images are synthetic. No customer, platform, identity, payment, credential, Cookie, or private-strategy data is included.

## Rebuild

Use the bundled Python runtime or another Python environment containing ReportLab, pdfplumber, pypdf, and Pillow. Poppler `pdftoppm` is required for rendered evidence.

```bash
python3 run_proof.py
```

The command regenerates the fixture, extracts blocks, audits metrics, renders coordinate overlays, builds the five-page Chinese evidence PDF, runs the tests, and creates the deterministic proof archive.

## Key outputs

- `dist/sample_response.json`: page blocks, article groups, coordinates, and issues.
- `dist/audit_report.json`: thresholds and measured results.
- `dist/unresolved_issues.md`: reviewer-facing open issue log.
- `openapi.yaml`: API contract.
- `output/pdf/PDF_Layout_Block_Extraction_Prototype_Evidence.pdf`: submission-safe evidence PDF.
- `output/portfolio/PDF_Layout_Block_Extraction_Proof_2026-07-18.zip`: source and evidence archive; keep local unless source is explicitly requested.
