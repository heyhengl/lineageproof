#!/usr/bin/env python3
"""Rebuild and verify the complete PDF layout-block proof."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


BASE = Path(__file__).resolve().parent


def run(*arguments: str) -> None:
    subprocess.run([sys.executable, *arguments], cwd=BASE, check=True)


def main() -> None:
    for script in [
        "generate_fixture.py",
        "extract_layout.py",
        "audit_prototype.py",
        "render_overlays.py",
        "build_evidence.py",
    ]:
        run(script)
    run("-m", "unittest", "discover", "-s", "tests", "-v")
    run("package_proof.py")
    audit = json.loads((BASE / "dist" / "audit_report.json").read_text(encoding="utf-8"))
    print(json.dumps({"proof_passed": audit["passed"], "metrics": audit["metrics"]}, sort_keys=True))


if __name__ == "__main__":
    main()
