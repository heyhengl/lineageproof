#!/usr/bin/env python3
"""Compare prototype output with synthetic ground truth and freeze QA metrics."""

from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path
from typing import Any


BASE = Path(__file__).resolve().parent
FIXTURES = BASE / "fixtures"
DIST = BASE / "dist"
GROUND_TRUTH = FIXTURES / "layout_ground_truth.json"
OUTPUT_JSON = DIST / "sample_response.json"
AUDIT_JSON = DIST / "audit_report.json"
METRICS_CSV = DIST / "metrics.csv"
ISSUE_LOG = DIST / "unresolved_issues.md"
OPENAPI = BASE / "openapi.yaml"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def as_bbox(block: dict[str, Any]) -> list[float]:
    bbox = block["bbox"]
    return [float(bbox["x0"]), float(bbox["y0"]), float(bbox["x1"]), float(bbox["y1"])]


def bbox_iou(left: list[float], right: list[float]) -> float:
    ix0, iy0 = max(left[0], right[0]), max(left[1], right[1])
    ix1, iy1 = min(left[2], right[2]), min(left[3], right[3])
    intersection = max(0.0, ix1 - ix0) * max(0.0, iy1 - iy0)
    left_area = max(0.0, left[2] - left[0]) * max(0.0, left[3] - left[1])
    right_area = max(0.0, right[2] - right[0]) * max(0.0, right[3] - right[1])
    union = left_area + right_area - intersection
    return intersection / union if union else 0.0


def contract_check(payload: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    required_root = {"schema_version", "document", "coordinate_systems", "pages", "articles", "issues"}
    missing = required_root - set(payload)
    if missing:
        errors.append(f"missing root fields: {sorted(missing)}")
    if payload.get("schema_version") != "1.0":
        errors.append("schema_version must equal 1.0")
    if not re.fullmatch(r"[a-f0-9]{64}", str(payload.get("document", {}).get("source_sha256", ""))):
        errors.append("document.source_sha256 is invalid")
    allowed_types = {"title", "subtitle", "byline", "continuation", "body", "pull_quote", "image", "caption"}
    for page in payload.get("pages", []):
        orders = []
        for block in page.get("blocks", []):
            missing_block = {"id", "page_number", "type", "article_id", "confidence", "reading_order", "text", "bbox", "bbox_pdf", "map_area"} - set(block)
            if missing_block:
                errors.append(f"{block.get('id', 'unknown')}: missing {sorted(missing_block)}")
                continue
            if block["type"] not in allowed_types:
                errors.append(f"{block['id']}: unsupported type {block['type']}")
            if not 0 <= float(block["confidence"]) <= 1:
                errors.append(f"{block['id']}: confidence outside 0..1")
            bbox = as_bbox(block)
            coords = block["map_area"]["coords"]
            expected_coords = [int(round(value * float(block["map_area"]["render_scale"]))) for value in bbox]
            if coords != expected_coords:
                errors.append(f"{block['id']}: map-area does not match bbox and render scale")
            if not (0 <= coords[0] < coords[2] <= int(block["map_area"]["canvas_width"])):
                errors.append(f"{block['id']}: map-area x coordinates outside canvas")
            if not (0 <= coords[1] < coords[3] <= int(block["map_area"]["canvas_height"])):
                errors.append(f"{block['id']}: map-area y coordinates outside canvas")
            orders.append(int(block["reading_order"]))
        if sorted(orders) != list(range(1, len(orders) + 1)):
            errors.append(f"page {page.get('page_number')}: reading order is not contiguous")
    if "POST /v1/layout/extract" not in str(payload.get("contract", {}).get("endpoint", "")):
        errors.append("contract endpoint missing")
    if "/v1/layout/extract:" not in OPENAPI.read_text(encoding="utf-8"):
        errors.append("openapi.yaml endpoint missing")
    return not errors, errors


def main() -> None:
    ground_truth = json.loads(GROUND_TRUTH.read_text(encoding="utf-8"))
    output = json.loads(OUTPUT_JSON.read_text(encoding="utf-8"))
    detected = [block for page in output["pages"] for block in page["blocks"]]
    expected = ground_truth["blocks"]
    unmatched = set(range(len(detected)))
    matches: list[tuple[dict[str, Any], dict[str, Any]]] = []

    for target in expected:
        candidates = []
        for index in unmatched:
            candidate = detected[index]
            if int(candidate["page_number"]) != int(target["page_number"]):
                continue
            if target["type"] == "image":
                if candidate["type"] != "image":
                    continue
                score = bbox_iou(list(map(float, target["bbox_top_left_pt"])), as_bbox(candidate))
            else:
                if normalize_text(str(candidate["text"])) != normalize_text(str(target["text"])):
                    continue
                score = 1.0
            candidates.append((score, index, candidate))
        if not candidates:
            continue
        _, index, candidate = max(candidates, key=lambda item: item[0])
        unmatched.remove(index)
        matches.append((target, candidate))

    ious = [bbox_iou(list(map(float, target["bbox_top_left_pt"])), as_bbox(candidate)) for target, candidate in matches]
    edge_errors = [
        abs(expected_edge - detected_edge)
        for target, candidate in matches
        for expected_edge, detected_edge in zip(map(float, target["bbox_top_left_pt"]), as_bbox(candidate), strict=True)
    ]
    type_correct = sum(target["type"] == candidate["type"] for target, candidate in matches)
    article_correct = sum(target["article_id"] == candidate["article_id"] for target, candidate in matches)

    matched_by_page: dict[int, list[tuple[dict[str, Any], dict[str, Any]]]] = {}
    for target, candidate in matches:
        matched_by_page.setdefault(int(target["page_number"]), []).append((target, candidate))
    correct_pairs = 0
    total_pairs = 0
    for page_matches in matched_by_page.values():
        for left_index, (left_target, left_candidate) in enumerate(page_matches):
            for right_target, right_candidate in page_matches[left_index + 1:]:
                expected_relation = int(left_target["reading_order"]) < int(right_target["reading_order"])
                detected_relation = int(left_candidate["reading_order"]) < int(right_candidate["reading_order"])
                correct_pairs += expected_relation == detected_relation
                total_pairs += 1

    contract_valid, contract_errors = contract_check(output)
    ambiguous = [issue for issue in output["issues"] if issue["issue_code"] == "AMBIGUOUS_ARTICLE_ASSOCIATION" and issue["status"] == "open"]
    matched_lookup = {target["block_id"]: candidate["id"] for target, candidate in matches}
    expected_ambiguous_ids = set(ground_truth["expected_unresolved_issues"][0]["block_ids"])
    ambiguity_logged = len(ambiguous) == 1 and {matched_lookup[item] for item in expected_ambiguous_ids} == set(ambiguous[0]["block_ids"])

    metrics = {
        "expected_blocks": len(expected),
        "detected_blocks": len(detected),
        "matched_blocks": len(matches),
        "block_precision": round(len(matches) / len(detected), 4) if detected else 0.0,
        "block_recall": round(len(matches) / len(expected), 4) if expected else 0.0,
        "type_accuracy": round(type_correct / len(matches), 4) if matches else 0.0,
        "article_group_accuracy": round(article_correct / len(matches), 4) if matches else 0.0,
        "reading_order_pair_accuracy": round(correct_pairs / total_pairs, 4) if total_pairs else 0.0,
        "mean_bbox_iou": round(sum(ious) / len(ious), 4) if ious else 0.0,
        "max_bbox_edge_error_pt": round(max(edge_errors), 4) if edge_errors else 0.0,
        "map_area_contract_valid": contract_valid,
        "unresolved_issue_count": len(output["issues"]),
        "expected_ambiguity_logged": ambiguity_logged,
    }
    thresholds = {
        "block_precision_gte_0_98": metrics["block_precision"] >= 0.98,
        "block_recall_gte_0_98": metrics["block_recall"] >= 0.98,
        "type_accuracy_gte_0_98": metrics["type_accuracy"] >= 0.98,
        "article_group_accuracy_gte_0_98": metrics["article_group_accuracy"] >= 0.98,
        "reading_order_pair_accuracy_gte_0_95": metrics["reading_order_pair_accuracy"] >= 0.95,
        "mean_bbox_iou_gte_0_90": metrics["mean_bbox_iou"] >= 0.90,
        "contract_valid": contract_valid,
        "expected_ambiguity_logged": ambiguity_logged,
    }
    passed = all(thresholds.values())
    report = {
        "prototype": "pdf-layout-blocks-v1",
        "scope": "synthetic born-digital PDF; OCR, arbitrary scans, tables, and production API hosting are not proven",
        "contains_customer_data": False,
        "source_pdf_sha256": sha256(FIXTURES / ground_truth["fixture"]["file"]),
        "sample_response_sha256": sha256(OUTPUT_JSON),
        "metrics": metrics,
        "thresholds": thresholds,
        "contract_errors": contract_errors,
        "passed": passed,
    }
    AUDIT_JSON.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with METRICS_CSV.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["metric", "value"])
        writer.writerows(metrics.items())

    issue_lines = [
        "# Unresolved Issue Log",
        "",
        "This log is generated from the prototype output. It contains no customer data.",
        "",
    ]
    for issue in output["issues"]:
        issue_lines.extend(
            [
                f"## {issue['issue_id']} - {issue['issue_code']}",
                "",
                f"- Status: {issue['status']}",
                f"- Page: {issue['page_number']}",
                f"- Blocks: {', '.join(issue['block_ids'])}",
                f"- Candidate articles: {', '.join(issue.get('candidate_article_ids', []))}",
                f"- Reason: {issue['reason']}",
                "- Required action: reviewer selects the article or explicitly marks the image as shared.",
                "",
            ]
        )
    ISSUE_LOG.write_text("\n".join(issue_lines).rstrip() + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True))
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
