from __future__ import annotations

import json
import re
import unittest
from pathlib import Path

from pypdf import PdfReader


TESTS = Path(__file__).resolve().parent
PROJECT = TESTS.parent
ROOT = PROJECT.parents[3]
DIST = PROJECT / "dist"
FIXTURES = PROJECT / "fixtures"
EVIDENCE = ROOT / "output" / "pdf" / "PDF_Layout_Block_Extraction_Prototype_Evidence.pdf"


class LayoutExtractionProofTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.response = json.loads((DIST / "sample_response.json").read_text(encoding="utf-8"))
        cls.audit = json.loads((DIST / "audit_report.json").read_text(encoding="utf-8"))
        cls.ground_truth = json.loads((FIXTURES / "layout_ground_truth.json").read_text(encoding="utf-8"))

    def test_audit_thresholds_pass(self) -> None:
        self.assertTrue(self.audit["passed"])
        self.assertTrue(all(self.audit["thresholds"].values()))
        self.assertEqual(self.audit["metrics"]["block_precision"], 1.0)
        self.assertEqual(self.audit["metrics"]["block_recall"], 1.0)
        self.assertGreaterEqual(self.audit["metrics"]["mean_bbox_iou"], 0.90)

    def test_cross_page_article_and_distinct_new_article(self) -> None:
        articles = {article["article_id"]: article for article in self.response["articles"]}
        self.assertEqual(articles["article-001"]["page_numbers"], [1, 2])
        self.assertEqual(articles["article-002"]["page_numbers"], [2])
        self.assertEqual(len(articles), 4)

    def test_map_area_matches_bbox_and_canvas(self) -> None:
        for page in self.response["pages"]:
            orders = []
            for block in page["blocks"]:
                bbox = block["bbox"]
                expected = [int(round(float(bbox[key]) * 2)) for key in ("x0", "y0", "x1", "y1")]
                self.assertEqual(block["map_area"]["coords"], expected)
                self.assertLess(expected[0], expected[2])
                self.assertLess(expected[1], expected[3])
                self.assertLessEqual(expected[2], block["map_area"]["canvas_width"])
                self.assertLessEqual(expected[3], block["map_area"]["canvas_height"])
                orders.append(block["reading_order"])
            self.assertEqual(sorted(orders), list(range(1, len(orders) + 1)))

    def test_ambiguous_image_and_caption_are_not_forced(self) -> None:
        self.assertEqual(len(self.response["issues"]), 1)
        issue = self.response["issues"][0]
        self.assertEqual(issue["issue_code"], "AMBIGUOUS_ARTICLE_ASSOCIATION")
        blocks = {block["id"]: block for page in self.response["pages"] for block in page["blocks"]}
        self.assertEqual({blocks[block_id]["type"] for block_id in issue["block_ids"]}, {"image", "caption"})
        self.assertTrue(all(blocks[block_id]["article_id"] is None for block_id in issue["block_ids"]))

    def test_privacy_flags_and_sensitive_token_scan(self) -> None:
        self.assertFalse(self.response["document"]["contains_customer_data"])
        self.assertFalse(self.ground_truth["fixture"]["contains_customer_data"])
        combined = "\n".join(
            path.read_text(encoding="utf-8", errors="ignore")
            for path in [DIST / "sample_response.json", DIST / "audit_report.json", FIXTURES / "layout_ground_truth.json"]
        )
        patterns = [r"api[_-]?key\s*[:=]", r"authorization\s*:\s*bearer", r"cookie\s*=", r"BEGIN [A-Z ]*PRIVATE KEY"]
        self.assertFalse(any(re.search(pattern, combined, flags=re.IGNORECASE) for pattern in patterns))

    def test_evidence_pdf_is_five_page_a4(self) -> None:
        reader = PdfReader(str(EVIDENCE))
        self.assertEqual(len(reader.pages), 5)
        self.assertIn("PDF", "\n".join((page.extract_text() or "") for page in reader.pages))
        first = reader.pages[0].mediabox
        self.assertAlmostEqual(float(first.width), 595.276, places=2)
        self.assertAlmostEqual(float(first.height), 841.89, places=2)


if __name__ == "__main__":
    unittest.main()
