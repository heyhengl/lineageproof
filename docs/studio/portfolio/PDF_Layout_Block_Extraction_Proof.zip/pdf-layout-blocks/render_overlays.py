#!/usr/bin/env python3
"""Render the source PDF at 144 dpi and overlay extracted block coordinates."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
SOURCE = BASE / "fixtures" / "Synthetic_Layout_Field_Notes.pdf"
RESPONSE = BASE / "dist" / "sample_response.json"
TEMP = ROOT / "tmp" / "pdfs" / "pdf-layout-blocks"
OVERLAYS = BASE / "dist" / "overlays"


COLORS = {
    "title": "#D1495B",
    "subtitle": "#7A5195",
    "byline": "#2F6B8A",
    "continuation": "#2F6B8A",
    "body": "#197278",
    "pull_quote": "#EDAE49",
    "image": "#F28E2B",
    "caption": "#6C757D",
}


def main() -> None:
    renderer = shutil.which("pdftoppm")
    if renderer is None:
        raise RuntimeError("pdftoppm is required for visual verification")
    TEMP.mkdir(parents=True, exist_ok=True)
    OVERLAYS.mkdir(parents=True, exist_ok=True)
    prefix = TEMP / "source"
    subprocess.run([renderer, "-png", "-r", "144", str(SOURCE), str(prefix)], check=True)
    payload = json.loads(RESPONSE.read_text(encoding="utf-8"))
    font = ImageFont.load_default()
    for page in payload["pages"]:
        source_png = TEMP / f"source-{page['page_number']}.png"
        target_png = OVERLAYS / f"page-{page['page_number']}-overlay.png"
        image = Image.open(source_png).convert("RGB")
        draw = ImageDraw.Draw(image)
        for block in page["blocks"]:
            x0, y0, x1, y1 = block["map_area"]["coords"]
            color = COLORS[block["type"]]
            width = 6 if block["article_id"] is None else 4
            draw.rectangle((x0, y0, x1, y1), outline=color, width=width)
            article = block["article_id"] or "UNRESOLVED"
            label = f"{block['reading_order']:02d} {block['type']} / {article}"
            text_bbox = draw.textbbox((0, 0), label, font=font)
            label_width = text_bbox[2] - text_bbox[0] + 10
            label_height = text_bbox[3] - text_bbox[1] + 7
            label_y = y0 if y0 + label_height < image.height else max(0, y1 - label_height)
            draw.rectangle((x0, label_y, min(image.width, x0 + label_width), label_y + label_height), fill=color)
            draw.text((x0 + 5, label_y + 3), label, fill="white", font=font)
        image.save(target_png, format="PNG", optimize=True)
    print(json.dumps({"rendered_pages": len(payload["pages"]), "overlay_dir": str(OVERLAYS)}, sort_keys=True))


if __name__ == "__main__":
    main()
