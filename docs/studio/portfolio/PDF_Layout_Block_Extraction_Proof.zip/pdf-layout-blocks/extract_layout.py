#!/usr/bin/env python3
"""Extract typed PDF layout blocks, article groups, and map-area coordinates."""

from __future__ import annotations

import hashlib
import json
import math
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

import pdfplumber
from pypdf import PdfReader


BASE = Path(__file__).resolve().parent
FIXTURES = BASE / "fixtures"
DIST = BASE / "dist"
SOURCE_PDF = FIXTURES / "Synthetic_Layout_Field_Notes.pdf"
OUTPUT_JSON = DIST / "sample_response.json"
ISSUES_JSON = DIST / "issues.json"
RENDER_SCALE = 2.0  # 144 dpi from a 72-point PDF coordinate system.


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def union_bbox(items: list[dict[str, Any]]) -> list[float]:
    return [
        min(float(item["x0"]) for item in items),
        min(float(item["top"]) for item in items),
        max(float(item["x1"]) for item in items),
        max(float(item["bottom"]) for item in items),
    ]


def line_segments(words: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Cluster words into visual lines, splitting wide gaps between columns."""
    bands: list[dict[str, Any]] = []
    for word in sorted(words, key=lambda item: (float(item["top"]), float(item["x0"]))):
        match = None
        for band in reversed(bands[-12:]):
            if (
                abs(float(word["top"]) - float(band["top"])) <= 1.5
                and abs(float(word.get("size", 0)) - float(band["size"])) <= 0.25
                and word.get("fontname") == band.get("fontname")
            ):
                match = band
                break
        if match is None:
            match = {
                "top": float(word["top"]),
                "size": float(word.get("size", 0)),
                "fontname": word.get("fontname", ""),
                "words": [],
            }
            bands.append(match)
        match["words"].append(word)

    lines: list[dict[str, Any]] = []
    for band in bands:
        current: list[dict[str, Any]] = []
        previous_x1: float | None = None
        for word in sorted(band["words"], key=lambda item: float(item["x0"])):
            gap = float(word["x0"]) - previous_x1 if previous_x1 is not None else 0
            if current and gap > 26:
                bbox = union_bbox(current)
                lines.append(
                    {
                        "text": normalize_text(" ".join(str(item["text"]) for item in current)),
                        "x0": bbox[0], "top": bbox[1], "x1": bbox[2], "bottom": bbox[3],
                        "size": float(band["size"]), "fontname": band["fontname"],
                    }
                )
                current = []
            current.append(word)
            previous_x1 = float(word["x1"])
        if current:
            bbox = union_bbox(current)
            lines.append(
                {
                    "text": normalize_text(" ".join(str(item["text"]) for item in current)),
                    "x0": bbox[0], "top": bbox[1], "x1": bbox[2], "bottom": bbox[3],
                    "size": float(band["size"]), "fontname": band["fontname"],
                }
            )
    return sorted(lines, key=lambda item: (float(item["top"]), float(item["x0"])))


def text_blocks(lines: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Join adjacent lines that share typeface, size, and left alignment."""
    blocks: list[dict[str, Any]] = []
    for line in lines:
        candidate = None
        for block in reversed(blocks[-16:]):
            last = block["lines"][-1]
            vertical_gap = float(line["top"]) - float(last["bottom"])
            if (
                abs(float(line["x0"]) - float(block["anchor_x"])) <= 3.0
                and abs(float(line["size"]) - float(block["size"])) <= 0.25
                and line["fontname"] == block["fontname"]
                and -0.5 <= vertical_gap <= max(7.5, float(line["size"]) * 0.9)
            ):
                candidate = block
                break
        if candidate is None:
            candidate = {
                "lines": [],
                "anchor_x": float(line["x0"]),
                "size": float(line["size"]),
                "fontname": line["fontname"],
            }
            blocks.append(candidate)
        candidate["lines"].append(line)

    result: list[dict[str, Any]] = []
    for block in blocks:
        bbox = union_bbox(block["lines"])
        result.append(
            {
                "text": normalize_text(" ".join(str(line["text"]) for line in block["lines"])),
                "x0": bbox[0], "top": bbox[1], "x1": bbox[2], "bottom": bbox[3],
                "size": float(block["size"]), "fontname": block["fontname"],
            }
        )
    return result


def classify(block: dict[str, Any]) -> tuple[str, float]:
    text = str(block["text"])
    upper = text.upper()
    size = float(block["size"])
    font = str(block["fontname"])
    if "CONTINUED" in upper and size <= 9.5 and ("BOLD" in font.upper()) and len(text) <= 80:
        return "continuation", 0.99
    if upper.startswith("BY "):
        return "byline", 0.99
    if size >= 18:
        return "title", 0.99
    if ("OBLIQUE" in font.upper() or "ITALIC" in font.upper()) and size >= 11:
        return "pull_quote", 0.97
    if 10.5 <= size < 14:
        return "subtitle", 0.94
    if size <= 7.7:
        return "caption", 0.96
    return "body", 0.95


def title_tokens(text: str) -> set[str]:
    stop = {"A", "AN", "AND", "AS", "AT", "BY", "FIELD", "NOTES", "OF", "THE", "TO", "CONTINUED"}
    return {token for token in re.findall(r"[A-Z0-9]+", text.upper()) if len(token) > 2 and token not in stop}


def bbox_record(bbox_top: list[float], page_height: float, page_width: float) -> dict[str, Any]:
    x0, top, x1, bottom = bbox_top
    coords = [int(round(value * RENDER_SCALE)) for value in (x0, top, x1, bottom)]
    return {
        "bbox": {"x0": round(x0, 3), "y0": round(top, 3), "x1": round(x1, 3), "y1": round(bottom, 3), "origin": "top-left", "unit": "pt"},
        "bbox_pdf": {"x0": round(x0, 3), "y0": round(page_height - bottom, 3), "x1": round(x1, 3), "y1": round(page_height - top, 3), "origin": "bottom-left", "unit": "pt"},
        "map_area": {
            "shape": "rect",
            "coords": coords,
            "origin": "top-left",
            "unit": "px",
            "render_scale": RENDER_SCALE,
            "canvas_width": int(round(page_width * RENDER_SCALE)),
            "canvas_height": int(round(page_height * RENDER_SCALE)),
        },
    }


def horizontal_overlap(bbox: list[float], zone: tuple[float, float]) -> float:
    return max(0.0, min(bbox[2], zone[1]) - max(bbox[0], zone[0]))


def infer_reading_order(blocks: list[dict[str, Any]], page_width: float) -> list[dict[str, Any]]:
    """Order full-width anchors first, then read column regions left-to-right."""
    if not blocks:
        return blocks
    spanning = [block for block in blocks if (block["bbox_top"][2] - block["bbox_top"][0]) >= page_width * 0.62]
    span_floor = max((block["bbox_top"][3] for block in spanning), default=34.0)
    top = sorted([block for block in blocks if block in spanning or block["bbox_top"][1] < span_floor], key=lambda block: (block["bbox_top"][1], block["bbox_top"][0]))
    remaining = [block for block in blocks if block not in top]
    left = sorted([block for block in remaining if (block["bbox_top"][0] + block["bbox_top"][2]) / 2 < page_width / 2], key=lambda block: (block["bbox_top"][1], block["bbox_top"][0]))
    right = sorted([block for block in remaining if block not in left], key=lambda block: (block["bbox_top"][1], block["bbox_top"][0]))
    ordered = top + left + right
    # Keep a geometrically adjacent caption immediately after its image.
    for image in [block for block in ordered if block["type"] == "image"]:
        nearby = []
        for caption in [block for block in ordered if block["type"] == "caption"]:
            gap = caption["bbox_top"][1] - image["bbox_top"][3]
            center_gap = abs((caption["bbox_top"][0] + caption["bbox_top"][2]) / 2 - (image["bbox_top"][0] + image["bbox_top"][2]) / 2)
            if -3 <= gap <= 26 and center_gap <= 80:
                nearby.append((abs(gap) + center_gap * 0.05, caption))
        if nearby:
            caption = min(nearby, key=lambda item: item[0])[1]
            ordered.remove(caption)
            ordered.insert(ordered.index(image) + 1, caption)
    return ordered


def main() -> None:
    DIST.mkdir(parents=True, exist_ok=True)
    article_counter = 0
    known_articles: dict[str, dict[str, Any]] = {}
    pages: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []

    with pdfplumber.open(SOURCE_PDF) as pdf:
        for page_number, page in enumerate(pdf.pages, start=1):
            width, height = float(page.width), float(page.height)
            words = page.extract_words(
                x_tolerance=2,
                y_tolerance=2,
                keep_blank_chars=False,
                use_text_flow=False,
                extra_attrs=["fontname", "size"],
            )
            words = [word for word in words if float(word["top"]) >= 34 and float(word["bottom"]) <= height - 34]
            raw_blocks = text_blocks(line_segments(words))
            page_blocks: list[dict[str, Any]] = []
            for index, block in enumerate(raw_blocks, start=1):
                kind, confidence = classify(block)
                bbox_top = [float(block[key]) for key in ("x0", "top", "x1", "bottom")]
                page_blocks.append(
                    {
                        "id": f"p{page_number}-t{index:02d}",
                        "page_number": page_number,
                        "type": kind,
                        "article_id": None,
                        "confidence": confidence,
                        "text": block["text"],
                        "font": {"name": block["fontname"], "size_pt": round(float(block["size"]), 2)},
                        "bbox_top": bbox_top,
                        **bbox_record(bbox_top, height, width),
                    }
                )

            for image_index, image in enumerate(page.images, start=1):
                bbox_top = [float(image["x0"]), float(image["top"]), float(image["x1"]), float(image["bottom"])]
                if bbox_top[1] < 34 or bbox_top[3] > height - 34:
                    continue
                page_blocks.append(
                    {
                        "id": f"p{page_number}-i{image_index:02d}",
                        "page_number": page_number,
                        "type": "image",
                        "article_id": None,
                        "confidence": 0.99,
                        "text": "",
                        "image": {"width_pt": round(bbox_top[2] - bbox_top[0], 3), "height_pt": round(bbox_top[3] - bbox_top[1], 3)},
                        "bbox_top": bbox_top,
                        **bbox_record(bbox_top, height, width),
                    }
                )

            anchors: list[dict[str, Any]] = []
            for block in sorted(page_blocks, key=lambda item: (item["bbox_top"][1], item["bbox_top"][0])):
                if block["type"] == "title":
                    article_counter += 1
                    article_id = f"article-{article_counter:03d}"
                    block["article_id"] = article_id
                    known_articles[article_id] = {
                        "article_id": article_id,
                        "title": block["text"],
                        "title_tokens": sorted(title_tokens(block["text"])),
                        "pages": set(),
                        "block_ids": [],
                    }
                    anchors.append({"article_id": article_id, "block": block})
                elif block["type"] == "continuation":
                    tokens = title_tokens(block["text"])
                    scored = []
                    for article_id, article in known_articles.items():
                        overlap = len(tokens & set(article["title_tokens"]))
                        scored.append((overlap, article_id))
                    overlap, article_id = max(scored, default=(0, ""))
                    if overlap >= 2:
                        block["article_id"] = article_id
                        anchors.append({"article_id": article_id, "block": block})
                    else:
                        issues.append(
                            {
                                "issue_id": f"ISS-{len(issues) + 1:03d}",
                                "issue_code": "UNRESOLVED_CONTINUATION",
                                "status": "open",
                                "page_number": page_number,
                                "block_ids": [block["id"]],
                                "reason": "Continuation label did not share enough title tokens with an earlier article.",
                            }
                        )

            anchors.sort(key=lambda item: (item["block"]["bbox_top"][0] + item["block"]["bbox_top"][2]) / 2)
            zones: list[tuple[str, tuple[float, float]]] = []
            if len(anchors) == 1:
                zones = [(anchors[0]["article_id"], (36.0, width - 36.0))]
            elif anchors:
                centers = [(item["block"]["bbox_top"][0] + item["block"]["bbox_top"][2]) / 2 for item in anchors]
                boundaries = [36.0] + [(centers[index] + centers[index + 1]) / 2 for index in range(len(centers) - 1)] + [width - 36.0]
                zones = [(item["article_id"], (boundaries[index], boundaries[index + 1])) for index, item in enumerate(anchors)]

            image_assignments: dict[str, str | None] = {}
            for block in page_blocks:
                if block["article_id"] is not None or not zones:
                    continue
                bbox_top = block["bbox_top"]
                if block["type"] == "image":
                    scores = sorted(
                        [(horizontal_overlap(bbox_top, zone), article_id) for article_id, zone in zones],
                        reverse=True,
                    )
                    block_center = (bbox_top[0] + bbox_top[2]) / 2
                    centered_cross_column = (
                        len(scores) > 1
                        and bbox_top[0] < width / 2 < bbox_top[2]
                        and abs(block_center - width / 2) <= 3.0
                    )
                    tied_overlap = len(scores) > 1 and scores[0][0] > 0 and math.isclose(scores[0][0], scores[1][0], abs_tol=2.0)
                    if centered_cross_column or tied_overlap:
                        image_assignments[block["id"]] = None
                        issues.append(
                            {
                                "issue_id": f"ISS-{len(issues) + 1:03d}",
                                "issue_code": "AMBIGUOUS_ARTICLE_ASSOCIATION",
                                "status": "open",
                                "page_number": page_number,
                                "block_ids": [block["id"]],
                                "candidate_article_ids": sorted([scores[0][1], scores[1][1]]),
                                "reason": "Image overlaps the two inferred article zones equally; assignment was intentionally left null.",
                            }
                        )
                    else:
                        block["article_id"] = scores[0][1]
                        image_assignments[block["id"]] = scores[0][1]
                else:
                    center = (bbox_top[0] + bbox_top[2]) / 2
                    for article_id, zone in zones:
                        if zone[0] <= center <= zone[1]:
                            block["article_id"] = article_id
                            break

            # Captions inherit a nearby image assignment. If the image is unresolved,
            # the caption is added to the same issue instead of being forced into a column.
            images = [block for block in page_blocks if block["type"] == "image"]
            for caption in [block for block in page_blocks if block["type"] == "caption"]:
                candidates = []
                for image in images:
                    vertical_gap = caption["bbox_top"][1] - image["bbox_top"][3]
                    center_gap = abs((caption["bbox_top"][0] + caption["bbox_top"][2]) / 2 - (image["bbox_top"][0] + image["bbox_top"][2]) / 2)
                    if -3 <= vertical_gap <= 26 and center_gap <= 80:
                        candidates.append((abs(vertical_gap) + center_gap * 0.05, image))
                if candidates:
                    image = min(candidates, key=lambda item: item[0])[1]
                    caption["article_id"] = image["article_id"]
                    if image["article_id"] is None:
                        for issue in reversed(issues):
                            if image["id"] in issue["block_ids"]:
                                issue["block_ids"].append(caption["id"])
                                issue["reason"] = "Image and its caption overlap the two inferred article zones equally; assignment was intentionally left null."
                                break

            ordered = infer_reading_order(page_blocks, width)
            for reading_order, block in enumerate(ordered, start=1):
                block["reading_order"] = reading_order
                block.pop("bbox_top", None)
                if block["article_id"]:
                    article = known_articles[block["article_id"]]
                    article["pages"].add(page_number)
                    article["block_ids"].append(block["id"])
            pages.append(
                {
                    "page_number": page_number,
                    "width_pt": round(width, 3),
                    "height_pt": round(height, 3),
                    "rendered_size_px": [int(round(width * RENDER_SCALE)), int(round(height * RENDER_SCALE))],
                    "blocks": ordered,
                }
            )

    articles = []
    for article in known_articles.values():
        articles.append(
            {
                "article_id": article["article_id"],
                "title": article["title"],
                "page_numbers": sorted(article["pages"]),
                "block_ids": article["block_ids"],
            }
        )
    result = {
        "schema_version": "1.0",
        "contract": {"openapi_file": "openapi.yaml", "endpoint": "POST /v1/layout/extract"},
        "document": {
            "source_file": SOURCE_PDF.name,
            "source_sha256": sha256(SOURCE_PDF),
            "page_count": len(PdfReader(str(SOURCE_PDF)).pages),
            "contains_customer_data": False,
            "extraction_scope": "born-digital text plus embedded raster regions; OCR is outside this prototype",
        },
        "coordinate_systems": {
            "bbox": {"origin": "top-left", "unit": "pt"},
            "bbox_pdf": {"origin": "bottom-left", "unit": "pt"},
            "map_area": {"origin": "top-left", "unit": "px", "render_scale": RENDER_SCALE, "dpi": 144},
        },
        "pages": pages,
        "articles": articles,
        "issues": issues,
    }
    OUTPUT_JSON.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    ISSUES_JSON.write_text(json.dumps({"issue_count": len(issues), "issues": issues}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"pages": len(pages), "blocks": sum(len(page["blocks"]) for page in pages), "articles": len(articles), "issues": len(issues)}, sort_keys=True))


if __name__ == "__main__":
    main()
