#!/usr/bin/env python3
"""Generate a privacy-safe synthetic magazine PDF and layout ground truth."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas


BASE = Path(__file__).resolve().parent
FIXTURES = BASE / "fixtures"
SOURCE_PDF = FIXTURES / "Synthetic_Layout_Field_Notes.pdf"
GROUND_TRUTH = FIXTURES / "layout_ground_truth.json"
PAGE_WIDTH, PAGE_HEIGHT = A4


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_image(path: Path, variant: str) -> None:
    """Create a simple synthetic raster so the PDF contains real image objects."""
    image = Image.new("RGB", (720, 420), "#e8f0f7")
    draw = ImageDraw.Draw(image)
    if variant == "thermal":
        palette = ["#173f5f", "#20639b", "#3caea3", "#f6d55c", "#ed553b"]
        for index, color in enumerate(palette):
            left = int(index * image.width / len(palette))
            right = int((index + 1) * image.width / len(palette))
            draw.rectangle((left, 0, right, image.height), fill=color)
        draw.ellipse((215, 90, 505, 350), outline="#ffffff", width=12)
        draw.line((90, 320, 630, 105), fill="#ffffff", width=9)
    elif variant == "repair":
        draw.rectangle((55, 55, 665, 365), fill="#d9ead3", outline="#2f6b4f", width=6)
        for x in (150, 360, 570):
            draw.ellipse((x - 55, 125, x + 55, 235), fill="#ffffff", outline="#2f6b4f", width=6)
            draw.line((x, 235, x, 325), fill="#2f6b4f", width=9)
        draw.rectangle((95, 285, 625, 330), fill="#8fbc8f")
    else:
        draw.rectangle((45, 45, 675, 375), fill="#f5e6cc", outline="#7a5b35", width=6)
        for index, height in enumerate((110, 205, 150, 255, 185, 230)):
            x0 = 90 + index * 90
            draw.rectangle((x0, 340 - height, x0 + 48, 340), fill="#c57b57")
        draw.line((75, 340, 650, 340), fill="#7a5b35", width=6)
    image.save(path, format="PNG", optimize=True)


def main() -> None:
    FIXTURES.mkdir(parents=True, exist_ok=True)
    thermal = FIXTURES / "synthetic-thermal.png"
    repair = FIXTURES / "synthetic-repair.png"
    shared = FIXTURES / "synthetic-shared-chart.png"
    make_image(thermal, "thermal")
    make_image(repair, "repair")
    make_image(shared, "shared")

    blocks: list[dict[str, object]] = []
    article_titles = {
        "article-001": "Urban Cooling Field Notes",
        "article-002": "Repair Cafes as Local Infrastructure",
        "article-003": "Small Sensors, Better Streets",
        "article-004": "The Cost of Delayed Maintenance",
    }
    pdf = canvas.Canvas(str(SOURCE_PDF), pagesize=A4, invariant=1)
    pdf.setTitle("Synthetic Layout Field Notes")
    pdf.setAuthor("MicroStudio Synthetic Evidence")
    pdf.setSubject("Privacy-safe PDF layout-block extraction fixture")
    order = 0

    def frame(page_number: int, section: str) -> None:
        pdf.setFillColor(colors.HexColor("#17324D"))
        pdf.rect(0, PAGE_HEIGHT - 28, PAGE_WIDTH, 28, fill=1, stroke=0)
        pdf.setFillColor(colors.white)
        pdf.setFont("Helvetica-Bold", 7.5)
        pdf.drawString(42, PAGE_HEIGHT - 18, f"FIELD NOTES / {section.upper()}")
        pdf.drawRightString(PAGE_WIDTH - 42, PAGE_HEIGHT - 18, f"SYNTHETIC ISSUE 04 / {page_number}")
        pdf.setStrokeColor(colors.HexColor("#BDD0DF"))
        pdf.line(42, 34, PAGE_WIDTH - 42, 34)
        pdf.setFillColor(colors.HexColor("#66788A"))
        pdf.setFont("Helvetica", 7)
        pdf.drawString(42, 22, "Synthetic portfolio fixture - no customer or platform data")

    def text_block(
        *,
        block_id: str,
        page: int,
        kind: str,
        article_id: str | None,
        x: float,
        y: float,
        lines: list[str],
        font: str = "Helvetica",
        size: float = 9,
        leading: float = 12,
        color: str = "#243B53",
    ) -> None:
        nonlocal order
        order += 1
        pdf.setFillColor(colors.HexColor(color))
        pdf.setFont(font, size)
        for line_index, line in enumerate(lines):
            pdf.drawString(x, y - line_index * leading, line)
        max_width = max(stringWidth(line, font, size) for line in lines)
        last_y = y - (len(lines) - 1) * leading
        bbox_top = [
            round(x, 3),
            round(PAGE_HEIGHT - (y + size * 0.82), 3),
            round(x + max_width, 3),
            round(PAGE_HEIGHT - (last_y - size * 0.24), 3),
        ]
        blocks.append(
            {
                "block_id": block_id,
                "page_number": page,
                "type": kind,
                "article_id": article_id,
                "reading_order": order,
                "text": " ".join(lines),
                "bbox_top_left_pt": bbox_top,
            }
        )

    def image_block(
        *,
        block_id: str,
        page: int,
        article_id: str | None,
        path: Path,
        x: float,
        y: float,
        width: float,
        height: float,
    ) -> None:
        nonlocal order
        order += 1
        pdf.drawImage(str(path), x, y, width=width, height=height, preserveAspectRatio=False, mask="auto")
        blocks.append(
            {
                "block_id": block_id,
                "page_number": page,
                "type": "image",
                "article_id": article_id,
                "reading_order": order,
                "text": "",
                "bbox_top_left_pt": [x, PAGE_HEIGHT - (y + height), x + width, PAGE_HEIGHT - y],
            }
        )

    # Page 1: one article with a full-width title, image and two text columns.
    frame(1, "Climate")
    text_block(block_id="p1-b01", page=1, kind="title", article_id="article-001", x=42, y=768,
               lines=["Urban Cooling Field Notes"], font="Helvetica-Bold", size=24, leading=27, color="#17324D")
    text_block(block_id="p1-b02", page=1, kind="subtitle", article_id="article-001", x=42, y=729,
               lines=["A measured look at shade, surface temperature, and public-space use."], size=11, leading=14, color="#44627C")
    text_block(block_id="p1-b03", page=1, kind="byline", article_id="article-001", x=42, y=701,
               lines=["BY THE SYNTHETIC FIELD DESK"], font="Helvetica-Bold", size=8, leading=10, color="#2F6B8A")
    image_block(block_id="p1-b04", page=1, article_id="article-001", path=thermal, x=42, y=493, width=232, height=150)
    text_block(block_id="p1-b05", page=1, kind="caption", article_id="article-001", x=42, y=480,
               lines=["Figure 1. Fictional thermal gradient used only for layout testing."], size=7.5, leading=9, color="#66788A")
    text_block(block_id="p1-b06", page=1, kind="body", article_id="article-001", x=310, y=643,
               lines=[
                   "A shaded bench can feel like a small intervention,",
                   "yet its value is measurable. In this synthetic study,",
                   "surface readings were paired with observation windows",
                   "to separate temperature change from changes in footfall.",
                   "No real people, locations, or sensor records are used.",
               ], size=9, leading=12)
    text_block(block_id="p1-b07", page=1, kind="body", article_id="article-001", x=42, y=441,
               lines=[
                   "The layout deliberately mixes a raster image, a short",
                   "caption, and body copy. A useful extractor should return",
                   "each region independently while preserving their shared",
                   "article identity and page-level reading order.",
               ], size=9, leading=12)
    text_block(block_id="p1-b08", page=1, kind="pull_quote", article_id="article-001", x=310, y=442,
               lines=["Good extraction keeps", "uncertainty visible."], font="Helvetica-Oblique", size=14, leading=17, color="#B04A3A")
    text_block(block_id="p1-b09", page=1, kind="body", article_id="article-001", x=310, y=381,
               lines=[
                   "Coordinate output is expressed twice: PDF points with a",
                   "top-left origin, and integer map-area pixels at 144 dpi.",
                   "That makes the same block auditable in an API response",
                   "and directly usable on a rendered page preview.",
               ], size=9, leading=12)
    pdf.showPage()

    # Page 2: a left-column continuation and a new right-column article.
    frame(2, "Community")
    text_block(block_id="p2-b01", page=2, kind="continuation", article_id="article-001", x=42, y=765,
               lines=["URBAN COOLING - CONTINUED"], font="Helvetica-Bold", size=9, leading=12, color="#2F6B8A")
    text_block(block_id="p2-b02", page=2, kind="body", article_id="article-001", x=42, y=731,
               lines=[
                   "Across pages, the running continuation label links this",
                   "column to the article that began on page one. The rule is",
                   "visible and testable: shared title tokens plus the word",
                   "continued, not a hidden identifier inside the PDF.",
                   "A production system would keep lower-confidence matches",
                   "in an issue queue for reviewer confirmation.",
               ], size=9, leading=12)
    text_block(block_id="p2-b03", page=2, kind="title", article_id="article-002", x=310, y=765,
               lines=["Repair Cafes as", "Local Infrastructure"], font="Helvetica-Bold", size=20, leading=23, color="#17324D")
    text_block(block_id="p2-b04", page=2, kind="byline", article_id="article-002", x=310, y=704,
               lines=["BY THE SYNTHETIC CIVIC DESK"], font="Helvetica-Bold", size=8, leading=10, color="#2F6B8A")
    image_block(block_id="p2-b05", page=2, article_id="article-002", path=repair, x=310, y=507, width=243, height=160)
    text_block(block_id="p2-b06", page=2, kind="caption", article_id="article-002", x=310, y=494,
               lines=["Figure 2. Illustrative repair stations; not a real venue."], size=7.5, leading=9, color="#66788A")
    text_block(block_id="p2-b07", page=2, kind="body", article_id="article-002", x=310, y=459,
               lines=[
                   "The second article starts inside the right column. Its",
                   "title, byline, image, caption, and paragraphs should form",
                   "a distinct group even though another story shares the page.",
                   "This tests column-aware grouping rather than plain text order.",
               ], size=9, leading=12)
    text_block(block_id="p2-b08", page=2, kind="body", article_id="article-001", x=42, y=610,
               lines=[
                   "The continuation closes with a compact acceptance rule:",
                   "match representative pages first, then expand only after",
                   "the customer approves block types, coordinate origin, and",
                   "the definition of a complete article.",
               ], size=9, leading=12)
    text_block(block_id="p2-b09", page=2, kind="body", article_id="article-002", x=310, y=356,
               lines=[
                   "The fixture remains intentionally clean enough to audit,",
                   "but varied enough to exercise titles, captions, columns,",
                   "cross-page continuity, and embedded raster objects.",
               ], size=9, leading=12)
    pdf.showPage()

    # Page 3: two articles plus one deliberately ambiguous shared image.
    frame(3, "Operations")
    text_block(block_id="p3-b01", page=3, kind="title", article_id="article-003", x=42, y=765,
               lines=["Small Sensors,", "Better Streets"], font="Helvetica-Bold", size=20, leading=23, color="#17324D")
    text_block(block_id="p3-b02", page=3, kind="byline", article_id="article-003", x=42, y=704,
               lines=["BY THE SYNTHETIC DATA DESK"], font="Helvetica-Bold", size=8, leading=10, color="#2F6B8A")
    text_block(block_id="p3-b03", page=3, kind="body", article_id="article-003", x=42, y=669,
               lines=[
                   "Compact devices can support maintenance planning when",
                   "their limits are documented. Here, the text is fictional",
                   "and exists only to produce a repeatable layout fixture.",
                   "The left column is one complete article region.",
               ], size=9, leading=12)
    text_block(block_id="p3-b04", page=3, kind="title", article_id="article-004", x=310, y=765,
               lines=["The Cost of Delayed", "Maintenance"], font="Helvetica-Bold", size=20, leading=23, color="#17324D")
    text_block(block_id="p3-b05", page=3, kind="byline", article_id="article-004", x=310, y=704,
               lines=["BY THE SYNTHETIC OPERATIONS DESK"], font="Helvetica-Bold", size=8, leading=10, color="#2F6B8A")
    text_block(block_id="p3-b06", page=3, kind="body", article_id="article-004", x=310, y=669,
               lines=[
                   "Deferred repairs often create hidden queues. The right",
                   "column uses a separate title anchor so its paragraphs stay",
                   "independent from the neighboring sensor article.",
                   "No cost, customer, or operational claim is represented.",
               ], size=9, leading=12)
    image_block(block_id="p3-b07", page=3, article_id=None, path=shared, x=235, y=347, width=125, height=132)
    text_block(block_id="p3-b08", page=3, kind="caption", article_id=None, x=216, y=333,
               lines=["Figure 3. Shared chart with intentionally ambiguous article ownership."], size=7.5, leading=9, color="#66788A")
    text_block(block_id="p3-b09", page=3, kind="body", article_id="article-003", x=42, y=535,
               lines=[
                   "A centered chart overlaps both inferred column zones by",
                   "the same amount. The prototype must leave it unresolved",
                   "and emit an explicit association issue for review.",
               ], size=9, leading=12)
    text_block(block_id="p3-b10", page=3, kind="body", article_id="article-004", x=310, y=535,
               lines=[
                   "This is a deliberate truth-boundary test. A forced guess",
                   "would improve a superficial completeness number while",
                   "reducing the reliability of the downstream API.",
               ], size=9, leading=12)
    pdf.showPage()
    pdf.save()

    # Human-reviewed reading order follows full-width anchors and then columns
    # from left to right. The ambiguous shared image/caption pair stays together.
    reviewed_order = {
        1: ["p1-b01", "p1-b02", "p1-b03", "p1-b04", "p1-b05", "p1-b07", "p1-b06", "p1-b08", "p1-b09"],
        2: ["p2-b01", "p2-b02", "p2-b08", "p2-b03", "p2-b04", "p2-b05", "p2-b06", "p2-b07", "p2-b09"],
        3: ["p3-b01", "p3-b02", "p3-b03", "p3-b09", "p3-b07", "p3-b08", "p3-b04", "p3-b05", "p3-b06", "p3-b10"],
    }
    order_lookup = {
        (page_number, block_id): index
        for page_number, block_ids in reviewed_order.items()
        for index, block_id in enumerate(block_ids, start=1)
    }
    for block in blocks:
        block["reading_order"] = order_lookup[(int(block["page_number"]), str(block["block_id"]))]

    payload = {
        "schema_version": "1.0",
        "fixture": {
            "file": SOURCE_PDF.name,
            "sha256": sha256(SOURCE_PDF),
            "page_count": 3,
            "contains_customer_data": False,
            "coordinate_system": {"origin": "top-left", "unit": "pt"},
        },
        "articles": [{"article_id": key, "title": value} for key, value in article_titles.items()],
        "blocks": blocks,
        "expected_unresolved_issues": [
            {
                "issue_code": "AMBIGUOUS_ARTICLE_ASSOCIATION",
                "page_number": 3,
                "block_ids": ["p3-b07", "p3-b08"],
                "reason": "The shared image and caption overlap the two article column zones equally.",
            }
        ],
    }
    GROUND_TRUTH.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"source_pdf": str(SOURCE_PDF), "blocks": len(blocks), "sha256": payload["fixture"]["sha256"]}, sort_keys=True))


if __name__ == "__main__":
    main()
