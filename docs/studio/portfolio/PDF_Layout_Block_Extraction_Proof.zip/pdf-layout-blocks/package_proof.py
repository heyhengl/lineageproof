#!/usr/bin/env python3
"""Create a deterministic, privacy-scanned proof archive and manifest."""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from pathlib import Path


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
DIST = BASE / "dist"
EVIDENCE = ROOT / "output" / "pdf" / "PDF_Layout_Block_Extraction_Prototype_Evidence.pdf"
OUTPUT = ROOT / "output" / "portfolio" / "PDF_Layout_Block_Extraction_Proof_2026-07-18.zip"
MANIFEST = DIST / "artifact_manifest.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive_name(path: Path) -> str:
    if path == EVIDENCE:
        return f"evidence/{path.name}"
    return f"pdf-layout-blocks/{path.relative_to(BASE).as_posix()}"


def main() -> None:
    files = [
        BASE / "README.md",
        BASE / "generate_fixture.py",
        BASE / "extract_layout.py",
        BASE / "audit_prototype.py",
        BASE / "render_overlays.py",
        BASE / "build_evidence.py",
        BASE / "package_proof.py",
        BASE / "run_proof.py",
        BASE / "openapi.yaml",
        BASE / "tests" / "test_layout_extraction.py",
        BASE / "fixtures" / "Synthetic_Layout_Field_Notes.pdf",
        BASE / "fixtures" / "layout_ground_truth.json",
        BASE / "fixtures" / "synthetic-thermal.png",
        BASE / "fixtures" / "synthetic-repair.png",
        BASE / "fixtures" / "synthetic-shared-chart.png",
        DIST / "sample_response.json",
        DIST / "issues.json",
        DIST / "audit_report.json",
        DIST / "metrics.csv",
        DIST / "unresolved_issues.md",
        DIST / "overlays" / "page-1-overlay.png",
        DIST / "overlays" / "page-2-overlay.png",
        DIST / "overlays" / "page-3-overlay.png",
        EVIDENCE,
    ]
    missing = [str(path) for path in files if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing proof files: {missing}")

    sensitive_patterns = {
        "api_key_assignment": re.compile(rb"api[_-]?key\s*[:=]", re.IGNORECASE),
        "bearer_header": re.compile(rb"authorization\s*:\s*bearer\s+", re.IGNORECASE),
        "cookie_assignment": re.compile(rb"cookie\s*=", re.IGNORECASE),
        "private_key": re.compile(rb"BEGIN [A-Z ]*PRIVATE KEY", re.IGNORECASE),
    }
    findings: list[dict[str, str]] = []
    for path in files:
        if path.suffix.lower() not in {".py", ".json", ".yaml", ".yml", ".md", ".csv", ".txt"}:
            continue
        content = path.read_bytes()
        for name, pattern in sensitive_patterns.items():
            if pattern.search(content):
                findings.append({"file": archive_name(path), "pattern": name})
    if findings:
        raise RuntimeError(f"Sensitive-token scan failed: {findings}")

    entries = [
        {
            "archive_path": archive_name(path),
            "sha256": sha256(path),
            "size_bytes": path.stat().st_size,
        }
        for path in files
    ]
    manifest_payload = {
        "package": OUTPUT.name,
        "contains_customer_data": False,
        "contains_credentials_or_payment_data": False,
        "privacy_scan": {"patterns_checked": sorted(sensitive_patterns), "finding_count": 0},
        "scope_boundary": "Synthetic born-digital PDF only; no claim for arbitrary OCR, customer accuracy, production hosting, or SLA.",
        "entries": entries,
    }
    MANIFEST.write_text(json.dumps(manifest_payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    files.append(MANIFEST)

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files, key=archive_name):
            info = zipfile.ZipInfo(archive_name(path), date_time=(2000, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())

    with zipfile.ZipFile(OUTPUT) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"ZIP integrity failed at {bad}")
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise RuntimeError("ZIP contains duplicate paths")
        forbidden = [name for name in names if name.endswith((".env", ".DS_Store")) or "__pycache__" in name or "/.git/" in name]
        if forbidden:
            raise RuntimeError(f"ZIP contains forbidden paths: {forbidden}")
    print(json.dumps({"archive": str(OUTPUT), "files": len(files), "sha256": sha256(OUTPUT), "privacy_findings": 0}, sort_keys=True))


if __name__ == "__main__":
    main()
