#!/usr/bin/env python3
"""Build a Chinese evidence PDF from verified synthetic layout artifacts."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import Image, PageBreak, Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table, TableStyle


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[3]
DIST = BASE / "dist"
FIXTURES = BASE / "fixtures"
OUTPUT = ROOT / "output" / "pdf" / "PDF_Layout_Block_Extraction_Prototype_Evidence.pdf"
SOURCE = FIXTURES / "Synthetic_Layout_Field_Notes.pdf"
RESPONSE = DIST / "sample_response.json"
AUDIT = DIST / "audit_report.json"
OPENAPI = BASE / "openapi.yaml"
OVERLAYS = DIST / "overlays"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class InvariantCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        kwargs["invariant"] = 1
        super().__init__(*args, **kwargs)


def fit_image(path: Path, max_width: float, max_height: float) -> Image:
    width, height = ImageReader(str(path)).getSize()
    scale = min(max_width / width, max_height / height)
    return Image(str(path), width=width * scale, height=height * scale)


def main() -> None:
    pdfmetrics.registerFont(TTFont("CJK", "/System/Library/Fonts/Supplemental/Arial Unicode.ttf"))
    response = json.loads(RESPONSE.read_text(encoding="utf-8"))
    audit = json.loads(AUDIT.read_text(encoding="utf-8"))
    overlays = [OVERLAYS / f"page-{index}-overlay.png" for index in range(1, 4)]
    for path in [SOURCE, RESPONSE, AUDIT, OPENAPI, *overlays]:
        if not path.exists():
            raise FileNotFoundError(path)
    if not audit["passed"]:
        raise RuntimeError("Audit thresholds must pass before evidence PDF generation")
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)

    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "ChineseTitle", parent=styles["Title"], fontName="CJK", fontSize=25,
        leading=32, textColor=colors.HexColor("#17324D"), alignment=TA_LEFT, spaceAfter=4 * mm,
    )
    subtitle = ParagraphStyle(
        "ChineseSubtitle", parent=styles["BodyText"], fontName="CJK", fontSize=11,
        leading=17, textColor=colors.HexColor("#49657A"), spaceAfter=4 * mm,
    )
    h1 = ParagraphStyle(
        "ChineseH1", parent=styles["Heading1"], fontName="CJK", fontSize=17,
        leading=23, textColor=colors.HexColor("#17324D"), spaceAfter=3 * mm,
    )
    h2 = ParagraphStyle(
        "ChineseH2", parent=styles["Heading2"], fontName="CJK", fontSize=11.5,
        leading=16, textColor=colors.HexColor("#197278"), spaceBefore=2 * mm, spaceAfter=2 * mm,
    )
    body = ParagraphStyle(
        "ChineseBody", parent=styles["BodyText"], fontName="CJK", fontSize=9.5,
        leading=14.5, textColor=colors.HexColor("#243B53"), spaceAfter=2.5 * mm,
    )
    small = ParagraphStyle(
        "ChineseSmall", parent=body, fontSize=8, leading=11.5, textColor=colors.HexColor("#66788A"),
    )
    center = ParagraphStyle("ChineseCenter", parent=small, alignment=TA_CENTER)
    code = ParagraphStyle(
        "Code", parent=styles["Code"], fontName="Courier", fontSize=6.7, leading=8.4,
        leftIndent=3 * mm, rightIndent=3 * mm, textColor=colors.HexColor("#243B53"),
        backColor=colors.HexColor("#F5F8FA"), borderColor=colors.HexColor("#C6D5DF"),
        borderWidth=0.5, borderPadding=7,
    )

    def page_frame(pdf: canvas.Canvas, doc: SimpleDocTemplate) -> None:
        pdf.saveState()
        width, height = A4
        pdf.setFillColor(colors.HexColor("#102A43"))
        pdf.rect(0, height - 12 * mm, width, 12 * mm, fill=1, stroke=0)
        pdf.setFillColor(colors.white)
        pdf.setFont("Helvetica-Bold", 8.3)
        pdf.drawString(18 * mm, height - 7.8 * mm, "MICROSTUDIO | PDF LAYOUT BLOCK PROOF")
        pdf.setFillColor(colors.HexColor("#66788A"))
        pdf.setFont("CJK", 8)
        pdf.drawString(18 * mm, 9.5 * mm, "完全合成证据 - 不含客户、平台或身份数据")
        pdf.setFont("Helvetica", 8)
        pdf.drawRightString(width - 18 * mm, 9.5 * mm, f"Page {doc.page}")
        pdf.restoreState()

    doc = SimpleDocTemplate(
        str(OUTPUT), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=20 * mm, bottomMargin=18 * mm,
        title="PDF Layout Block Extraction Synthetic Prototype Evidence",
        author="MicroStudio", subject="Privacy-safe synthetic layout extraction evidence",
    )
    story: list[object] = []

    # Cover.
    story.append(Paragraph("PDF 版面文本块提取<br/>合成原型证据", title))
    story.append(Paragraph(
        "用于验证逐页块、标题/正文/图片归组、bbox 与 map-area 坐标、JSON/API 契约、质量指标和未解决问题日志。该证据只证明本合成 born-digital PDF 的能力边界，不冒充客户案例。",
        subtitle,
    ))
    metrics = audit["metrics"]
    kpis = [
        ["页面", "文本/图片块", "文章组", "bbox 平均 IoU", "待复核"],
        ["3", str(metrics["detected_blocks"]), "4", f"{metrics['mean_bbox_iou']:.4f}", str(metrics["unresolved_issue_count"])],
    ]
    table = Table(kpis, colWidths=[34 * mm] * 5, rowHeights=[9 * mm, 13 * mm])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#17324D")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, -1), "CJK"),
        ("FONTSIZE", (0, 0), (-1, 0), 8),
        ("FONTSIZE", (0, 1), (-1, 1), 12),
        ("BACKGROUND", (0, 1), (-1, 1), colors.HexColor("#EAF2F8")),
        ("TEXTCOLOR", (0, 1), (-1, 1), colors.HexColor("#17324D")),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#AFC7D6")),
    ]))
    story.append(table)
    story.append(Spacer(1, 5 * mm))
    story.append(fit_image(overlays[0], 170 * mm, 115 * mm))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph("图中彩色框直接使用 API 响应里的 144 dpi map-area 坐标绘制。", center))

    # Page 2: two source pages.
    story.append(PageBreak())
    story.append(Paragraph("1. 逐页版面块与跨页文章归组", h1))
    story.append(Paragraph(
        "第 1 页包含跨栏标题、图片、图注、正文和引语；第 2 页同时包含上一篇文章的 continuation 区域和一篇新文章。article-001 因可见标题词与 CONTINUED 标记跨页连接，article-002 保持独立。",
        body,
    ))
    story.append(fit_image(overlays[0], 170 * mm, 91 * mm))
    story.append(Spacer(1, 3 * mm))
    story.append(fit_image(overlays[1], 170 * mm, 91 * mm))
    story.append(Spacer(1, 2 * mm))
    story.append(Paragraph("框标签依次显示阅读顺序、块类型与 article_id。", center))

    # Page 3: ambiguity evidence.
    story.append(PageBreak())
    story.append(Paragraph("2. 图片归属不确定时不强行猜测", h1))
    story.append(Paragraph(
        "第 3 页有两篇独立文章。居中的 Figure 3 图片跨过两栏中线，其图注也与该图片相邻。原型将两者 article_id 保持为 null，并生成 AMBIGUOUS_ARTICLE_ASSOCIATION 待复核项。",
        body,
    ))
    story.append(fit_image(overlays[2], 170 * mm, 185 * mm))
    story.append(Spacer(1, 3 * mm))
    issue = response["issues"][0]
    issue_table = Table(
        [
            ["问题", issue["issue_code"]],
            ["状态", issue["status"]],
            ["候选文章", ", ".join(issue.get("candidate_article_ids", []))],
            ["处置", "由复核者选择文章，或明确标记为跨文章共享图片。"],
        ],
        colWidths=[34 * mm, 136 * mm],
    )
    issue_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "CJK"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#FDECEA")),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.HexColor("#A33A2B")),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#D8C5C1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(issue_table)

    # Page 4: coordinate and API contract.
    story.append(PageBreak())
    story.append(Paragraph("3. bbox、map-area 与 JSON/API 契约", h1))
    story.append(Paragraph(
        "同一块同时返回顶点为左上角的 PDF 点坐标、PDF 原生左下角坐标，以及按 2 倍比例渲染后的整数像素 map-area。这样网页预览和审计工具无需隐式换算。",
        body,
    ))
    coordinate_table = Table(
        [
            ["字段", "原点", "单位", "用途"],
            ["bbox", "左上角", "pt", "页面版面与模型审计"],
            ["bbox_pdf", "左下角", "pt", "PDF 原生坐标互操作"],
            ["map_area.coords", "左上角", "px", "144 dpi 页面图片的 HTML rect"],
        ],
        colWidths=[42 * mm, 31 * mm, 25 * mm, 72 * mm],
    )
    coordinate_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#17324D")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, -1), "CJK"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F8FA")]),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#C6D5DF")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(coordinate_table)
    story.append(Spacer(1, 4 * mm))
    sample = response["pages"][0]["blocks"][0]
    snippet = {
        "id": sample["id"],
        "type": sample["type"],
        "article_id": sample["article_id"],
        "reading_order": sample["reading_order"],
        "bbox": sample["bbox"],
        "map_area": sample["map_area"],
    }
    story.append(Paragraph("样例响应块", h2))
    story.append(Preformatted(json.dumps(snippet, indent=2, sort_keys=True), code))
    story.append(Spacer(1, 4 * mm))
    contract_rows = [
        ["Endpoint", response["contract"]["endpoint"]],
        ["Schema", "OpenAPI 3.1 / openapi.yaml"],
        ["成功响应", "document + pages[].blocks + articles + issues"],
        ["坐标画布", "页面点尺寸 x 2，输出整数像素"],
    ]
    contract_table = Table(contract_rows, colWidths=[38 * mm, 132 * mm])
    contract_table.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "CJK"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#E7F3F3")),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#B7D1D1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(contract_table)

    # Page 5: metrics and scope.
    story.append(PageBreak())
    story.append(Paragraph("4. 自动化指标、验证和未证明范围", h1))
    metric_rows = [
        ["指标", "结果", "阈值"],
        ["块 precision / recall", f"{metrics['block_precision']:.4f} / {metrics['block_recall']:.4f}", ">= 0.98"],
        ["块类型准确率", f"{metrics['type_accuracy']:.4f}", ">= 0.98"],
        ["文章归组准确率", f"{metrics['article_group_accuracy']:.4f}", ">= 0.98"],
        ["阅读顺序成对准确率", f"{metrics['reading_order_pair_accuracy']:.4f}", ">= 0.95"],
        ["bbox 平均 IoU", f"{metrics['mean_bbox_iou']:.4f}", ">= 0.90"],
        ["最大边缘误差", f"{metrics['max_bbox_edge_error_pt']:.3f} pt", "记录值"],
        ["JSON/map-area 契约", "通过", "必须通过"],
    ]
    metric_table = Table(metric_rows, colWidths=[70 * mm, 55 * mm, 45 * mm])
    metric_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#17324D")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, -1), "CJK"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F8FA")]),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#C6D5DF")),
        ("ALIGN", (1, 1), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(metric_table)
    story.append(Spacer(1, 5 * mm))
    story.append(Paragraph("已验证范围", h2))
    for text in [
        "完全合成的 3 页 born-digital PDF，包含双栏、跨页延续、图片、图注和引语。",
        "逐页块检测、块类型、article_id、阅读顺序、bbox/map-area 换算和开放问题输出。",
        "源文件、响应 JSON、审计报告和视觉框选证据均可用 SHA-256 复查。",
    ]:
        story.append(Paragraph(f"- {text}", body))
    story.append(Paragraph("未证明范围", h2))
    for text in [
        "扫描件 OCR、手写内容、复杂表格、任意未知版式和生产级吞吐。",
        "客户真实 PDF 上的最终准确率、托管 API、认证、监控或 SLA。",
        "唯一待复核项必须由人工选择文章，或明确标记为共享图片。",
    ]:
        story.append(Paragraph(f"- {text}", body))
    story.append(Spacer(1, 3 * mm))
    story.append(Paragraph("冻结指纹", h2))
    story.append(Paragraph(f"Source PDF SHA-256: {sha256(SOURCE)}", small))
    story.append(Paragraph(f"Sample response SHA-256: {sha256(RESPONSE)}", small))
    story.append(Paragraph(f"Audit report SHA-256: {sha256(AUDIT)}", small))

    doc.build(story, onFirstPage=page_frame, onLaterPages=page_frame, canvasmaker=InvariantCanvas)
    print(OUTPUT)


if __name__ == "__main__":
    main()
