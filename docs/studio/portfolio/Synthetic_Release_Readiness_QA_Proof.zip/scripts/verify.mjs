import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const fixture = JSON.parse(await readFile(new URL("fixture.json", root), "utf8"));
const report = JSON.parse(await readFile(new URL("run-report.json", root), "utf8"));
const issue = await readFile(new URL("issues/QA-001.md", root), "utf8");

assert.equal(fixture.fictional_product, true);
assert.equal(fixture.customer_data, false);
assert.equal(fixture.external_calls, 0);

const evidenceIds = new Set(fixture.evidence.map((item) => item.id));
assert.equal(evidenceIds.size, fixture.evidence.length);

const caseIds = new Set();
for (const testCase of fixture.test_cases) {
  assert.ok(!caseIds.has(testCase.id), `duplicate test case ${testCase.id}`);
  caseIds.add(testCase.id);
  assert.ok(["PASS", "REVIEW"].includes(testCase.state), testCase.id);
  assert.ok(testCase.evidence_refs.length > 0, testCase.id);
  for (const evidenceRef of testCase.evidence_refs) {
    assert.ok(evidenceIds.has(evidenceRef), `${testCase.id}:${evidenceRef}`);
  }
  if (testCase.state === "REVIEW") {
    assert.equal(testCase.issue_id, "QA-001");
  }
}

const pass = fixture.test_cases.filter((testCase) => testCase.state === "PASS").length;
const review = fixture.test_cases.filter((testCase) => testCase.state === "REVIEW").length;
assert.equal(report.test_cases, fixture.test_cases.length);
assert.equal(report.pass, pass);
assert.equal(report.review, review);
assert.equal(report.fail, 0);
assert.equal(report.open_issues, review);
assert.equal(report.release_state, review > 0 ? "REVIEW" : "PASS");
assert.equal(report.external_calls, 0);
assert.equal(report.customer_data, false);
assert.ok(issue.includes("Severity: Medium"));
assert.ok(issue.includes("fictional defect in a synthetic fixture"));

console.log(JSON.stringify(report));
