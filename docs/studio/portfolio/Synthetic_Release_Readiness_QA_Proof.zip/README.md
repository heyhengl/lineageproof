# Synthetic release-readiness QA proof

This package demonstrates a bounded QA audit for one fictional appointment
scheduling workflow. It is not a client case study and does not represent a
production application, customer engagement, security assessment, performance
test or compliance certification.

The fixture contains six deterministic test cases:

- five resolve to `PASS`;
- one routes to `REVIEW` with a reproducible issue report;
- every case names its synthetic evidence;
- no network, live account, credential, personal record or customer data is
  used.

Run the verifier with:

```bash
node scripts/verify.mjs
```

The verifier checks case IDs, evidence references, issue routing, control
counts and the release decision in `run-report.json`.

## Opening audit boundary

A real engagement starts with one synthetic or sanitized workflow, up to ten
agreed checks, up to three issue reports and one bounded retest. Production
accounts, broad device labs, load testing, security testing, regulated-data
handling and deployment are separately scoped only after authority, privacy and
access conditions are confirmed.
