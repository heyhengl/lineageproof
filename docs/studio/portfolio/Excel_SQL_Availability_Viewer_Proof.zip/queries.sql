-- Product-level availability at the reference date.
WITH active AS (
    SELECT
        b.product_id,
        b.status,
        SUM(b.quantity) AS quantity
    FROM bookings AS b
    WHERE b.start_date <= :reference_date
      AND b.end_date >= :reference_date
      AND b.status IN ('Quoted', 'Booked', 'On Hire')
    GROUP BY b.product_id, b.status
)
SELECT
    p.product_id,
    p.product_name,
    p.fleet_total,
    COALESCE(SUM(CASE WHEN a.status = 'Quoted' THEN a.quantity END), 0) AS quoted_now,
    COALESCE(SUM(CASE WHEN a.status = 'Booked' THEN a.quantity END), 0) AS booked_now,
    COALESCE(SUM(CASE WHEN a.status = 'On Hire' THEN a.quantity END), 0) AS on_hire_now,
    p.fleet_total
      - COALESCE(SUM(CASE WHEN a.status IN ('Booked', 'On Hire') THEN a.quantity END), 0)
      AS available_now,
    p.fleet_total
      - COALESCE(SUM(CASE WHEN a.status IN ('Quoted', 'Booked', 'On Hire') THEN a.quantity END), 0)
      AS quote_headroom
FROM products AS p
LEFT JOIN active AS a ON a.product_id = p.product_id
GROUP BY p.product_id, p.product_name, p.fleet_total
ORDER BY p.product_id;

-- Daily units that are booked out. Quotes do not consume stock.
SELECT
    p.product_id,
    p.product_name,
    d.day,
    COALESCE(SUM(CASE WHEN b.status IN ('Booked', 'On Hire') THEN b.quantity END), 0)
      AS booked_out
FROM products AS p
CROSS JOIN calendar AS d
LEFT JOIN bookings AS b
  ON b.product_id = p.product_id
 AND b.start_date <= d.day
 AND b.end_date >= d.day
GROUP BY p.product_id, p.product_name, d.day
ORDER BY p.product_id, d.day;

-- Client-level schedule for the review window.
SELECT
    b.booking_id,
    b.product_id,
    p.product_name,
    b.client_name,
    b.start_date,
    b.end_date,
    b.status,
    b.quantity
FROM bookings AS b
JOIN products AS p ON p.product_id = b.product_id
ORDER BY b.start_date, b.booking_id;

