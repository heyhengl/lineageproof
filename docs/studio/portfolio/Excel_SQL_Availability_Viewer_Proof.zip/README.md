# Excel + SQL Availability Viewer — synthetic proof

This deterministic sample mirrors the public requirements of PeoplePerHour project `4513841` without using buyer data, credentials, or a production database.

It demonstrates:

- a read-only SQL data contract for fleet totals, quoted, booked, and on-hire quantities;
- an Excel dashboard with formula-driven availability and a 14-day booked-out view;
- a client schedule and a fail-closed exception queue;
- SQL/workbook reconciliation at product and control-total level;
- a reproducible SQLite stand-in that can be replaced with the buyer's actual SQL dialect after the database type and read-only access method are confirmed.

Build sequence:

```sh
python3 build_source.py
node build_workbook.mjs
python3 verify_proof.py
```

The workbook is a synthetic capability proof, not evidence of a live buyer database connection or prior client delivery.

